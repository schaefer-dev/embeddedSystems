//
// Created by Daniel Schäfer on 19.06.18.
//

#ifndef EMBEDDEDSYSTEMS18_UTILITY_H
#define EMBEDDEDSYSTEMS18_UTILITY_H


class Utility {

public:
    static int int_pow(int base, int exp);
    static int maximum(int a, int b);
};


#endif //EMBEDDEDSYSTEMS18_UTILITY_H
