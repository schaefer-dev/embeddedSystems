#include "__cf_enable_hold.h"
#include "enable_hold_capi.h"
#include "enable_hold.h"
#include "enable_hold_private.h"
static RegMdlInfo rtMdlInfo_enable_hold [ 46 ] = { { "n1ljxg42ztp" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "enable_hold" } , {
"ayscym2s52" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "i2ahgcfqnf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "nltx03uscc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"am2ws025am" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "nyeam0z5vn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "mkkyw2crv2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"bvoao4osrh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "atokffp4qm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "e25dtcjkkv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"isbf0vjqji" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "izbiho5mjy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "ezoyf2vg2d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"j4sttxvfh0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "e2vf0mfuvm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "k2z2rnpuwa" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"nrszje2zqa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "o0iyk4gijb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "gu4l3yxezw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"k1bgzwznlm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "hdlazxqvxn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "e2gokq3a0m" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"enable_hold" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"ica1qecniym" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "fa5ltfyhyj4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "enable_hold" } , { "m2vq3ljshv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"luk53srd2vg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "lab0pp4wvzj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "enable_hold" } , { "ica1qecniy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"fa5ltfyhyj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"enable_hold" } , { "a150ea0bnm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "enable_hold" } , { "j40hacjaod" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "enable_hold" } , { "mr_enable_hold_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "enable_hold" } , { "mr_enable_hold_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "enable_hold" } , {
"mr_enable_hold_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"enable_hold" } , { "mr_enable_hold_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "enable_hold" } , { "enable_hold.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , { "enable_hold.c" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * ) "enable_hold" } } ;
ksacfc1uotb ksacfc1uot = { 0.0 , 1.0 , 0.0 , 0.0 } ; void gu4l3yxezw ( real_T
* ax3gpbdowu ) { * ax3gpbdowu = ksacfc1uot . P_0 ; } void k2z2rnpuwa (
isbf0vjqji * localDW ) { if ( localDW -> cvt4onnzup ) { localDW -> cvt4onnzup
= false ; } } void o0iyk4gijb ( const real_T * bfbsotkw43 , izbiho5mjy *
localB , isbf0vjqji * localDW , ayscym2s52 * localZCSV ) { localZCSV ->
oez5bkv2ld = * bfbsotkw43 - ksacfc1uot . P_3 ; localZCSV -> daldcwqhia =
localB -> c1yikhioct ; if ( ! localDW -> cvt4onnzup ) { } } void enable_hold
( j40hacjaod * const m5524orqff , const real_T * bfbsotkw43 , const real_T *
dsy1i1sfrz , real_T * ax3gpbdowu , izbiho5mjy * localB , isbf0vjqji * localDW
) { if ( rtmIsMajorTimeStep ( m5524orqff ) ) { localDW -> c3mmr1u343 = ( *
bfbsotkw43 > ksacfc1uot . P_3 ) ; } if ( localDW -> c3mmr1u343 ) { localB ->
c1yikhioct = ksacfc1uot . P_1 ; } else { localB -> c1yikhioct = ksacfc1uot .
P_2 ; } if ( ( rtmIsMajorTimeStep ( m5524orqff ) && rtmIsSampleHit (
m5524orqff , 1 , 0 ) ) && rtmIsMajorTimeStep ( m5524orqff ) ) { if ( localB
-> c1yikhioct > 0.0 ) { if ( ! localDW -> cvt4onnzup ) { if ( rtmGetTaskTime
( m5524orqff , 1 ) != rtmGetTStart ( m5524orqff ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( m5524orqff -> _mdlRefSfcnS ) ; }
localDW -> cvt4onnzup = true ; } } else { if ( localDW -> cvt4onnzup ) {
ssSetBlockStateForSolverChangedAtMajorStep ( m5524orqff -> _mdlRefSfcnS ) ;
localDW -> cvt4onnzup = false ; } } } if ( localDW -> cvt4onnzup ) { *
ax3gpbdowu = * bfbsotkw43 + * dsy1i1sfrz ; if ( rtmIsMajorTimeStep (
m5524orqff ) ) { srUpdateBC ( localDW -> o3loph3gyw ) ; } } } void
enable_holdTID2 ( void ) { } void j4sttxvfh0 ( j40hacjaod * const m5524orqff
) { if ( ! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent (
m5524orqff -> _mdlRefSfcnS , "enable_hold" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void k1bgzwznlm (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , j40hacjaod * const m5524orqff , izbiho5mjy * localB ,
isbf0vjqji * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) m5524orqff , 0 , sizeof ( j40hacjaod ) ) ;
m5524orqff -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; m5524orqff ->
Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; m5524orqff -> Timing .
mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; m5524orqff -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( m5524orqff -> _mdlRefSfcnS , "enable_hold" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> c1yikhioct = 0.0
; } ( void ) memset ( ( void * ) localDW , 0 , sizeof ( isbf0vjqji ) ) ;
enable_hold_InitializeDataMapInfo ( m5524orqff , localDW , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
m5524orqff -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( m5524orqff ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
m5524orqff -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_enable_hold_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_enable_hold , 46 ) ; * retVal = 1 ; } static void
mr_enable_hold_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_enable_hold_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_enable_hold_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_enable_hold_restoreDataFromMxArray ( void * destData , const mxArray
* srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_enable_hold_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_enable_hold_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int
j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_enable_hold_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_enable_hold_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_enable_hold_cacheDataToMxArrayWithOffset ( mxArray * destArray , mwIndex i
, int j , mwIndex offset , const void * srcData , size_t numBytes ) ; static
void mr_enable_hold_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
{ uint8_T * varData = ( uint8_T * ) mxGetData ( mxGetFieldByNumber (
destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData [ offset * numBytes
] , ( const uint8_T * ) srcData , numBytes ) ; } static void
mr_enable_hold_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_enable_hold_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_enable_hold_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray
, mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_enable_hold_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_enable_hold_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_enable_hold_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_enable_hold_GetDWork ( const n1ljxg42ztp * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_enable_hold_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 3 ]
= { "mdlrefDW->rtdw.o3loph3gyw" , "mdlrefDW->rtdw.c3mmr1u343" ,
"mdlrefDW->rtdw.cvt4onnzup" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 3 , rtdwDataFieldNames ) ; mr_enable_hold_cacheDataAsMxArray (
rtdwData , 0 , 0 , & ( mdlrefDW -> rtdw . o3loph3gyw ) , sizeof ( mdlrefDW ->
rtdw . o3loph3gyw ) ) ; mr_enable_hold_cacheDataAsMxArray ( rtdwData , 0 , 1
, & ( mdlrefDW -> rtdw . c3mmr1u343 ) , sizeof ( mdlrefDW -> rtdw .
c3mmr1u343 ) ) ; mr_enable_hold_cacheDataAsMxArray ( rtdwData , 0 , 2 , & (
mdlrefDW -> rtdw . cvt4onnzup ) , sizeof ( mdlrefDW -> rtdw . cvt4onnzup ) )
; mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_enable_hold_SetDWork ( n1ljxg42ztp * mdlrefDW , const mxArray * ssDW ) {
mr_enable_hold_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0
, sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_enable_hold_restoreDataFromMxArray (
& ( mdlrefDW -> rtdw . o3loph3gyw ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW ->
rtdw . o3loph3gyw ) ) ; mr_enable_hold_restoreDataFromMxArray ( & ( mdlrefDW
-> rtdw . c3mmr1u343 ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw .
c3mmr1u343 ) ) ; mr_enable_hold_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. cvt4onnzup ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . cvt4onnzup )
) ; } } void mr_enable_hold_RegisterSimStateChecksum ( SimStruct * S ) {
const uint32_T chksum [ 4 ] = { 443342177U , 427441288U , 2619250043U ,
1404803705U , } ; slmrModelRefRegisterSimStateChecksum ( S , "enable_hold" ,
& chksum [ 0 ] ) ; } mxArray * mr_enable_hold_GetSimStateDisallowedBlocks ( )
{ return NULL ; }
