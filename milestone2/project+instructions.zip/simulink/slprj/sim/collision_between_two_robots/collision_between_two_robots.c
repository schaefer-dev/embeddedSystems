#include "__cf_collision_between_two_robots.h"
#include "collision_between_two_robots_capi.h"
#include "collision_between_two_robots.h"
#include "collision_between_two_robots_private.h"
static RegMdlInfo rtMdlInfo_collision_between_two_robots [ 44 ] = { {
"alscpsbetdd" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "iimqbbjb2z" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "hrrs2t1hrv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "izststszvf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "n5ci2thof0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "pog4heqyom" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "h3mejrgdh3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "pqwqa4bvyo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "frs4ulljyo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "e34spd1eyh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "hmfgq0pduk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "mohwqmysoh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "izom5m5q55" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "ppne3p4rj0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "evgvxvtciw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "lykin54hlj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "m2f0lgduyv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "mwju1cce1h" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "hrcfg5ieq3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "fnba5phedl" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "collision_between_two_robots" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "kqhz01sozwc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "jsgonmpiris" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "gp3cvmrj2c" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "d0351qwarf1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "kqhz01sozw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "jsgonmpiri" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "ooflf54s5f" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "gvmzk0fl4d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision_between_two_robots" } , { "pwumfdjokh3" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , {
"mr_collision_between_two_robots_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision_between_two_robots" } , {
"mr_collision_between_two_robots_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "collision_between_two_robots" } , {
"mr_collision_between_two_robots_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "collision_between_two_robots" } , {
"collision_between_two_robots.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "collision_between_two_robots.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1
, ( void * ) "collision_between_two_robots" } } ; void hrcfg5ieq3 (
hmfgq0pduk * localDW ) { i4c20is4cv ( & ( localDW -> ddmunrklls . rtdw ) ) ;
i4c20is4cv ( & ( localDW -> pveuch1us5 . rtdw ) ) ; i4c20is4cv ( & ( localDW
-> omy5bzwku5 . rtdw ) ) ; i4c20is4cv ( & ( localDW -> c2p4x13tse . rtdw ) )
; i4c20is4cv ( & ( localDW -> lud0lsws1r . rtdw ) ) ; i4c20is4cv ( & (
localDW -> d052an5vz3 . rtdw ) ) ; i4c20is4cv ( & ( localDW -> lkijrf5rww .
rtdw ) ) ; i4c20is4cv ( & ( localDW -> m0zpvbz51r . rtdw ) ) ; } void
lykin54hlj ( hmfgq0pduk * localDW , iimqbbjb2z * localZCSV ) { pdwmgeosum ( &
( localDW -> ddmunrklls . rtb ) , & ( localZCSV -> owuxdtzoig ) ) ;
pdwmgeosum ( & ( localDW -> pveuch1us5 . rtb ) , & ( localZCSV -> eeozmf2aou
) ) ; pdwmgeosum ( & ( localDW -> omy5bzwku5 . rtb ) , & ( localZCSV ->
a5ajufwhl4 ) ) ; pdwmgeosum ( & ( localDW -> c2p4x13tse . rtb ) , & (
localZCSV -> g3fyfyg2z5 ) ) ; pdwmgeosum ( & ( localDW -> lud0lsws1r . rtb )
, & ( localZCSV -> lebxfuu3gd ) ) ; pdwmgeosum ( & ( localDW -> d052an5vz3 .
rtb ) , & ( localZCSV -> khy5m1sv2i ) ) ; pdwmgeosum ( & ( localDW ->
lkijrf5rww . rtb ) , & ( localZCSV -> la2ajilz3t ) ) ; pdwmgeosum ( & (
localDW -> m0zpvbz51r . rtb ) , & ( localZCSV -> l5zg5q0eg0 ) ) ; } void
collision_between_two_robots ( const real_T cqnf1hvbbq [ 2 ] , const real_T
kgq5gprc4c [ 2 ] , const real_T ea0wflbvz5 [ 2 ] , const real_T akxeqwc2of [
2 ] , const real_T hazmue4lk1 [ 2 ] , const real_T cqbom3utsp [ 2 ] , const
real_T bh1kmek4w4 [ 2 ] , const real_T flh2dyfykp [ 2 ] , real_T * kdaes4ewfm
, real_T * btrcky5iv0 , real_T * f53nk1solk , real_T * nejzdpvfk3 , real_T *
azlp514mtk , real_T * eqaslwac2f , real_T * fosinrpole , real_T * pp1bob34u4
, real_T * fn31plbhb3 , real_T * j2e4k0fal2 , real_T * lbamjxjn3j , real_T *
j3xj1j3h2f , real_T * l2vgl4d2e4 , real_T * pjj5yv04cg , real_T * ouupl0cdgc
, real_T * afjol4u5nf , real_T * g10tao1zsn , real_T * mgpl4k3ppa , real_T *
pkcbyilhxw , real_T * jdrlhzvtev , real_T * dx2y3gq1u4 , real_T * kotkzrgcsa
, real_T * ptmzf1eebl , real_T * pd5vefvn4n , real_T * dffsuv5xm0 , real_T *
clmcpj43dq , real_T * h4hpoqrnra , real_T * n5ga5jisx1 , real_T * nnohfvoqbc
, real_T * fefoxb05bs , real_T * jushde1qle , real_T * pnp4saief2 ,
hmfgq0pduk * localDW ) { check_collision_with_bounding ( & ( localDW ->
ddmunrklls . rtm ) , & cqnf1hvbbq [ 0 ] , & kgq5gprc4c [ 0 ] , & ea0wflbvz5 [
0 ] , & akxeqwc2of [ 0 ] , & hazmue4lk1 [ 0 ] , kdaes4ewfm , btrcky5iv0 ,
f53nk1solk , nejzdpvfk3 , & ( localDW -> ddmunrklls . rtb ) , & ( localDW ->
ddmunrklls . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
pveuch1us5 . rtm ) , & cqnf1hvbbq [ 0 ] , & kgq5gprc4c [ 0 ] , & ea0wflbvz5 [
0 ] , & akxeqwc2of [ 0 ] , & cqbom3utsp [ 0 ] , azlp514mtk , eqaslwac2f ,
fosinrpole , pp1bob34u4 , & ( localDW -> pveuch1us5 . rtb ) , & ( localDW ->
pveuch1us5 . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
omy5bzwku5 . rtm ) , & cqnf1hvbbq [ 0 ] , & kgq5gprc4c [ 0 ] , & ea0wflbvz5 [
0 ] , & akxeqwc2of [ 0 ] , & bh1kmek4w4 [ 0 ] , fn31plbhb3 , j2e4k0fal2 ,
lbamjxjn3j , j3xj1j3h2f , & ( localDW -> omy5bzwku5 . rtb ) , & ( localDW ->
omy5bzwku5 . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
c2p4x13tse . rtm ) , & cqnf1hvbbq [ 0 ] , & kgq5gprc4c [ 0 ] , & ea0wflbvz5 [
0 ] , & akxeqwc2of [ 0 ] , & flh2dyfykp [ 0 ] , l2vgl4d2e4 , pjj5yv04cg ,
ouupl0cdgc , afjol4u5nf , & ( localDW -> c2p4x13tse . rtb ) , & ( localDW ->
c2p4x13tse . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
lud0lsws1r . rtm ) , & hazmue4lk1 [ 0 ] , & cqbom3utsp [ 0 ] , & bh1kmek4w4 [
0 ] , & flh2dyfykp [ 0 ] , & cqnf1hvbbq [ 0 ] , g10tao1zsn , mgpl4k3ppa ,
pkcbyilhxw , jdrlhzvtev , & ( localDW -> lud0lsws1r . rtb ) , & ( localDW ->
lud0lsws1r . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
d052an5vz3 . rtm ) , & hazmue4lk1 [ 0 ] , & cqbom3utsp [ 0 ] , & bh1kmek4w4 [
0 ] , & flh2dyfykp [ 0 ] , & kgq5gprc4c [ 0 ] , dx2y3gq1u4 , kotkzrgcsa ,
ptmzf1eebl , pd5vefvn4n , & ( localDW -> d052an5vz3 . rtb ) , & ( localDW ->
d052an5vz3 . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
lkijrf5rww . rtm ) , & hazmue4lk1 [ 0 ] , & cqbom3utsp [ 0 ] , & bh1kmek4w4 [
0 ] , & flh2dyfykp [ 0 ] , & ea0wflbvz5 [ 0 ] , dffsuv5xm0 , clmcpj43dq ,
h4hpoqrnra , n5ga5jisx1 , & ( localDW -> lkijrf5rww . rtb ) , & ( localDW ->
lkijrf5rww . rtdw ) ) ; check_collision_with_bounding ( & ( localDW ->
m0zpvbz51r . rtm ) , & hazmue4lk1 [ 0 ] , & cqbom3utsp [ 0 ] , & bh1kmek4w4 [
0 ] , & flh2dyfykp [ 0 ] , & akxeqwc2of [ 0 ] , nnohfvoqbc , fefoxb05bs ,
jushde1qle , pnp4saief2 , & ( localDW -> m0zpvbz51r . rtb ) , & ( localDW ->
m0zpvbz51r . rtdw ) ) ; } void ppne3p4rj0 ( hmfgq0pduk * localDW , gvmzk0fl4d
* const cle1hx0fby ) { agrzpxqxax ( & ( localDW -> ddmunrklls . rtdw ) , & (
localDW -> ddmunrklls . rtm ) ) ; agrzpxqxax ( & ( localDW -> pveuch1us5 .
rtdw ) , & ( localDW -> pveuch1us5 . rtm ) ) ; agrzpxqxax ( & ( localDW ->
omy5bzwku5 . rtdw ) , & ( localDW -> omy5bzwku5 . rtm ) ) ; agrzpxqxax ( & (
localDW -> c2p4x13tse . rtdw ) , & ( localDW -> c2p4x13tse . rtm ) ) ;
agrzpxqxax ( & ( localDW -> lud0lsws1r . rtdw ) , & ( localDW -> lud0lsws1r .
rtm ) ) ; agrzpxqxax ( & ( localDW -> d052an5vz3 . rtdw ) , & ( localDW ->
d052an5vz3 . rtm ) ) ; agrzpxqxax ( & ( localDW -> lkijrf5rww . rtdw ) , & (
localDW -> lkijrf5rww . rtm ) ) ; agrzpxqxax ( & ( localDW -> m0zpvbz51r .
rtdw ) , & ( localDW -> m0zpvbz51r . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( cle1hx0fby ->
_mdlRefSfcnS , "collision_between_two_robots" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void mwju1cce1h (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , gvmzk0fl4d * const cle1hx0fby
, hmfgq0pduk * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) cle1hx0fby , 0 , sizeof ( gvmzk0fl4d ) ) ;
cle1hx0fby -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; cle1hx0fby ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( cle1hx0fby -> _mdlRefSfcnS ,
"collision_between_two_robots" , "START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" )
; } ( void ) memset ( ( void * ) localDW , 0 , sizeof ( hmfgq0pduk ) ) ;
collision_between_two_robots_InitializeDataMapInfo ( cle1hx0fby , localDW ,
sysRanPtr , contextTid ) ; pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & (
localDW -> ddmunrklls . rtm ) , & ( localDW -> ddmunrklls . rtb ) , & (
localDW -> ddmunrklls . rtdw ) , cle1hx0fby -> DataMapInfo . systemRan [ 0 ]
, cle1hx0fby -> DataMapInfo . systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo
. mmi ) , "collision_between_two_robots/Check Collision With BB" , 0 , - 1 )
; pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> pveuch1us5 . rtm )
, & ( localDW -> pveuch1us5 . rtb ) , & ( localDW -> pveuch1us5 . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB1" , 1 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> omy5bzwku5 . rtm ) ,
& ( localDW -> omy5bzwku5 . rtb ) , & ( localDW -> omy5bzwku5 . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB2" , 2 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> c2p4x13tse . rtm ) ,
& ( localDW -> c2p4x13tse . rtb ) , & ( localDW -> c2p4x13tse . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB3" , 3 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> lud0lsws1r . rtm ) ,
& ( localDW -> lud0lsws1r . rtb ) , & ( localDW -> lud0lsws1r . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB4" , 4 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> d052an5vz3 . rtm ) ,
& ( localDW -> d052an5vz3 . rtb ) , & ( localDW -> d052an5vz3 . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB5" , 5 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> lkijrf5rww . rtm ) ,
& ( localDW -> lkijrf5rww . rtb ) , & ( localDW -> lkijrf5rww . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB6" , 6 , - 1 ) ;
pliranin35 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> m0zpvbz51r . rtm ) ,
& ( localDW -> m0zpvbz51r . rtb ) , & ( localDW -> m0zpvbz51r . rtdw ) ,
cle1hx0fby -> DataMapInfo . systemRan [ 0 ] , cle1hx0fby -> DataMapInfo .
systemTid [ 0 ] , & ( cle1hx0fby -> DataMapInfo . mmi ) ,
"collision_between_two_robots/Check Collision With BB7" , 7 , - 1 ) ; if ( (
rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) {
rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( cle1hx0fby ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( cle1hx0fby -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( cle1hx0fby ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_collision_between_two_robots_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_check_collision_with_bounding_MdlInfoRegFcn ( mdlRefSfcnS ,
"check_collision_with_bounding" , retVal ) ; if ( * retVal == 0 ) return ; *
retVal = 0 ; } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS ,
modelName , rtMdlInfo_collision_between_two_robots , 44 ) ; * retVal = 1 ; }
static void mr_collision_between_two_robots_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_collision_between_two_robots_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_collision_between_two_robots_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_collision_between_two_robots_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy (
( uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_collision_between_two_robots_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) ; static void
mr_collision_between_two_robots_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i ,
j , mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_collision_between_two_robots_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_collision_between_two_robots_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_collision_between_two_robots_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_collision_between_two_robots_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_collision_between_two_robots_restoreDataFromMxArrayWithOffset ( void
* destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_collision_between_two_robots_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_collision_between_two_robots_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void
mr_collision_between_two_robots_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_collision_between_two_robots_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) ; static uint_T
mr_collision_between_two_robots_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) { const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_collision_between_two_robots_GetDWork
( const alscpsbetdd * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] =
{ "NULL->rtb" , "rtdw" , "NULL->rtzce" , } ; mxArray * ssDW =
mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ; { static const char *
rtdwDataFieldNames [ 8 ] = { "mdlrefDW->rtdw.ddmunrklls" ,
"mdlrefDW->rtdw.pveuch1us5" , "mdlrefDW->rtdw.omy5bzwku5" ,
"mdlrefDW->rtdw.c2p4x13tse" , "mdlrefDW->rtdw.lud0lsws1r" ,
"mdlrefDW->rtdw.d052an5vz3" , "mdlrefDW->rtdw.lkijrf5rww" ,
"mdlrefDW->rtdw.m0zpvbz51r" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 8 , rtdwDataFieldNames ) ; { mxArray * varData =
mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW -> rtdw . ddmunrklls
) ) ; mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } { mxArray *
varData = mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW -> rtdw .
pveuch1us5 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } {
mxArray * varData = mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW
-> rtdw . omy5bzwku5 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 2 , varData )
; } { mxArray * varData = mr_check_collision_with_bounding_GetDWork ( & (
mdlrefDW -> rtdw . c2p4x13tse ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 3 ,
varData ) ; } { mxArray * varData = mr_check_collision_with_bounding_GetDWork
( & ( mdlrefDW -> rtdw . lud0lsws1r ) ) ; mxSetFieldByNumber ( rtdwData , 0 ,
4 , varData ) ; } { mxArray * varData =
mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW -> rtdw . d052an5vz3
) ) ; mxSetFieldByNumber ( rtdwData , 0 , 5 , varData ) ; } { mxArray *
varData = mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW -> rtdw .
lkijrf5rww ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 6 , varData ) ; } {
mxArray * varData = mr_check_collision_with_bounding_GetDWork ( & ( mdlrefDW
-> rtdw . m0zpvbz51r ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 7 , varData )
; } mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_collision_between_two_robots_SetDWork ( alscpsbetdd * mdlrefDW , const
mxArray * ssDW ) { { const mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0
, 1 ) ; mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw .
ddmunrklls ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . pveuch1us5
) , mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . omy5bzwku5
) , mxGetFieldByNumber ( rtdwData , 0 , 2 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . c2p4x13tse
) , mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . lud0lsws1r
) , mxGetFieldByNumber ( rtdwData , 0 , 4 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . d052an5vz3
) , mxGetFieldByNumber ( rtdwData , 0 , 5 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . lkijrf5rww
) , mxGetFieldByNumber ( rtdwData , 0 , 6 ) ) ;
mr_check_collision_with_bounding_SetDWork ( & ( mdlrefDW -> rtdw . m0zpvbz51r
) , mxGetFieldByNumber ( rtdwData , 0 , 7 ) ) ; } } void
mr_collision_between_two_robots_RegisterSimStateChecksum ( SimStruct * S ) {
const uint32_T chksum [ 4 ] = { 1368796138U , 1854044995U , 2240951637U ,
532929833U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"collision_between_two_robots" , & chksum [ 0 ] ) ;
mr_check_collision_with_bounding_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_collision_between_two_robots_GetSimStateDisallowedBlocks ( ) { return
mr_check_collision_with_bounding_GetSimStateDisallowedBlocks ( ) ; }
