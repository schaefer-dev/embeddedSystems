#include "__cf_check_collision_with_bounding.h"
#include "check_collision_with_bounding_capi.h"
#include "check_collision_with_bounding.h"
#include "check_collision_with_bounding_private.h"
static RegMdlInfo rtMdlInfo_check_collision_with_bounding [ 45 ] = { {
"pwumfdjokh3" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "a4o4bify4r" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "ayi2o2ju5q" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "besjnijp1i" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "jlvvvyncfi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "lmeedhvfm2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "jvt11kniqe" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "ocwowgtvls" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "kfu40flnm4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "ajp3gro2ms" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "efinskpodg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "pqr3o0henh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "et5zzmxnor" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "agrzpxqxax" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "njuqy4bsix" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "pdwmgeosum" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "gxjz0ao54c" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "pliranin35" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "i4c20is4cv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "j0cdajkrj5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "check_collision_with_bounding" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "kpzhz3afzpj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "heqvqy2wpiu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "lzucqnalvx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "ndkf3pg5hqg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "oozsdzq0h3d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "kpzhz3afzp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "heqvqy2wpi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "baldpu2bah" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "lv1w310d1o" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , { "hiop4a4wknb" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , {
"mr_check_collision_with_bounding_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "check_collision_with_bounding" } , {
"mr_check_collision_with_bounding_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "check_collision_with_bounding" } , {
"check_collision_with_bounding.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
NULL ) } , { "check_collision_with_bounding.c" , MDL_INFO_MODEL_FILENAME , 0
, - 1 , ( void * ) "check_collision_with_bounding" } } ; void i4c20is4cv (
efinskpodg * localDW ) { bwtbvc0a4j ( & ( localDW -> blairxx1vj . rtdw ) ) ;
bwtbvc0a4j ( & ( localDW -> arprv3o2vz . rtdw ) ) ; bwtbvc0a4j ( & ( localDW
-> o30mbzurqt . rtdw ) ) ; bwtbvc0a4j ( & ( localDW -> gc4fzs2b2z . rtdw ) )
; } void pdwmgeosum ( pqr3o0henh * localB , a4o4bify4r * localZCSV ) {
localZCSV -> pegcidfdsy = localB -> i33aua3itk ; localZCSV -> oacisbyhw1 =
localB -> hsak5qsaji ; localZCSV -> ihbii4vefz = localB -> gujgvxpe5h ;
localZCSV -> cpvzfdd0fy = localB -> pawgmgahze ; } void
check_collision_with_bounding ( lv1w310d1o * const ne0pyymecy , const real_T
lry1xnto3a [ 2 ] , const real_T p0u2sizukj [ 2 ] , const real_T eehn2nro0z [
2 ] , const real_T minwt0uhrb [ 2 ] , const real_T nljvsh4hie [ 2 ] , real_T
* kdf2ekgda1 , real_T * hcsviezkmc , real_T * ftwulus2t5 , real_T *
lymbh00sji , pqr3o0henh * localB , efinskpodg * localDW ) { real_T l2n21xv4mb
; real_T msu35k2mr0 ; real_T an1e3owfw5 ; real_T cr5yeyduin ; real_T
c1ie30dh4m ; real_T mtygpvgxs5 ; real_T naqj4en1hh ; real_T mwpge405zr ;
real_T ggaryastfv ; real_T fefegj0hqw ; real_T lt0zfykqoj ; real_T c204par3mg
; to_line_segments ( & ( localDW -> blairxx1vj . rtm ) , & lry1xnto3a [ 0 ] ,
& p0u2sizukj [ 0 ] , & nljvsh4hie [ 0 ] , & l2n21xv4mb , & msu35k2mr0 , &
an1e3owfw5 , & ( localDW -> blairxx1vj . rtdw ) ) ; localB -> i33aua3itk = (
msu35k2mr0 + an1e3owfw5 ) - l2n21xv4mb ; if ( rtmIsMajorTimeStep ( ne0pyymecy
) ) { localDW -> nujdfx1zvk = ( localB -> i33aua3itk >= 0.0 ) ; } *
kdf2ekgda1 = localDW -> nujdfx1zvk > 0 ? localB -> i33aua3itk : - localB ->
i33aua3itk ; to_line_segments ( & ( localDW -> arprv3o2vz . rtm ) , &
p0u2sizukj [ 0 ] , & eehn2nro0z [ 0 ] , & nljvsh4hie [ 0 ] , & cr5yeyduin , &
c1ie30dh4m , & mtygpvgxs5 , & ( localDW -> arprv3o2vz . rtdw ) ) ; localB ->
hsak5qsaji = ( c1ie30dh4m + mtygpvgxs5 ) - cr5yeyduin ; if (
rtmIsMajorTimeStep ( ne0pyymecy ) ) { localDW -> dytv4pfvv3 = ( localB ->
hsak5qsaji >= 0.0 ) ; } * hcsviezkmc = localDW -> dytv4pfvv3 > 0 ? localB ->
hsak5qsaji : - localB -> hsak5qsaji ; to_line_segments ( & ( localDW ->
o30mbzurqt . rtm ) , & eehn2nro0z [ 0 ] , & minwt0uhrb [ 0 ] , & nljvsh4hie [
0 ] , & naqj4en1hh , & mwpge405zr , & ggaryastfv , & ( localDW -> o30mbzurqt
. rtdw ) ) ; localB -> gujgvxpe5h = ( mwpge405zr + ggaryastfv ) - naqj4en1hh
; if ( rtmIsMajorTimeStep ( ne0pyymecy ) ) { localDW -> airptslae2 = ( localB
-> gujgvxpe5h >= 0.0 ) ; } * ftwulus2t5 = localDW -> airptslae2 > 0 ? localB
-> gujgvxpe5h : - localB -> gujgvxpe5h ; to_line_segments ( & ( localDW ->
gc4fzs2b2z . rtm ) , & minwt0uhrb [ 0 ] , & lry1xnto3a [ 0 ] , & nljvsh4hie [
0 ] , & fefegj0hqw , & lt0zfykqoj , & c204par3mg , & ( localDW -> gc4fzs2b2z
. rtdw ) ) ; localB -> pawgmgahze = ( lt0zfykqoj + c204par3mg ) - fefegj0hqw
; if ( rtmIsMajorTimeStep ( ne0pyymecy ) ) { localDW -> a1rwb52k02 = ( localB
-> pawgmgahze >= 0.0 ) ; } * lymbh00sji = localDW -> a1rwb52k02 > 0 ? localB
-> pawgmgahze : - localB -> pawgmgahze ; } void agrzpxqxax ( efinskpodg *
localDW , lv1w310d1o * const ne0pyymecy ) { f13vsqxakx ( & ( localDW ->
blairxx1vj . rtm ) ) ; f13vsqxakx ( & ( localDW -> arprv3o2vz . rtm ) ) ;
f13vsqxakx ( & ( localDW -> o30mbzurqt . rtm ) ) ; f13vsqxakx ( & ( localDW
-> gc4fzs2b2z . rtm ) ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( ne0pyymecy -> _mdlRefSfcnS ,
"check_collision_with_bounding" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void pliranin35 (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , lv1w310d1o * const ne0pyymecy
, pqr3o0henh * localB , efinskpodg * localDW , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) ne0pyymecy , 0 , sizeof
( lv1w310d1o ) ) ; ne0pyymecy -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; ne0pyymecy -> _mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( ne0pyymecy ->
_mdlRefSfcnS , "check_collision_with_bounding" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> i33aua3itk = 0.0
; localB -> hsak5qsaji = 0.0 ; localB -> gujgvxpe5h = 0.0 ; localB ->
pawgmgahze = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
efinskpodg ) ) ; check_collision_with_bounding_InitializeDataMapInfo (
ne0pyymecy , localDW , sysRanPtr , contextTid ) ; kcfnbd3ym4 ( _mdlRefSfcnS ,
mdlref_TID0 , & ( localDW -> blairxx1vj . rtm ) , & ( localDW -> blairxx1vj .
rtdw ) , ne0pyymecy -> DataMapInfo . systemRan [ 0 ] , ne0pyymecy ->
DataMapInfo . systemTid [ 0 ] , & ( ne0pyymecy -> DataMapInfo . mmi ) ,
"check_collision_with_bounding/To Line Segments" , 0 , - 1 ) ; kcfnbd3ym4 (
_mdlRefSfcnS , mdlref_TID0 , & ( localDW -> arprv3o2vz . rtm ) , & ( localDW
-> arprv3o2vz . rtdw ) , ne0pyymecy -> DataMapInfo . systemRan [ 0 ] ,
ne0pyymecy -> DataMapInfo . systemTid [ 0 ] , & ( ne0pyymecy -> DataMapInfo .
mmi ) , "check_collision_with_bounding/To Line Segments1" , 1 , - 1 ) ;
kcfnbd3ym4 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> o30mbzurqt . rtm ) ,
& ( localDW -> o30mbzurqt . rtdw ) , ne0pyymecy -> DataMapInfo . systemRan [
0 ] , ne0pyymecy -> DataMapInfo . systemTid [ 0 ] , & ( ne0pyymecy ->
DataMapInfo . mmi ) , "check_collision_with_bounding/To Line Segments2" , 2 ,
- 1 ) ; kcfnbd3ym4 ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> gc4fzs2b2z .
rtm ) , & ( localDW -> gc4fzs2b2z . rtdw ) , ne0pyymecy -> DataMapInfo .
systemRan [ 0 ] , ne0pyymecy -> DataMapInfo . systemTid [ 0 ] , & (
ne0pyymecy -> DataMapInfo . mmi ) ,
"check_collision_with_bounding/To Line Segments3" , 3 , - 1 ) ; if ( (
rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) {
rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( ne0pyymecy ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( ne0pyymecy -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( ne0pyymecy ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_check_collision_with_bounding_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_to_line_segments_MdlInfoRegFcn ( mdlRefSfcnS , "to_line_segments" , retVal
) ; if ( * retVal == 0 ) return ; * retVal = 0 ; } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_check_collision_with_bounding , 45 ) ; * retVal = 1 ; } static void
mr_check_collision_with_bounding_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_check_collision_with_bounding_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_check_collision_with_bounding_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_check_collision_with_bounding_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_check_collision_with_bounding_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) ; static void
mr_check_collision_with_bounding_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i ,
j , mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_check_collision_with_bounding_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_check_collision_with_bounding_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_check_collision_with_bounding_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_check_collision_with_bounding_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_check_collision_with_bounding_restoreDataFromMxArrayWithOffset ( void
* destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_check_collision_with_bounding_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_check_collision_with_bounding_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void
mr_check_collision_with_bounding_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_check_collision_with_bounding_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) ; static uint_T
mr_check_collision_with_bounding_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) { const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray *
mr_check_collision_with_bounding_GetDWork ( const pwumfdjokh3 * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_check_collision_with_bounding_cacheDataAsMxArray ( ssDW , 0 , 0 , & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 8 ] = { "mdlrefDW->rtdw.blairxx1vj" ,
"mdlrefDW->rtdw.arprv3o2vz" , "mdlrefDW->rtdw.o30mbzurqt" ,
"mdlrefDW->rtdw.gc4fzs2b2z" , "mdlrefDW->rtdw.nujdfx1zvk" ,
"mdlrefDW->rtdw.dytv4pfvv3" , "mdlrefDW->rtdw.airptslae2" ,
"mdlrefDW->rtdw.a1rwb52k02" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 8 , rtdwDataFieldNames ) ; { mxArray * varData =
mr_to_line_segments_GetDWork ( & ( mdlrefDW -> rtdw . blairxx1vj ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } { mxArray * varData =
mr_to_line_segments_GetDWork ( & ( mdlrefDW -> rtdw . arprv3o2vz ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } { mxArray * varData =
mr_to_line_segments_GetDWork ( & ( mdlrefDW -> rtdw . o30mbzurqt ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 2 , varData ) ; } { mxArray * varData =
mr_to_line_segments_GetDWork ( & ( mdlrefDW -> rtdw . gc4fzs2b2z ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 3 , varData ) ; }
mr_check_collision_with_bounding_cacheDataAsMxArray ( rtdwData , 0 , 4 , & (
mdlrefDW -> rtdw . nujdfx1zvk ) , sizeof ( mdlrefDW -> rtdw . nujdfx1zvk ) )
; mr_check_collision_with_bounding_cacheDataAsMxArray ( rtdwData , 0 , 5 , &
( mdlrefDW -> rtdw . dytv4pfvv3 ) , sizeof ( mdlrefDW -> rtdw . dytv4pfvv3 )
) ; mr_check_collision_with_bounding_cacheDataAsMxArray ( rtdwData , 0 , 6 ,
& ( mdlrefDW -> rtdw . airptslae2 ) , sizeof ( mdlrefDW -> rtdw . airptslae2
) ) ; mr_check_collision_with_bounding_cacheDataAsMxArray ( rtdwData , 0 , 7
, & ( mdlrefDW -> rtdw . a1rwb52k02 ) , sizeof ( mdlrefDW -> rtdw .
a1rwb52k02 ) ) ; mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return
ssDW ; } void mr_check_collision_with_bounding_SetDWork ( pwumfdjokh3 *
mdlrefDW , const mxArray * ssDW ) {
mr_check_collision_with_bounding_restoreDataFromMxArray ( & ( mdlrefDW -> rtb
) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData
= mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_to_line_segments_SetDWork ( & (
mdlrefDW -> rtdw . blairxx1vj ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_to_line_segments_SetDWork ( & ( mdlrefDW -> rtdw . arprv3o2vz ) ,
mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ; mr_to_line_segments_SetDWork ( &
( mdlrefDW -> rtdw . o30mbzurqt ) , mxGetFieldByNumber ( rtdwData , 0 , 2 ) )
; mr_to_line_segments_SetDWork ( & ( mdlrefDW -> rtdw . gc4fzs2b2z ) ,
mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ;
mr_check_collision_with_bounding_restoreDataFromMxArray ( & ( mdlrefDW ->
rtdw . nujdfx1zvk ) , rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw .
nujdfx1zvk ) ) ; mr_check_collision_with_bounding_restoreDataFromMxArray ( &
( mdlrefDW -> rtdw . dytv4pfvv3 ) , rtdwData , 0 , 5 , sizeof ( mdlrefDW ->
rtdw . dytv4pfvv3 ) ) ;
mr_check_collision_with_bounding_restoreDataFromMxArray ( & ( mdlrefDW ->
rtdw . airptslae2 ) , rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw .
airptslae2 ) ) ; mr_check_collision_with_bounding_restoreDataFromMxArray ( &
( mdlrefDW -> rtdw . a1rwb52k02 ) , rtdwData , 0 , 7 , sizeof ( mdlrefDW ->
rtdw . a1rwb52k02 ) ) ; } } void
mr_check_collision_with_bounding_RegisterSimStateChecksum ( SimStruct * S ) {
const uint32_T chksum [ 4 ] = { 3730432822U , 3959980252U , 2832677739U ,
189444540U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"check_collision_with_bounding" , & chksum [ 0 ] ) ;
mr_to_line_segments_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_check_collision_with_bounding_GetSimStateDisallowedBlocks ( ) { return
mr_to_line_segments_GetSimStateDisallowedBlocks ( ) ; }
