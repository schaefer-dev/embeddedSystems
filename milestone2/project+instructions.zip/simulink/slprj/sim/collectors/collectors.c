#include "__cf_collectors.h"
#include "collectors_capi.h"
#include "collectors.h"
#include "collectors_private.h"
static RegMdlInfo rtMdlInfo_collectors [ 52 ] = { { "n2raavie0r3" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "collectors" } , {
"gqs0ayjk3c" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "hxzibpq3xb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "b55xret0yr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"ncpvkuj3c4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "b42hzqgmbd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "mpb5bxjcoe" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"d0biehg2q4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "b4ilaskio1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "g2rgo5hore" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"jma5b1bq35" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "hyovovrsd4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "nttibtfrmo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"ccpkj4xp2g" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "cqgnaoq3xv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "dn5sevcmw0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"pvemghshyv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "iqwtbjefxp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "lqizubt0d2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"ixdd0mmlc0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "kyhcohuznm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "a0x1yrikye" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"fskm0v2x2z" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "a4pd0ca5cg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "fpylj1em1k" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"collectors" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"lsbdz0hv01y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "iq4uc4y3utt" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "nde0m3q4p5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"kjxxnk0gmbw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "kkrjivjvzli" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "lsbdz0hv01" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"iq4uc4y3ut" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collectors" } , { "jfa1zfim0v" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "collectors" } , { "pdhslryz2b" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collectors" } , {
"kevw5qu2wxg" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"n1ljxg42ztp" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"ceyldc12a32" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_collectors_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "collectors" } , {
"mr_collectors_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "collectors" } , {
"mr_collectors_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "collectors" } , { "mr_collectors_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "collectors" } , { "mr_collectors_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "collectors" } , { "mr_collectors_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collectors" } , {
"mr_collectors_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collectors" } , { "collectors.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
NULL ) } , { "collectors.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"collectors" } } ; eqobxgoyezm eqobxgoyez = { 6.0 , 6.0 , 0.0 , 0.0 , 0.0 ,
180.0 , - 180.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , - 30.0 , 0.0 , 1.0 , 0.0 , 0.0 , 360.0 , 0.0 , 180.0
, 360.0 , 360.0 , 1.0 , 1.0 , 57.295779513082323 , 360.0 , 180.0 , - 1.0 ,
180.0 , 360.0 , 90.0 , - 90.0 , 1.0 , 30.0 , 0.0 , 0 , 0 } ; void a0x1yrikye
( hyovovrsd4 * localB , jma5b1bq35 * localDW , b42hzqgmbd * localX ) {
localDW -> cue4epbxs1 = eqobxgoyez . P_44 ; localDW -> neijca2aa0 =
eqobxgoyez . P_11 ; localDW -> c3kby1aas1 = eqobxgoyez . P_17 ; localDW ->
f5mq4pxf3g = eqobxgoyez . P_45 ; localDW -> l2uesssmqp = eqobxgoyez . P_24 ;
localDW -> oedmhddfuu = eqobxgoyez . P_25 ; gu4l3yxezw ( & localB ->
b01fd3houa ) ; gu4l3yxezw ( & localB -> pnrmy5pt0a ) ; localB -> ga3g0ygafw =
eqobxgoyez . P_2 ; k0ljbsbawd ( & ( localX -> mlafm4a2kv ) ) ; } void
kyhcohuznm ( jma5b1bq35 * localDW , b42hzqgmbd * localX ) { localDW ->
cue4epbxs1 = eqobxgoyez . P_44 ; localDW -> neijca2aa0 = eqobxgoyez . P_11 ;
localDW -> c3kby1aas1 = eqobxgoyez . P_17 ; localDW -> f5mq4pxf3g =
eqobxgoyez . P_45 ; localDW -> l2uesssmqp = eqobxgoyez . P_24 ; localDW ->
oedmhddfuu = eqobxgoyez . P_25 ; gcf02wcldj ( & ( localX -> mlafm4a2kv ) ) ;
} void dn5sevcmw0 ( jma5b1bq35 * localDW ) { k2z2rnpuwa ( & ( localDW ->
ndumhg2xop . rtdw ) ) ; k2z2rnpuwa ( & ( localDW -> pcu5iliyv2 . rtdw ) ) ;
if ( localDW -> hgxsmjezq5 ) { localDW -> hgxsmjezq5 = false ; } } void
a4pd0ca5cg ( pdhslryz2b * const npwdrebuui , jma5b1bq35 * localDW ) { localDW
-> pyv54bcszh = ( rtMinusInf ) ; localDW -> i2kfaargqy = true ; if ( (
ssGetSimMode ( npwdrebuui -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
npwdrebuui -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( npwdrebuui -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath
= sdiGetLabelFromChars ( "collectors/Enabled Subsystem2" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiDims forEachMdlRefDims ;
int_T forEachMdlRefDimsArray [ 32 ] ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncQueueHandle hForEachParent = ( NULL ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; if ( slIsRapidAcceleratorSimulating (
) ) { forEachMdlRefDims . nDims = 0 ; } else { forEachMdlRefDims . nDims =
slSigLogGetForEachDimsForRefModel ( npwdrebuui -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> cfwuamncbt . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , npwdrebuui -> DataMapInfo
. mmi . InstanceMap . fullPath , "111a9588-5480-41dc-8193-c88b7b51c771" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> cfwuamncbt . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> cfwuamncbt . AQHandles , "Continuous" , 0.0 , rtmGetTFinal ( npwdrebuui )
) ; sdiSetRunStartTime ( localDW -> cfwuamncbt . AQHandles , rtmGetTaskTime (
npwdrebuui , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
cfwuamncbt . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> cfwuamncbt . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> cfwuamncbt . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( npwdrebuui
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "" , "linear"
, 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "" , "Continuous" ,
0.0 , rtmGetTFinal ( npwdrebuui ) , treeVector ) ; } signalDescriptor =
rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 , "" , "" , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Enabled Subsystem2"
, 1 , 0 , slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Enabled Subsystem2"
, 1 , "" ) ; } if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) )
{ if ( npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) {
loggingInterval = rtliGetLoggingInterval ( npwdrebuui -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
npwdrebuui -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; localDW -> cfwuamncbt . SlioLTF = accessor ; } } } } if ( (
ssGetSimMode ( npwdrebuui -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
npwdrebuui -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( npwdrebuui -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName = sdiGetLabelFromChars (
"" ) ; sdiLabelU propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath
= sdiGetLabelFromChars ( "collectors/Model" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiDims forEachMdlRefDims ; int_T forEachMdlRefDimsArray
[ 32 ] ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncQueueHandle hForEachParent = ( NULL ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; if (
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDims . nDims = 0 ; } else
{ forEachMdlRefDims . nDims = slSigLogGetForEachDimsForRefModel ( npwdrebuui
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> a1ke0ybzoy . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , npwdrebuui -> DataMapInfo
. mmi . InstanceMap . fullPath , "bf553e74-3a0b-4562-af91-65dd275ef9ec" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> a1ke0ybzoy . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> a1ke0ybzoy . AQHandles , "Continuous" , 0.0 , rtmGetTFinal ( npwdrebuui )
) ; sdiSetRunStartTime ( localDW -> a1ke0ybzoy . AQHandles , rtmGetTaskTime (
npwdrebuui , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
a1ke0ybzoy . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> a1ke0ybzoy . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> a1ke0ybzoy . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( npwdrebuui
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "" , "linear"
, 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "" , "Continuous" ,
0.0 , rtmGetTFinal ( npwdrebuui ) , treeVector ) ; } signalDescriptor =
rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 , "" , "" , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 1 , "" ) ;
} if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if (
npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; localDW ->
a1ke0ybzoy . SlioLTF = accessor ; } } } } if ( ( ssGetSimMode ( npwdrebuui ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( npwdrebuui -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void *
slioCatalogue = rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr (
rt_slioCatalogue ( ) ) : sdiGetSlioCatalogue ( npwdrebuui -> DataMapInfo .
mmi . InstanceMap . fullPath ) ; if ( ! slioCatalogue || !
rtwDisableStreamingToRepository ( slioCatalogue ) ) { { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"collectors/Model" ) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ;
sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiDims
forEachMdlRefDims ; int_T forEachMdlRefDimsArray [ 32 ] ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncQueueHandle hForEachParent = ( NULL ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 1 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; if ( slIsRapidAcceleratorSimulating (
) ) { forEachMdlRefDims . nDims = 0 ; } else { forEachMdlRefDims . nDims =
slSigLogGetForEachDimsForRefModel ( npwdrebuui -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> kzdmj1p3ja . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , npwdrebuui -> DataMapInfo
. mmi . InstanceMap . fullPath , "e38a44f0-2295-451e-b76d-781c7336ce2e" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> kzdmj1p3ja . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> kzdmj1p3ja . AQHandles , "Continuous" , 0.0 , rtmGetTFinal ( npwdrebuui )
) ; sdiSetRunStartTime ( localDW -> kzdmj1p3ja . AQHandles , rtmGetTaskTime (
npwdrebuui , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
kzdmj1p3ja . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> kzdmj1p3ja . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> kzdmj1p3ja . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( npwdrebuui
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "" , "linear"
, 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "" , "Continuous" ,
0.0 , rtmGetTFinal ( npwdrebuui ) , treeVector ) ; } signalDescriptor =
rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 , "" , "" , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 2 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 2 , "" ) ;
} if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if (
npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; localDW ->
kzdmj1p3ja . SlioLTF = accessor ; } } } } if ( ( ssGetSimMode ( npwdrebuui ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( npwdrebuui -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void *
slioCatalogue = rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr (
rt_slioCatalogue ( ) ) : sdiGetSlioCatalogue ( npwdrebuui -> DataMapInfo .
mmi . InstanceMap . fullPath ) ; if ( ! slioCatalogue || !
rtwDisableStreamingToRepository ( slioCatalogue ) ) { { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"collectors/Model" ) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ;
sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiDims
forEachMdlRefDims ; int_T forEachMdlRefDimsArray [ 32 ] ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncQueueHandle hForEachParent = ( NULL ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 2 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; if ( slIsRapidAcceleratorSimulating (
) ) { forEachMdlRefDims . nDims = 0 ; } else { forEachMdlRefDims . nDims =
slSigLogGetForEachDimsForRefModel ( npwdrebuui -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } localDW -> j2jhbbnvxa . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , npwdrebuui -> DataMapInfo
. mmi . InstanceMap . fullPath , "7447807d-82dc-4247-8c42-ea194c2b3b09" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if (
localDW -> j2jhbbnvxa . AQHandles ) { sdiSetSignalSampleTimeString ( localDW
-> j2jhbbnvxa . AQHandles , "Continuous" , 0.0 , rtmGetTFinal ( npwdrebuui )
) ; sdiSetRunStartTime ( localDW -> j2jhbbnvxa . AQHandles , rtmGetTaskTime (
npwdrebuui , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings ( localDW ->
j2jhbbnvxa . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( localDW
-> j2jhbbnvxa . AQHandles , loggedName , origSigName , propName ) ; if (
forEachMdlRefDims . nDims > 0 ) { sdiAttachForEachIterationToParent (
hForEachParent , localDW -> j2jhbbnvxa . AQHandles , ( NULL ) ) ; if (
srcInfo . signalName != sigName ) { sdiFreeName ( srcInfo . signalName ) ; }
} } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } } { void *
treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const void *
signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char *
datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue && rtwIsLoggingToFile
( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ] ; int_T
forEachMdlRefDimsArraySize = 0 ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ forEachMdlRefDimsArraySize = slSigLogGetForEachDimsForRefModel ( npwdrebuui
-> _mdlRefSfcnS , forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector
( ) ; { int_T sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "" , "linear"
, 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "" , "Continuous" ,
0.0 , rtmGetTFinal ( npwdrebuui ) , treeVector ) ; } signalDescriptor =
rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 , "" , "" , npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 3 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath , "collectors/Model" , 3 , "" ) ;
} if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if (
npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( npwdrebuui -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( npwdrebuui ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; localDW ->
j2jhbbnvxa . SlioLTF = accessor ; } } } } } void collectors ( pdhslryz2b *
const npwdrebuui , const real_T * fk2c0ccj2c , const real_T * btvo5en4ud ,
const boolean_T * iotnreyvax , const real_T * dz1jubqcyh , const real_T *
ef3k1j1yal , const real_T * k45bautdum , const real_T * mxofui1bba , const
real_T * hkwpse42jr , const real_T * dvjucuzzmu , real_T * d4huorahpr ,
real_T * anibmz4x0j , real_T * hnta3h5b0t , real_T * cyxhubwqby , real_T *
nsorbwa4pw , real_T * k2du1qrl5u , real_T * a1bh0yxhhi , hyovovrsd4 * localB
, jma5b1bq35 * localDW , b42hzqgmbd * localX ) { real_T jyb5qsrxtl ; real_T
kk2cgjsngi ; boolean_T lagmnq01wn ; real_T pvjow40bo2_p ; real_T nfzj0pl5cr_p
; real_T jdqalid4ce_p ; if ( rtmIsMajorTimeStep ( npwdrebuui ) &&
rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { if ( localDW -> cue4epbxs1 ) {
localB -> pdc0nmj4hf = eqobxgoyez . P_8 ; } else { localB -> pdc0nmj4hf =
eqobxgoyez . P_9 ; } localB -> hngyfvqpgw = localDW -> neijca2aa0 ; } if (
localB -> hngyfvqpgw > eqobxgoyez . P_12 ) { localB -> ozn2fano21 = *
btvo5en4ud + eqobxgoyez . P_10 ; } else { localB -> ozn2fano21 = * ef3k1j1yal
; } enable_hold ( & ( localDW -> ndumhg2xop . rtm ) , & localB -> ozn2fano21
, & eqobxgoyez . P_13 , & localB -> b01fd3houa , & ( localDW -> ndumhg2xop .
rtb ) , & ( localDW -> ndumhg2xop . rtdw ) ) ; if ( localB -> pdc0nmj4hf >
eqobxgoyez . P_14 ) { localB -> diaxldekhu = eqobxgoyez . P_7 ; } else {
localB -> diaxldekhu = localB -> b01fd3houa ; } * nsorbwa4pw =
muDoubleScalarCeil ( localB -> diaxldekhu ) ; if ( rtmIsMajorTimeStep (
npwdrebuui ) && rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { localB ->
gogt1d2csu = localDW -> c3kby1aas1 ; } if ( localB -> gogt1d2csu > eqobxgoyez
. P_18 ) { localB -> h4ffw12002 = * fk2c0ccj2c + eqobxgoyez . P_16 ; } else {
localB -> h4ffw12002 = * dz1jubqcyh ; } enable_hold ( & ( localDW ->
pcu5iliyv2 . rtm ) , & localB -> h4ffw12002 , & eqobxgoyez . P_19 , & localB
-> pnrmy5pt0a , & ( localDW -> pcu5iliyv2 . rtb ) , & ( localDW -> pcu5iliyv2
. rtdw ) ) ; if ( localB -> pdc0nmj4hf > eqobxgoyez . P_20 ) { localB ->
oktwnaytk1 = eqobxgoyez . P_15 ; } else { localB -> oktwnaytk1 = localB ->
pnrmy5pt0a ; } * cyxhubwqby = muDoubleScalarCeil ( localB -> oktwnaytk1 ) ;
localB -> lhpteadr0x = rtmGetTaskTime ( npwdrebuui , 0 ) ; jdqalid4ce_p =
rtmGetTaskTime ( npwdrebuui , 0 ) ; if ( ( localDW -> pyv54bcszh == (
rtMinusInf ) ) || ( localDW -> pyv54bcszh == jdqalid4ce_p ) ) { localDW ->
pyv54bcszh = jdqalid4ce_p ; jyb5qsrxtl = eqobxgoyez . P_21 ; } else {
jyb5qsrxtl = localB -> lhpteadr0x ; } if ( rtmIsMajorTimeStep ( npwdrebuui )
&& rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { if ( localDW -> i2kfaargqy ) {
localDW -> i2kfaargqy = false ; pvjow40bo2_p = eqobxgoyez . P_23 ; } else if
( localDW -> f5mq4pxf3g ) { pvjow40bo2_p = eqobxgoyez . P_22 ; } else {
pvjow40bo2_p = * iotnreyvax ; } if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { if
( pvjow40bo2_p > 0.0 ) { if ( ! localDW -> hgxsmjezq5 ) { if ( rtmGetTaskTime
( npwdrebuui , 1 ) != rtmGetTStart ( npwdrebuui ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( npwdrebuui -> _mdlRefSfcnS ) ; }
localDW -> hgxsmjezq5 = true ; } } else { if ( localDW -> hgxsmjezq5 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( npwdrebuui -> _mdlRefSfcnS ) ;
localDW -> hgxsmjezq5 = false ; } } } } if ( localDW -> hgxsmjezq5 ) { localB
-> ga3g0ygafw = jyb5qsrxtl ; if ( rtmIsMajorTimeStep ( npwdrebuui ) ) {
srUpdateBC ( localDW -> kpdlqt3sqz ) ; } } { if ( ( localDW -> cfwuamncbt .
AQHandles || localDW -> cfwuamncbt . SlioLTF ) && ssGetLogOutput ( npwdrebuui
-> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> cfwuamncbt .
AQHandles , localDW -> cfwuamncbt . SlioLTF , 0 , rtmGetTaskTime ( npwdrebuui
, 0 ) , ( void * ) & localB -> ga3g0ygafw ) ; } } if ( rtmIsMajorTimeStep (
npwdrebuui ) && rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { localB ->
bo3yk1zi4u = localDW -> l2uesssmqp ; localB -> izkax3ozd2 = localDW ->
oedmhddfuu ; } differential_drive ( & ( localDW -> kfqrefdtma . rtm ) , &
localB -> bo3yk1zi4u , & localB -> izkax3ozd2 , k45bautdum , mxofui1bba ,
hkwpse42jr , dvjucuzzmu , d4huorahpr , anibmz4x0j , hnta3h5b0t , & ( localDW
-> kfqrefdtma . rtb ) , & ( localX -> mlafm4a2kv ) , & ( localDW ->
kfqrefdtma . rtzce ) ) ; { if ( ( localDW -> a1ke0ybzoy . AQHandles ||
localDW -> a1ke0ybzoy . SlioLTF ) && ssGetLogOutput ( npwdrebuui ->
_mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> a1ke0ybzoy . AQHandles
, localDW -> a1ke0ybzoy . SlioLTF , 0 , rtmGetTaskTime ( npwdrebuui , 0 ) , (
void * ) d4huorahpr ) ; } } { if ( ( localDW -> kzdmj1p3ja . AQHandles ||
localDW -> kzdmj1p3ja . SlioLTF ) && ssGetLogOutput ( npwdrebuui ->
_mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> kzdmj1p3ja . AQHandles
, localDW -> kzdmj1p3ja . SlioLTF , 0 , rtmGetTaskTime ( npwdrebuui , 0 ) , (
void * ) anibmz4x0j ) ; } } { if ( ( localDW -> j2jhbbnvxa . AQHandles ||
localDW -> j2jhbbnvxa . SlioLTF ) && ssGetLogOutput ( npwdrebuui ->
_mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( localDW -> j2jhbbnvxa . AQHandles
, localDW -> j2jhbbnvxa . SlioLTF , 0 , rtmGetTaskTime ( npwdrebuui , 0 ) , (
void * ) hnta3h5b0t ) ; } } jyb5qsrxtl = muDoubleScalarCeil ( * d4huorahpr )
; localB -> dgvdxeiddq = * cyxhubwqby - jyb5qsrxtl ; pvjow40bo2_p =
muDoubleScalarCeil ( * anibmz4x0j ) ; jdqalid4ce_p = * nsorbwa4pw -
pvjow40bo2_p ; if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { localDW ->
odyseg1rwq = ( localB -> dgvdxeiddq >= 0.0 ) ; } nfzj0pl5cr_p = localDW ->
odyseg1rwq > 0 ? localB -> dgvdxeiddq : - localB -> dgvdxeiddq ; if (
nfzj0pl5cr_p > eqobxgoyez . P_32 ) { kk2cgjsngi = localB -> dgvdxeiddq ; }
else { kk2cgjsngi = eqobxgoyez . P_31 ; } kk2cgjsngi = muDoubleScalarMod (
muDoubleScalarAtan ( jdqalid4ce_p / kk2cgjsngi ) * eqobxgoyez . P_33 ,
eqobxgoyez . P_34 ) ; if ( kk2cgjsngi > eqobxgoyez . P_35 ) { kk2cgjsngi -=
eqobxgoyez . P_30 ; } localB -> pydz3y3yv5 = eqobxgoyez . P_36 * kk2cgjsngi ;
if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { localDW -> dlwhmkwakq = ( localB
-> pydz3y3yv5 > eqobxgoyez . P_37 ) ; } if ( localDW -> dlwhmkwakq ) {
kk2cgjsngi += eqobxgoyez . P_29 ; } if ( nfzj0pl5cr_p > eqobxgoyez . P_41 ) {
if ( localB -> dgvdxeiddq >= eqobxgoyez . P_4 ) { jdqalid4ce_p = eqobxgoyez .
P_27 ; } else { jdqalid4ce_p = eqobxgoyez . P_28 ; } jdqalid4ce_p +=
kk2cgjsngi ; if ( jdqalid4ce_p > eqobxgoyez . P_5 ) { jdqalid4ce_p -=
eqobxgoyez . P_26 ; } if ( jdqalid4ce_p >= eqobxgoyez . P_6 ) { localB ->
gsyfdaw4em = jdqalid4ce_p ; } else { localB -> gsyfdaw4em = eqobxgoyez . P_38
- jdqalid4ce_p ; } } else if ( jdqalid4ce_p > eqobxgoyez . P_3 ) { localB ->
gsyfdaw4em = eqobxgoyez . P_39 ; } else { localB -> gsyfdaw4em = eqobxgoyez .
P_40 ; } localB -> bj3y0ixfut = localB -> ga3g0ygafw + eqobxgoyez . P_42 ; if
( rtmIsMajorTimeStep ( npwdrebuui ) && rtmIsSampleHit ( npwdrebuui , 1 , 0 )
) { if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { localDW -> goc2stz4xv = (
localB -> bj3y0ixfut > localB -> lhpteadr0x ) ; } localB -> n3ue5eu4ae =
localDW -> goc2stz4xv ; } localB -> amefm4tzmg = jyb5qsrxtl - * cyxhubwqby ;
if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { localDW -> dkvmcj4vbo = ( localB
-> amefm4tzmg >= 0.0 ) ; } localB -> dobjugjpu2 = localDW -> dkvmcj4vbo > 0 ?
localB -> amefm4tzmg : - localB -> amefm4tzmg ; if ( rtmIsMajorTimeStep (
npwdrebuui ) && rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { if (
rtmIsMajorTimeStep ( npwdrebuui ) ) { localDW -> kyrqx4vhbt = ( localB ->
dobjugjpu2 <= eqobxgoyez . P_0 ) ; } lagmnq01wn = localDW -> kyrqx4vhbt ; }
localB -> l11apivhsv = pvjow40bo2_p - * nsorbwa4pw ; if ( rtmIsMajorTimeStep
( npwdrebuui ) ) { localDW -> ph53rkyasy = ( localB -> l11apivhsv >= 0.0 ) ;
} localB -> gdr2ioefwl = localDW -> ph53rkyasy > 0 ? localB -> l11apivhsv : -
localB -> l11apivhsv ; if ( rtmIsMajorTimeStep ( npwdrebuui ) &&
rtmIsSampleHit ( npwdrebuui , 1 , 0 ) ) { if ( rtmIsMajorTimeStep (
npwdrebuui ) ) { localDW -> j4xzkmpvu5 = ( localB -> gdr2ioefwl <= eqobxgoyez
. P_1 ) ; } localB -> lu1gaeouvr = ( lagmnq01wn && localDW -> j4xzkmpvu5 ) ;
} theta_correction ( & ( localDW -> g0r4ymcmco . rtm ) , hnta3h5b0t , &
localB -> gsyfdaw4em , & localB -> ngiofh2aao , & localB -> nut0um4ywp , & (
localDW -> g0r4ymcmco . rtb ) , & ( localDW -> g0r4ymcmco . rtdw ) ) ; if (
localB -> n3ue5eu4ae ) { * k2du1qrl5u = eqobxgoyez . P_43 ; * a1bh0yxhhi =
eqobxgoyez . P_43 ; } else { * k2du1qrl5u = localB -> ngiofh2aao ; *
a1bh0yxhhi = localB -> nut0um4ywp ; } } void collectorsTID2 ( jma5b1bq35 *
localDW ) { enable_holdTID2 ( ) ; enable_holdTID2 ( ) ;
differential_driveTID1 ( & ( localDW -> kfqrefdtma . rtb ) ) ;
theta_correctionTID1 ( ) ; } void ixdd0mmlc0 ( pdhslryz2b * const npwdrebuui
, real_T * k2du1qrl5u , real_T * a1bh0yxhhi , hyovovrsd4 * localB ,
jma5b1bq35 * localDW ) { if ( rtmIsMajorTimeStep ( npwdrebuui ) ) { if (
memcmp ( npwdrebuui -> nonContDerivSignal [ 0 ] . pCurrVal , npwdrebuui ->
nonContDerivSignal [ 0 ] . pPrevVal , npwdrebuui -> nonContDerivSignal [ 0 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( npwdrebuui -> nonContDerivSignal [
0 ] . pPrevVal , npwdrebuui -> nonContDerivSignal [ 0 ] . pCurrVal ,
npwdrebuui -> nonContDerivSignal [ 0 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( npwdrebuui -> _mdlRefSfcnS ) ; } if ( memcmp (
npwdrebuui -> nonContDerivSignal [ 1 ] . pCurrVal , npwdrebuui ->
nonContDerivSignal [ 1 ] . pPrevVal , npwdrebuui -> nonContDerivSignal [ 1 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( npwdrebuui -> nonContDerivSignal [
1 ] . pPrevVal , npwdrebuui -> nonContDerivSignal [ 1 ] . pCurrVal ,
npwdrebuui -> nonContDerivSignal [ 1 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( npwdrebuui -> _mdlRefSfcnS ) ; } } if (
rtmIsMajorTimeStep ( npwdrebuui ) && rtmIsSampleHit ( npwdrebuui , 1 , 0 ) )
{ localDW -> cue4epbxs1 = localB -> lu1gaeouvr ; localDW -> neijca2aa0 =
localB -> diaxldekhu ; localDW -> c3kby1aas1 = localB -> oktwnaytk1 ; localDW
-> f5mq4pxf3g = localB -> n3ue5eu4ae ; localDW -> l2uesssmqp = * k2du1qrl5u ;
localDW -> oedmhddfuu = * a1bh0yxhhi ; } a0atpmh4a1 ( ) ; } void
ixdd0mmlc0TID2 ( void ) { } void lqizubt0d2 ( jma5b1bq35 * localDW ,
ncpvkuj3c4 * localXdot ) { mjzcgvjfr5 ( & ( localDW -> kfqrefdtma . rtb ) , &
( localXdot -> mlafm4a2kv ) ) ; } void iqwtbjefxp ( const real_T * dvjucuzzmu
, hyovovrsd4 * localB , jma5b1bq35 * localDW , gqs0ayjk3c * localZCSV ) {
o0iyk4gijb ( & localB -> ozn2fano21 , & ( localDW -> ndumhg2xop . rtb ) , & (
localDW -> ndumhg2xop . rtdw ) , & ( localZCSV -> lhktdszytm ) ) ; o0iyk4gijb
( & localB -> h4ffw12002 , & ( localDW -> pcu5iliyv2 . rtb ) , & ( localDW ->
pcu5iliyv2 . rtdw ) , & ( localZCSV -> kpxvmmdk2t ) ) ; h5vubb4liy (
dvjucuzzmu , & ( localZCSV -> a25f4a5nee ) ) ; localZCSV -> oz2vdctrir =
localB -> dgvdxeiddq ; localZCSV -> a3mmezjzek = localB -> pydz3y3yv5 -
eqobxgoyez . P_37 ; localZCSV -> fnooglxgja = localB -> bj3y0ixfut - localB
-> lhpteadr0x ; localZCSV -> fpvzakf51m = localB -> amefm4tzmg ; localZCSV ->
fwxu1jsfre = localB -> dobjugjpu2 - eqobxgoyez . P_0 ; localZCSV ->
ii2bzafydq = localB -> l11apivhsv ; localZCSV -> l3tf2z02z5 = localB ->
gdr2ioefwl - eqobxgoyez . P_1 ; pdvunnwa5j ( & ( localDW -> g0r4ymcmco . rtb
) , & ( localZCSV -> nh0mog2na5 ) ) ; } void ccpkj4xp2g ( pdhslryz2b * const
npwdrebuui , jma5b1bq35 * localDW ) { j4sttxvfh0 ( & ( localDW -> ndumhg2xop
. rtm ) ) ; j4sttxvfh0 ( & ( localDW -> pcu5iliyv2 . rtm ) ) ; if ( (
ssGetSimMode ( npwdrebuui -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
npwdrebuui -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> cfwuamncbt .
AQHandles ) { sdiTerminateStreaming ( & localDW -> cfwuamncbt . AQHandles ) ;
} if ( localDW -> cfwuamncbt . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> cfwuamncbt . SlioLTF ) ; } } bfhsp2jlnv ( & ( localDW ->
kfqrefdtma . rtm ) ) ; if ( ( ssGetSimMode ( npwdrebuui -> _mdlRefSfcnS ) !=
SS_SIMMODE_EXTERNAL ) && ( ( npwdrebuui -> _mdlRefSfcnS ) -> mdlInfo ->
rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW ->
a1ke0ybzoy . AQHandles ) { sdiTerminateStreaming ( & localDW -> a1ke0ybzoy .
AQHandles ) ; } if ( localDW -> a1ke0ybzoy . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> a1ke0ybzoy . SlioLTF ) ; } } if ( (
ssGetSimMode ( npwdrebuui -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( (
npwdrebuui -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( localDW -> kzdmj1p3ja .
AQHandles ) { sdiTerminateStreaming ( & localDW -> kzdmj1p3ja . AQHandles ) ;
} if ( localDW -> kzdmj1p3ja . SlioLTF ) { rtwDestructAccessorPointer (
localDW -> kzdmj1p3ja . SlioLTF ) ; } } if ( ( ssGetSimMode ( npwdrebuui ->
_mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( npwdrebuui -> _mdlRefSfcnS )
-> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
localDW -> j2jhbbnvxa . AQHandles ) { sdiTerminateStreaming ( & localDW ->
j2jhbbnvxa . AQHandles ) ; } if ( localDW -> j2jhbbnvxa . SlioLTF ) {
rtwDestructAccessorPointer ( localDW -> j2jhbbnvxa . SlioLTF ) ; } }
bwb4mgvz4x ( & ( localDW -> g0r4ymcmco . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( npwdrebuui ->
_mdlRefSfcnS , "collectors" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" )
; } } void fskm0v2x2z ( SimStruct * _mdlRefSfcnS ,
ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray , int_T
mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , pdhslryz2b * const
npwdrebuui , hyovovrsd4 * localB , jma5b1bq35 * localDW , b42hzqgmbd * localX
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( ( void * )
npwdrebuui , 0 , sizeof ( pdhslryz2b ) ) ; npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; npwdrebuui -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; npwdrebuui -> Timing .
mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; npwdrebuui -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( npwdrebuui -> _mdlRefSfcnS , "collectors" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) localB ) , 0 , sizeof ( hyovovrsd4 ) ) ; { localB -> pdc0nmj4hf = 0.0 ;
localB -> hngyfvqpgw = 0.0 ; localB -> ozn2fano21 = 0.0 ; localB ->
b01fd3houa = 0.0 ; localB -> diaxldekhu = 0.0 ; localB -> gogt1d2csu = 0.0 ;
localB -> h4ffw12002 = 0.0 ; localB -> pnrmy5pt0a = 0.0 ; localB ->
oktwnaytk1 = 0.0 ; localB -> lhpteadr0x = 0.0 ; localB -> bo3yk1zi4u = 0.0 ;
localB -> izkax3ozd2 = 0.0 ; localB -> dgvdxeiddq = 0.0 ; localB ->
pydz3y3yv5 = 0.0 ; localB -> gsyfdaw4em = 0.0 ; localB -> bj3y0ixfut = 0.0 ;
localB -> amefm4tzmg = 0.0 ; localB -> dobjugjpu2 = 0.0 ; localB ->
l11apivhsv = 0.0 ; localB -> gdr2ioefwl = 0.0 ; localB -> ngiofh2aao = 0.0 ;
localB -> nut0um4ywp = 0.0 ; localB -> ga3g0ygafw = 0.0 ; } ( void ) memset (
( void * ) localDW , 0 , sizeof ( jma5b1bq35 ) ) ; localDW -> neijca2aa0 =
0.0 ; localDW -> c3kby1aas1 = 0.0 ; localDW -> pyv54bcszh = 0.0 ; localDW ->
l2uesssmqp = 0.0 ; localDW -> oedmhddfuu = 0.0 ;
collectors_InitializeDataMapInfo ( npwdrebuui , localDW , sysRanPtr ,
contextTid ) ; mn0c0dajpf ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID2 , & (
localDW -> kfqrefdtma . rtm ) , & ( localDW -> kfqrefdtma . rtb ) , & (
localX -> mlafm4a2kv ) , & ( localDW -> kfqrefdtma . rtzce ) , npwdrebuui ->
DataMapInfo . systemRan [ 0 ] , npwdrebuui -> DataMapInfo . systemTid [ 0 ] ,
& ( npwdrebuui -> DataMapInfo . mmi ) , "collectors/Model" , 0 , 0 ) ;
k1bgzwznlm ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , mdlref_TID2 , & (
localDW -> ndumhg2xop . rtm ) , & ( localDW -> ndumhg2xop . rtb ) , & (
localDW -> ndumhg2xop . rtdw ) , npwdrebuui -> DataMapInfo . systemRan [ 0 ]
, npwdrebuui -> DataMapInfo . systemTid [ 0 ] , & ( npwdrebuui -> DataMapInfo
. mmi ) , "collectors/Model1" , 1 , - 1 ) ; k1bgzwznlm ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , mdlref_TID2 , & ( localDW -> pcu5iliyv2 . rtm ) ,
& ( localDW -> pcu5iliyv2 . rtb ) , & ( localDW -> pcu5iliyv2 . rtdw ) ,
npwdrebuui -> DataMapInfo . systemRan [ 0 ] , npwdrebuui -> DataMapInfo .
systemTid [ 0 ] , & ( npwdrebuui -> DataMapInfo . mmi ) , "collectors/Model2"
, 2 , - 1 ) ; pckfge0fgo ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID2 , & (
localDW -> g0r4ymcmco . rtm ) , & ( localDW -> g0r4ymcmco . rtb ) , & (
localDW -> g0r4ymcmco . rtdw ) , npwdrebuui -> DataMapInfo . systemRan [ 0 ]
, npwdrebuui -> DataMapInfo . systemTid [ 0 ] , & ( npwdrebuui -> DataMapInfo
. mmi ) , "collectors/Model3" , 3 , - 1 ) ; if ( ( rt_ParentMMI != ( NULL ) )
&& ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( npwdrebuui -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
npwdrebuui -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( npwdrebuui -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } npwdrebuui -> nonContDerivSignal [ 0 ] . pPrevVal = (
char_T * ) npwdrebuui -> NonContDerivMemory . mr_nonContSig0 ; npwdrebuui ->
nonContDerivSignal [ 0 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
npwdrebuui -> nonContDerivSignal [ 0 ] . pCurrVal = ( char_T * ) ( & localB
-> izkax3ozd2 ) ; ; npwdrebuui -> nonContDerivSignal [ 1 ] . pPrevVal = (
char_T * ) npwdrebuui -> NonContDerivMemory . mr_nonContSig1 ; npwdrebuui ->
nonContDerivSignal [ 1 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
npwdrebuui -> nonContDerivSignal [ 1 ] . pCurrVal = ( char_T * ) ( & localB
-> bo3yk1zi4u ) ; ; if ( mr_nonContOutputArray [ 0 ] != ( NULL ) ) {
mr_nonContOutputArray [ 0 ] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 0 ] [ 0 ] . currVal = ( char_T * ) & localB ->
izkax3ozd2 ; mr_nonContOutputArray [ 0 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 0 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 0 ] != (
NULL ) ) { mr_nonContOutputArray [ 0 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 0 ] [ 1 ] . currVal = ( char_T * ) &
localB -> bo3yk1zi4u ; mr_nonContOutputArray [ 0 ] [ 1 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 1 ] != ( NULL ) ) { mr_nonContOutputArray [ 1
] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ; mr_nonContOutputArray [ 1 ] [
0 ] . currVal = ( char_T * ) & localB -> izkax3ozd2 ; mr_nonContOutputArray [
1 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 1 ] [ 1 ] ) ; } if (
mr_nonContOutputArray [ 1 ] != ( NULL ) ) { mr_nonContOutputArray [ 1 ] [ 1 ]
. sizeInBytes = 1 * sizeof ( real_T ) ; mr_nonContOutputArray [ 1 ] [ 1 ] .
currVal = ( char_T * ) & localB -> bo3yk1zi4u ; mr_nonContOutputArray [ 1 ] [
1 ] . next = ( NULL ) ; } if ( mr_nonContOutputArray [ 2 ] != ( NULL ) ) {
mr_nonContOutputArray [ 2 ] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 2 ] [ 0 ] . currVal = ( char_T * ) & localB ->
izkax3ozd2 ; mr_nonContOutputArray [ 2 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 2 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 2 ] != (
NULL ) ) { mr_nonContOutputArray [ 2 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 2 ] [ 1 ] . currVal = ( char_T * ) &
localB -> bo3yk1zi4u ; mr_nonContOutputArray [ 2 ] [ 1 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 3 ] != ( NULL ) ) { mr_nonContOutputArray [ 3
] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ; mr_nonContOutputArray [ 3 ] [
0 ] . currVal = ( char_T * ) & localB -> gogt1d2csu ; mr_nonContOutputArray [
3 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 3 ] [ 1 ] ) ; } if (
mr_nonContOutputArray [ 3 ] != ( NULL ) ) { mr_nonContOutputArray [ 3 ] [ 1 ]
. sizeInBytes = 1 * sizeof ( real_T ) ; mr_nonContOutputArray [ 3 ] [ 1 ] .
currVal = ( char_T * ) & localB -> pdc0nmj4hf ; mr_nonContOutputArray [ 3 ] [
1 ] . next = ( NULL ) ; } if ( mr_nonContOutputArray [ 4 ] != ( NULL ) ) {
mr_nonContOutputArray [ 4 ] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 4 ] [ 0 ] . currVal = ( char_T * ) & localB ->
hngyfvqpgw ; mr_nonContOutputArray [ 4 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 4 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 4 ] != (
NULL ) ) { mr_nonContOutputArray [ 4 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 4 ] [ 1 ] . currVal = ( char_T * ) &
localB -> pdc0nmj4hf ; mr_nonContOutputArray [ 4 ] [ 1 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 5 ] != ( NULL ) ) { mr_nonContOutputArray [ 5
] [ 0 ] . sizeInBytes = 1 * sizeof ( boolean_T ) ; mr_nonContOutputArray [ 5
] [ 0 ] . currVal = ( char_T * ) & localB -> n3ue5eu4ae ;
mr_nonContOutputArray [ 5 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 5 ] [
1 ] ) ; } if ( mr_nonContOutputArray [ 5 ] != ( NULL ) ) {
mr_nonContOutputArray [ 5 ] [ 1 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 5 ] [ 1 ] . currVal = ( char_T * ) & localB ->
izkax3ozd2 ; mr_nonContOutputArray [ 5 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 5 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 5 ] != (
NULL ) ) { mr_nonContOutputArray [ 5 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 5 ] [ 2 ] . currVal = ( char_T * ) &
localB -> bo3yk1zi4u ; mr_nonContOutputArray [ 5 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 5 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 5 ] != (
NULL ) ) { mr_nonContOutputArray [ 5 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 5 ] [ 3 ] . currVal = ( char_T * ) &
localB -> gogt1d2csu ; mr_nonContOutputArray [ 5 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 5 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 5 ] != (
NULL ) ) { mr_nonContOutputArray [ 5 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 5 ] [ 4 ] . currVal = ( char_T * ) &
localB -> hngyfvqpgw ; mr_nonContOutputArray [ 5 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 5 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 5 ] != (
NULL ) ) { mr_nonContOutputArray [ 5 ] [ 5 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 5 ] [ 5 ] . currVal = ( char_T * ) &
localB -> pdc0nmj4hf ; mr_nonContOutputArray [ 5 ] [ 5 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 6 ] != ( NULL ) ) { mr_nonContOutputArray [ 6
] [ 0 ] . sizeInBytes = 1 * sizeof ( boolean_T ) ; mr_nonContOutputArray [ 6
] [ 0 ] . currVal = ( char_T * ) & localB -> n3ue5eu4ae ;
mr_nonContOutputArray [ 6 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 6 ] [
1 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != ( NULL ) ) {
mr_nonContOutputArray [ 6 ] [ 1 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 6 ] [ 1 ] . currVal = ( char_T * ) & localB ->
izkax3ozd2 ; mr_nonContOutputArray [ 6 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 2 ] . currVal = ( char_T * ) &
localB -> bo3yk1zi4u ; mr_nonContOutputArray [ 6 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 3 ] . currVal = ( char_T * ) &
localB -> gogt1d2csu ; mr_nonContOutputArray [ 6 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 4 ] . currVal = ( char_T * ) &
localB -> hngyfvqpgw ; mr_nonContOutputArray [ 6 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 5 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 5 ] . currVal = ( char_T * ) &
localB -> pdc0nmj4hf ; mr_nonContOutputArray [ 6 ] [ 5 ] . next = ( NULL ) ;
} } void mr_collectors_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { mr_differential_drive_MdlInfoRegFcn (
mdlRefSfcnS , "differential_drive" , retVal ) ; if ( * retVal == 0 ) return ;
* retVal = 0 ; mr_enable_hold_MdlInfoRegFcn ( mdlRefSfcnS , "enable_hold" ,
retVal ) ; if ( * retVal == 0 ) return ; * retVal = 0 ;
mr_theta_correction_MdlInfoRegFcn ( mdlRefSfcnS , "theta_correction" , retVal
) ; if ( * retVal == 0 ) return ; * retVal = 0 ; } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName , rtMdlInfo_collectors , 52 )
; * retVal = 1 ; } static void mr_collectors_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_collectors_cacheDataAsMxArray ( mxArray * destArray , mwIndex
i , int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_collectors_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_collectors_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_collectors_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_collectors_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int
j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_collectors_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_collectors_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_collectors_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_collectors_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_collectors_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_collectors_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_collectors_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_collectors_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_collectors_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_collectors_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_collectors_GetDWork ( const n2raavie0r3 * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_collectors_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 21
] = { "mdlrefDW->rtdw.ndumhg2xop" , "mdlrefDW->rtdw.pcu5iliyv2" ,
"mdlrefDW->rtdw.kfqrefdtma" , "mdlrefDW->rtdw.g0r4ymcmco" ,
"mdlrefDW->rtdw.neijca2aa0" , "mdlrefDW->rtdw.c3kby1aas1" ,
"mdlrefDW->rtdw.pyv54bcszh" , "mdlrefDW->rtdw.l2uesssmqp" ,
"mdlrefDW->rtdw.oedmhddfuu" , "mdlrefDW->rtdw.odyseg1rwq" ,
"mdlrefDW->rtdw.dkvmcj4vbo" , "mdlrefDW->rtdw.ph53rkyasy" ,
"mdlrefDW->rtdw.kpdlqt3sqz" , "mdlrefDW->rtdw.cue4epbxs1" ,
"mdlrefDW->rtdw.f5mq4pxf3g" , "mdlrefDW->rtdw.i2kfaargqy" ,
"mdlrefDW->rtdw.dlwhmkwakq" , "mdlrefDW->rtdw.goc2stz4xv" ,
"mdlrefDW->rtdw.kyrqx4vhbt" , "mdlrefDW->rtdw.j4xzkmpvu5" ,
"mdlrefDW->rtdw.hgxsmjezq5" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 21 , rtdwDataFieldNames ) ; { mxArray * varData =
mr_enable_hold_GetDWork ( & ( mdlrefDW -> rtdw . ndumhg2xop ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } { mxArray * varData =
mr_enable_hold_GetDWork ( & ( mdlrefDW -> rtdw . pcu5iliyv2 ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } { mxArray * varData =
mr_differential_drive_GetDWork ( & ( mdlrefDW -> rtdw . kfqrefdtma ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 2 , varData ) ; } { mxArray * varData =
mr_theta_correction_GetDWork ( & ( mdlrefDW -> rtdw . g0r4ymcmco ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 3 , varData ) ; }
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( mdlrefDW -> rtdw .
neijca2aa0 ) , sizeof ( mdlrefDW -> rtdw . neijca2aa0 ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( mdlrefDW -> rtdw .
c3kby1aas1 ) , sizeof ( mdlrefDW -> rtdw . c3kby1aas1 ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( mdlrefDW -> rtdw .
pyv54bcszh ) , sizeof ( mdlrefDW -> rtdw . pyv54bcszh ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( mdlrefDW -> rtdw .
l2uesssmqp ) , sizeof ( mdlrefDW -> rtdw . l2uesssmqp ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( mdlrefDW -> rtdw .
oedmhddfuu ) , sizeof ( mdlrefDW -> rtdw . oedmhddfuu ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( mdlrefDW -> rtdw .
odyseg1rwq ) , sizeof ( mdlrefDW -> rtdw . odyseg1rwq ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( mdlrefDW -> rtdw .
dkvmcj4vbo ) , sizeof ( mdlrefDW -> rtdw . dkvmcj4vbo ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( mdlrefDW -> rtdw .
ph53rkyasy ) , sizeof ( mdlrefDW -> rtdw . ph53rkyasy ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( mdlrefDW -> rtdw .
kpdlqt3sqz ) , sizeof ( mdlrefDW -> rtdw . kpdlqt3sqz ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( mdlrefDW -> rtdw .
cue4epbxs1 ) , sizeof ( mdlrefDW -> rtdw . cue4epbxs1 ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 14 , & ( mdlrefDW -> rtdw .
f5mq4pxf3g ) , sizeof ( mdlrefDW -> rtdw . f5mq4pxf3g ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 15 , & ( mdlrefDW -> rtdw .
i2kfaargqy ) , sizeof ( mdlrefDW -> rtdw . i2kfaargqy ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 16 , & ( mdlrefDW -> rtdw .
dlwhmkwakq ) , sizeof ( mdlrefDW -> rtdw . dlwhmkwakq ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 17 , & ( mdlrefDW -> rtdw .
goc2stz4xv ) , sizeof ( mdlrefDW -> rtdw . goc2stz4xv ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 18 , & ( mdlrefDW -> rtdw .
kyrqx4vhbt ) , sizeof ( mdlrefDW -> rtdw . kyrqx4vhbt ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 19 , & ( mdlrefDW -> rtdw .
j4xzkmpvu5 ) , sizeof ( mdlrefDW -> rtdw . j4xzkmpvu5 ) ) ;
mr_collectors_cacheDataAsMxArray ( rtdwData , 0 , 20 , & ( mdlrefDW -> rtdw .
hgxsmjezq5 ) , sizeof ( mdlrefDW -> rtdw . hgxsmjezq5 ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_collectors_SetDWork ( n2raavie0r3 * mdlrefDW , const mxArray * ssDW ) {
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 ,
sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_enable_hold_SetDWork ( & ( mdlrefDW
-> rtdw . ndumhg2xop ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_enable_hold_SetDWork ( & ( mdlrefDW -> rtdw . pcu5iliyv2 ) ,
mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ; mr_differential_drive_SetDWork (
& ( mdlrefDW -> rtdw . kfqrefdtma ) , mxGetFieldByNumber ( rtdwData , 0 , 2 )
) ; mr_theta_correction_SetDWork ( & ( mdlrefDW -> rtdw . g0r4ymcmco ) ,
mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . neijca2aa0 ) ,
rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . neijca2aa0 ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . c3kby1aas1 ) ,
rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . c3kby1aas1 ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . pyv54bcszh ) ,
rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . pyv54bcszh ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . l2uesssmqp ) ,
rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . l2uesssmqp ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . oedmhddfuu ) ,
rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . oedmhddfuu ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . odyseg1rwq ) ,
rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . odyseg1rwq ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . dkvmcj4vbo ) ,
rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . dkvmcj4vbo ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ph53rkyasy ) ,
rtdwData , 0 , 11 , sizeof ( mdlrefDW -> rtdw . ph53rkyasy ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . kpdlqt3sqz ) ,
rtdwData , 0 , 12 , sizeof ( mdlrefDW -> rtdw . kpdlqt3sqz ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . cue4epbxs1 ) ,
rtdwData , 0 , 13 , sizeof ( mdlrefDW -> rtdw . cue4epbxs1 ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . f5mq4pxf3g ) ,
rtdwData , 0 , 14 , sizeof ( mdlrefDW -> rtdw . f5mq4pxf3g ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . i2kfaargqy ) ,
rtdwData , 0 , 15 , sizeof ( mdlrefDW -> rtdw . i2kfaargqy ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . dlwhmkwakq ) ,
rtdwData , 0 , 16 , sizeof ( mdlrefDW -> rtdw . dlwhmkwakq ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . goc2stz4xv ) ,
rtdwData , 0 , 17 , sizeof ( mdlrefDW -> rtdw . goc2stz4xv ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . kyrqx4vhbt ) ,
rtdwData , 0 , 18 , sizeof ( mdlrefDW -> rtdw . kyrqx4vhbt ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . j4xzkmpvu5 ) ,
rtdwData , 0 , 19 , sizeof ( mdlrefDW -> rtdw . j4xzkmpvu5 ) ) ;
mr_collectors_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hgxsmjezq5 ) ,
rtdwData , 0 , 20 , sizeof ( mdlrefDW -> rtdw . hgxsmjezq5 ) ) ; } } void
mr_collectors_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 3823587380U , 918322516U , 1993122876U , 2987203372U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "collectors" , & chksum [ 0 ] ) ;
mr_differential_drive_RegisterSimStateChecksum ( S ) ;
mr_enable_hold_RegisterSimStateChecksum ( S ) ;
mr_theta_correction_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_collectors_GetSimStateDisallowedBlocks ( ) { mxArray * data = NULL ;
size_t numChildrenWithDisallowedBlocks = 0 ; size_t numBlocks = 0 ; mxArray *
disallowedBlocksInChild [ 3 ] ; disallowedBlocksInChild [ 0 ] =
mr_differential_drive_GetSimStateDisallowedBlocks ( ) ;
disallowedBlocksInChild [ 1 ] = mr_enable_hold_GetSimStateDisallowedBlocks (
) ; disallowedBlocksInChild [ 2 ] =
mr_theta_correction_GetSimStateDisallowedBlocks ( ) ; { size_t i ; for ( i =
0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [ i ] ; if (
NULL != data_i ) { if ( 0 == numChildrenWithDisallowedBlocks ++ ) { data =
data_i ; } numBlocks += mxGetM ( data_i ) ; } } } if (
numChildrenWithDisallowedBlocks > 1 ) { mwIndex subs [ 2 ] , offset ; data =
mxCreateCellMatrix ( numBlocks , 3 ) ; subs [ 0 ] = 0 ; { size_t i ; for ( i
= 0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [ i ] ; if
( NULL != data_i ) { mwIndex subs_i [ 2 ] , offset_i ; const mwIndex
numRows_i = ( mwIndex ) mxGetM ( data_i ) ; for ( subs_i [ 0 ] = 0 ; subs_i [
0 ] < numRows_i ; ++ ( subs_i [ 0 ] ) ) { mwIndex j ; for ( j = 0 ; j < 3 ;
++ j ) { mxArray * data_ij ; subs_i [ 1 ] = j ; offset_i =
mxCalcSingleSubscript ( data_i , 2 , subs_i ) ; data_ij = mxGetCell ( data_i
, offset_i ) ; data_ij = mxDuplicateArray ( data_ij ) ; subs [ 1 ] = j ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , data_ij ) ; } ++ ( subs [ 0 ] ) ; } mxDestroyArray ( data_i ) ; } }
} } return data ; }
