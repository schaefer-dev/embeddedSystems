#include "__cf_collectors.h"
#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "collectors_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "collectors.h"
#include "collectors_capi.h"
#include "collectors_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , - 1
, ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1 , 0 } } ;
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "" , "" , 0 ,
0 , 0 , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 0 , 0 } } ; static uint_T rtDimensionArray [ ] = { 0 } ;
static rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( NULL ) , ( NULL ) , 0 , 0 } } ; static int_T
rtContextSystems [ 11 ] ; static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ]
= { { 0 , 0 , "" , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 11 , rtContextSystems , loggingMetaInfo , 0 , NULL ,
{ 0 , NULL , NULL } , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL
) , 0 , ( NULL ) , 0 } , { rtBlockStates , 0 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 3858915088U , 1285671989U , 4055705839U ,
1171473620U } , & mmiStaticInfoLogging , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo * collectors_GetCAPIStaticMap ( void ) {
return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void collectors_InitializeSystemRan ( pdhslryz2b * const npwdrebuui ,
sysRanDType * systemRan [ ] , jma5b1bq35 * localDW , int_T systemTid [ ] ,
void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER ( npwdrebuui ) ;
UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType * )
rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemRan [ 2 ] = ( NULL ) ;
systemRan [ 3 ] = ( sysRanDType * ) & localDW -> kpdlqt3sqz ; systemRan [ 4 ]
= ( NULL ) ; systemRan [ 5 ] = ( NULL ) ; systemRan [ 6 ] = ( NULL ) ;
systemRan [ 7 ] = ( NULL ) ; systemRan [ 8 ] = ( NULL ) ; systemRan [ 9 ] = (
NULL ) ; systemRan [ 10 ] = ( NULL ) ; systemTid [ 1 ] = npwdrebuui -> Timing
. mdlref_GlobalTID [ 0 ] ; systemTid [ 2 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 3 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 4 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 5 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 6 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 7 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 8 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 9 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 10 ] = npwdrebuui -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ; rtContextSystems [ 0 ] =
0 ; rtContextSystems [ 1 ] = 0 ; rtContextSystems [ 2 ] = 0 ;
rtContextSystems [ 3 ] = 3 ; rtContextSystems [ 4 ] = 0 ; rtContextSystems [
5 ] = 0 ; rtContextSystems [ 6 ] = 0 ; rtContextSystems [ 7 ] = 0 ;
rtContextSystems [ 8 ] = 0 ; rtContextSystems [ 9 ] = 0 ; rtContextSystems [
10 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void collectors_InitializeDataMapInfo ( pdhslryz2b * const npwdrebuui ,
jma5b1bq35 * localDW , void * sysRanPtr , int contextTid ) {
rtwCAPI_SetVersion ( npwdrebuui -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( npwdrebuui -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( npwdrebuui -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; rtwCAPI_SetPath ( npwdrebuui -> DataMapInfo . mmi ,
( NULL ) ) ; rtwCAPI_SetFullPath ( npwdrebuui -> DataMapInfo . mmi , ( NULL )
) ; rtwCAPI_SetInstanceLoggingInfo ( npwdrebuui -> DataMapInfo . mmi , &
npwdrebuui -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
npwdrebuui -> DataMapInfo . mmi , npwdrebuui -> DataMapInfo . childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( npwdrebuui -> DataMapInfo . mmi , 4 ) ;
collectors_InitializeSystemRan ( npwdrebuui , npwdrebuui -> DataMapInfo .
systemRan , localDW , npwdrebuui -> DataMapInfo . systemTid , sysRanPtr ,
contextTid ) ; rtwCAPI_SetSystemRan ( npwdrebuui -> DataMapInfo . mmi ,
npwdrebuui -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid ( npwdrebuui
-> DataMapInfo . mmi , npwdrebuui -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( npwdrebuui -> DataMapInfo . mmi , & npwdrebuui ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void collectors_host_InitializeDataMapInfo ( collectors_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
differential_drive_host_InitializeDataMapInfo ( & ( dataMap -> child0 ) ,
"collectors/Model" ) ; dataMap -> childMMI [ 1 ] = & ( dataMap -> child1 .
mmi ) ; enable_hold_host_InitializeDataMapInfo ( & ( dataMap -> child1 ) ,
"collectors/Model1" ) ; dataMap -> childMMI [ 2 ] = & ( dataMap -> child2 .
mmi ) ; enable_hold_host_InitializeDataMapInfo ( & ( dataMap -> child2 ) ,
"collectors/Model2" ) ; dataMap -> childMMI [ 3 ] = & ( dataMap -> child3 .
mmi ) ; theta_correction_host_InitializeDataMapInfo ( & ( dataMap -> child3 )
, "collectors/Model3" ) ; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , dataMap
-> childMMI ) ; rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 4 ) ; }
#ifdef __cplusplus
}
#endif
#endif
