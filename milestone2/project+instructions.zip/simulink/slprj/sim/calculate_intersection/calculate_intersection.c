#include "__cf_calculate_intersection.h"
#include "calculate_intersection_capi.h"
#include "calculate_intersection.h"
#include "calculate_intersection_private.h"
static RegMdlInfo rtMdlInfo_calculate_intersection [ 41 ] = { { "l20fhy3pjtc"
, MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "calculate_intersection"
} , { "pj45xiynrj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "jno4qgzuxy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "b1yxpspxbb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "khqwtixwvi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "aon3ryu5lx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "nw4flz232y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "oue4h3mqt4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "ii3fyza0iq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "g2k12iw2re" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "dxcbjngbmm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "dmuuaj2jn5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "d3cwwlyl4v" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "copojq4112" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "e01bafor1x" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "dtkqd5hpmf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "gvgkyoxgcv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "dc0vwycsfr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "gryadurtlv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "calculate_intersection" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "bbyzmykysjg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "phcf34gkwmy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "mix1tak350" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "bbyzmykysj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "phcf34gkwm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "bvctzapre3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , { "kvlk4iofhp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_intersection" } , {
"mr_calculate_intersection_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "calculate_intersection" }
, { "mr_calculate_intersection_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "calculate_intersection" } , {
"mr_calculate_intersection_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "calculate_intersection" } , { "calculate_intersection.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , { "calculate_intersection.c"
, MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * ) "calculate_intersection" } }
; ka2ttq1dcfe ka2ttq1dcf = { 1.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 } ; void
calculate_intersection ( const real_T oxhmadjrqw [ 2 ] , const real_T
d3a5jqxhqp [ 2 ] , const real_T evdksc4bkv [ 2 ] , const real_T lpcds1hdsi [
2 ] , real_T * aseknauz5g , boolean_T * jwpzptwbpe ) { real_T lasusr0o2k ;
boolean_T ptktuafnmo ; real_T dbc45fhjho ; real_T jycv2z4i5i_idx_0 ; real_T
jycv2z4i5i_idx_1 ; real_T irypz5muiz_idx_0 ; real_T irypz5muiz_idx_1 ;
jycv2z4i5i_idx_0 = oxhmadjrqw [ 0 ] - evdksc4bkv [ 0 ] ; jycv2z4i5i_idx_1 =
oxhmadjrqw [ 1 ] - evdksc4bkv [ 1 ] ; irypz5muiz_idx_0 = d3a5jqxhqp [ 0 ] -
oxhmadjrqw [ 0 ] ; irypz5muiz_idx_1 = d3a5jqxhqp [ 1 ] - oxhmadjrqw [ 1 ] ;
lasusr0o2k = lpcds1hdsi [ 0 ] * irypz5muiz_idx_1 - lpcds1hdsi [ 1 ] *
irypz5muiz_idx_0 ; ptktuafnmo = ! ( lasusr0o2k == ka2ttq1dcf . P_1 ) ; if (
ptktuafnmo ) { dbc45fhjho = lasusr0o2k ; } else { dbc45fhjho = ka2ttq1dcf .
P_2 ; } lasusr0o2k = ( jycv2z4i5i_idx_0 * irypz5muiz_idx_1 - jycv2z4i5i_idx_1
* irypz5muiz_idx_0 ) / dbc45fhjho ; dbc45fhjho = ( jycv2z4i5i_idx_0 *
lpcds1hdsi [ 1 ] - jycv2z4i5i_idx_1 * lpcds1hdsi [ 0 ] ) / dbc45fhjho ; *
jwpzptwbpe = ( ( lasusr0o2k >= ka2ttq1dcf . P_3 ) && ( dbc45fhjho >=
ka2ttq1dcf . P_4 ) && ( dbc45fhjho <= ka2ttq1dcf . P_0 ) && ptktuafnmo ) ; if
( * jwpzptwbpe ) { * aseknauz5g = lasusr0o2k ; } else { * aseknauz5g =
ka2ttq1dcf . P_5 ; } } void calculate_intersectionTID1 ( void ) { } void
copojq4112 ( kvlk4iofhp * const cagiuqgwmu ) { if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( cagiuqgwmu ->
_mdlRefSfcnS , "calculate_intersection" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void gvgkyoxgcv (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , kvlk4iofhp
* const cagiuqgwmu , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ka2ttq1dcf . P_5 = rtInf ; ( void ) memset ( ( void * ) cagiuqgwmu , 0 ,
sizeof ( kvlk4iofhp ) ) ; cagiuqgwmu -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; cagiuqgwmu -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
cagiuqgwmu -> _mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( cagiuqgwmu ->
_mdlRefSfcnS , "calculate_intersection" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; }
calculate_intersection_InitializeDataMapInfo ( cagiuqgwmu , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
cagiuqgwmu -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( cagiuqgwmu ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
cagiuqgwmu -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_calculate_intersection_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo (
mdlRefSfcnS , modelName , rtMdlInfo_calculate_intersection , 41 ) ; * retVal
= 1 ; } static void mr_calculate_intersection_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_calculate_intersection_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_calculate_intersection_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_calculate_intersection_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_calculate_intersection_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_calculate_intersection_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_calculate_intersection_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_calculate_intersection_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_calculate_intersection_cacheDataToMxArrayWithOffset ( mxArray * destArray
, mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes
) ; static void mr_calculate_intersection_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_calculate_intersection_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_calculate_intersection_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_calculate_intersection_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_calculate_intersection_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_calculate_intersection_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T
mr_calculate_intersection_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_calculate_intersection_GetDWork (
const l20fhy3pjtc * mdlrefDW ) { ( void ) mdlrefDW ; return NULL ; } void
mr_calculate_intersection_SetDWork ( l20fhy3pjtc * mdlrefDW , const mxArray *
ssDW ) { ( void ) ssDW ; ( void ) mdlrefDW ; } void
mr_calculate_intersection_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 3462601052U , 3310718094U , 1330332368U ,
570363195U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"calculate_intersection" , & chksum [ 0 ] ) ; } mxArray *
mr_calculate_intersection_GetSimStateDisallowedBlocks ( ) { return NULL ; }
