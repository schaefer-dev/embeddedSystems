#include "__cf_collide_between.h"
#include "collide_between_capi.h"
#include "collide_between.h"
#include "collide_between_private.h"
static RegMdlInfo rtMdlInfo_collide_between [ 47 ] = { { "jv23mlr3c55" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "collide_between" } , {
"lupwujirzg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "jiexea1mf4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "bl4e5u3ma3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "j22oq20v1e" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "a4uxree4wj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "asdcofuiek" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "ctkiy1if25" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "hsuxecy2b2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "aqmmaxesgr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "f0welreujf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "ex0mzjx2dh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "cv0c010vl1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "la13zfc2mh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "bqypsmovqd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "a5luif514d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "dtuq1ronza" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "hzpcsj4xge" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "l4wp2x1qk5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "olpiqkcws2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "collide_between" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , 0 , ( NULL ) } , { "p4eupohwrtl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "collide_between" } , { "nv3dlbmi2ui" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "gzk0lslrt4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "oawvrvzpgqq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "collide_between" } , { "demajggysvg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "p4eupohwrt" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "nv3dlbmi2u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "collide_between" } , { "gvluteqd3x" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collide_between" } ,
{ "kkquagm1v4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collide_between" } , { "nqg40qhj3f4" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "hsv52bpfnq0" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"alscpsbetdd" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_collide_between_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "collide_between" } , {
"mr_collide_between_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "collide_between" } , { "mr_collide_between_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collide_between" } , {
"mr_collide_between_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void
* ) "collide_between" } , { "collide_between.h" , MDL_INFO_MODEL_FILENAME , 0
, - 1 , ( NULL ) } , { "collide_between.c" , MDL_INFO_MODEL_FILENAME , 0 , -
1 , ( void * ) "collide_between" } } ; fkbebj4drm1 fkbebj4drm = {
0.017453292519943295 , 8.6 , 9.8 , 0.017453292519943295 , 8.6 , 9.8 , 100.0 ,
100.0 } ; void l4wp2x1qk5 ( f0welreujf * localDW ) { hrcfg5ieq3 ( & ( localDW
-> gcuvu3m0di . rtdw ) ) ; } void a5luif514d ( ex0mzjx2dh * localB ,
f0welreujf * localDW , lupwujirzg * localZCSV ) { real_T tmp ; lykin54hlj ( &
( localDW -> gcuvu3m0di . rtdw ) , & ( localZCSV -> pq5i5waaj2 ) ) ; if (
localB -> ofgarm1ld3 < localB -> hgzpghkg22 ) { if ( localDW -> ng1osjo4sf ==
0 ) { localZCSV -> f3bl4bzknt = localB -> ofgarm1ld3 - localB -> ofgarm1ld3 ;
} else { localZCSV -> f3bl4bzknt = localB -> ofgarm1ld3 - localB ->
hgzpghkg22 ; } } else if ( localDW -> ng1osjo4sf == 0 ) { localZCSV ->
f3bl4bzknt = localB -> hgzpghkg22 - localB -> ofgarm1ld3 ; } else { localZCSV
-> f3bl4bzknt = localB -> hgzpghkg22 - localB -> hgzpghkg22 ; } tmp = localB
-> ljwmuuz4q3 ; if ( localDW -> h2ru2roh3b == 1 ) { tmp = localB ->
fcboqja0ri ; } if ( localDW -> h2ru2roh3b == 2 ) { tmp = localB -> kpuedxhpyi
; } if ( localDW -> h2ru2roh3b == 3 ) { tmp = localB -> m5gfuwsgrh ; } if (
localDW -> h2ru2roh3b == 4 ) { tmp = fkbebj4drm . P_8 ; } if ( localDW ->
h2ru2roh3b == 5 ) { tmp = fkbebj4drm . P_8 ; } if ( localDW -> h2ru2roh3b ==
6 ) { tmp = fkbebj4drm . P_8 ; } if ( localDW -> h2ru2roh3b == 7 ) { tmp =
fkbebj4drm . P_8 ; } if ( localDW -> h2ru2roh3b == 8 ) { tmp = fkbebj4drm .
P_8 ; } if ( localDW -> h2ru2roh3b == 9 ) { tmp = fkbebj4drm . P_8 ; } if (
localDW -> h2ru2roh3b == 10 ) { tmp = fkbebj4drm . P_8 ; } if ( localDW ->
h2ru2roh3b == 11 ) { tmp = fkbebj4drm . P_8 ; } if ( localDW -> h2ru2roh3b ==
12 ) { tmp = localB -> abffb4kyof ; } if ( localDW -> h2ru2roh3b == 13 ) {
tmp = localB -> bii0uc2qtt ; } if ( localDW -> h2ru2roh3b == 14 ) { tmp =
localB -> lifetzu3z5 ; } if ( localDW -> h2ru2roh3b == 15 ) { tmp = localB ->
hgzpghkg22 ; } localZCSV -> btelntelql = muDoubleScalarMin ( localB ->
hgzpghkg22 , muDoubleScalarMin ( localB -> lifetzu3z5 , muDoubleScalarMin (
localB -> bii0uc2qtt , muDoubleScalarMin ( localB -> abffb4kyof ,
muDoubleScalarMin ( fkbebj4drm . P_8 , muDoubleScalarMin ( fkbebj4drm . P_8 ,
muDoubleScalarMin ( fkbebj4drm . P_8 , muDoubleScalarMin ( fkbebj4drm . P_8 ,
muDoubleScalarMin ( fkbebj4drm . P_8 , muDoubleScalarMin ( fkbebj4drm . P_8 ,
muDoubleScalarMin ( fkbebj4drm . P_8 , muDoubleScalarMin ( fkbebj4drm . P_8 ,
muDoubleScalarMin ( localB -> m5gfuwsgrh , muDoubleScalarMin ( localB ->
kpuedxhpyi , muDoubleScalarMin ( localB -> fcboqja0ri , localB -> ljwmuuz4q3
) ) ) ) ) ) ) ) ) ) ) ) ) ) ) - tmp ; if ( localB -> p310k0tjoa < localB ->
d32qz0xifn ) { if ( localDW -> bjl0j4aebl == 0 ) { localZCSV -> ejfuhrskm1 =
localB -> p310k0tjoa - localB -> p310k0tjoa ; } else { localZCSV ->
ejfuhrskm1 = localB -> p310k0tjoa - localB -> d32qz0xifn ; } } else if (
localDW -> bjl0j4aebl == 0 ) { localZCSV -> ejfuhrskm1 = localB -> d32qz0xifn
- localB -> p310k0tjoa ; } else { localZCSV -> ejfuhrskm1 = localB ->
d32qz0xifn - localB -> d32qz0xifn ; } tmp = localB -> imxxijqg21 ; if (
localDW -> mfqbmx4mtw == 1 ) { tmp = localB -> fpfbc0gosq ; } if ( localDW ->
mfqbmx4mtw == 2 ) { tmp = localB -> acuqy4u4b1 ; } if ( localDW -> mfqbmx4mtw
== 3 ) { tmp = localB -> dfurjr5qtf ; } if ( localDW -> mfqbmx4mtw == 4 ) {
tmp = fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw == 5 ) { tmp =
fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw == 6 ) { tmp = fkbebj4drm .
P_9 ; } if ( localDW -> mfqbmx4mtw == 7 ) { tmp = fkbebj4drm . P_9 ; } if (
localDW -> mfqbmx4mtw == 8 ) { tmp = fkbebj4drm . P_9 ; } if ( localDW ->
mfqbmx4mtw == 9 ) { tmp = fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw ==
10 ) { tmp = fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw == 11 ) { tmp =
fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw == 12 ) { tmp = localB ->
ashqba03j0 ; } if ( localDW -> mfqbmx4mtw == 13 ) { tmp = localB ->
idddua3mxb ; } if ( localDW -> mfqbmx4mtw == 14 ) { tmp = localB ->
m03yodakzw ; } if ( localDW -> mfqbmx4mtw == 15 ) { tmp = localB ->
d32qz0xifn ; } localZCSV -> bp1owqberd = muDoubleScalarMin ( localB ->
d32qz0xifn , muDoubleScalarMin ( localB -> m03yodakzw , muDoubleScalarMin (
localB -> idddua3mxb , muDoubleScalarMin ( localB -> ashqba03j0 ,
muDoubleScalarMin ( fkbebj4drm . P_9 , muDoubleScalarMin ( fkbebj4drm . P_9 ,
muDoubleScalarMin ( fkbebj4drm . P_9 , muDoubleScalarMin ( fkbebj4drm . P_9 ,
muDoubleScalarMin ( fkbebj4drm . P_9 , muDoubleScalarMin ( fkbebj4drm . P_9 ,
muDoubleScalarMin ( fkbebj4drm . P_9 , muDoubleScalarMin ( fkbebj4drm . P_9 ,
muDoubleScalarMin ( localB -> dfurjr5qtf , muDoubleScalarMin ( localB ->
acuqy4u4b1 , muDoubleScalarMin ( localB -> fpfbc0gosq , localB -> imxxijqg21
) ) ) ) ) ) ) ) ) ) ) ) ) ) ) - tmp ; if ( localB -> m5gfuwsgrh < localB ->
f0aytpalcp ) { if ( localDW -> olke42stum == 0 ) { localZCSV -> n4bnuf0fyv =
localB -> m5gfuwsgrh - localB -> m5gfuwsgrh ; } else { localZCSV ->
n4bnuf0fyv = localB -> m5gfuwsgrh - localB -> f0aytpalcp ; } } else if (
localDW -> olke42stum == 0 ) { localZCSV -> n4bnuf0fyv = localB -> f0aytpalcp
- localB -> m5gfuwsgrh ; } else { localZCSV -> n4bnuf0fyv = localB ->
f0aytpalcp - localB -> f0aytpalcp ; } if ( localB -> d25dphbvhy < localB ->
dfurjr5qtf ) { if ( localDW -> d2zo2mzgqj == 0 ) { localZCSV -> mnp1bce0oj =
localB -> d25dphbvhy - localB -> d25dphbvhy ; } else { localZCSV ->
mnp1bce0oj = localB -> d25dphbvhy - localB -> dfurjr5qtf ; } } else if (
localDW -> d2zo2mzgqj == 0 ) { localZCSV -> mnp1bce0oj = localB -> dfurjr5qtf
- localB -> d25dphbvhy ; } else { localZCSV -> mnp1bce0oj = localB ->
dfurjr5qtf - localB -> dfurjr5qtf ; } bgeo5i3ygf ( & ( localDW -> frtlkcykq2
. rtb ) , & ( localZCSV -> blsvh33yee ) ) ; bgeo5i3ygf ( & ( localDW ->
andmdsa3j2 . rtb ) , & ( localZCSV -> pmp1m4elur ) ) ; } void collide_between
( kkquagm1v4 * const enzdlkimmo , const real_T * ovvs4bqoyp , const real_T *
fdhlvye24h , const real_T * l5jziqi0ba , const real_T * pawpwzwy5p , const
real_T * dvmkti5moy , const real_T * dmpt42ua2b , real_T * ovce2laicm ,
real_T * eqskzgx34o , real_T * kykyy0cn2i , real_T * obs1kj5i1i , real_T *
gtvqdo3szi , real_T * hajnrpkslx , ex0mzjx2dh * localB , f0welreujf * localDW
) { real_T pjrshh50wf ; real_T fkssxtirhu ; real_T j434gcuals ; real_T
dbue4nw4yt ; real_T ees3ztokw3 ; real_T kw04tyy54m ; real_T esupizzank ;
real_T avpt5fq1ig ; real_T jxja1a4uuw ; real_T h4ggo0qw0h ; real_T brobepwtwc
; real_T fahm1mfo4q ; real_T eiijnll30c ; real_T pkjknn4vog ; real_T
bcfyew0dnv ; real_T ij1jxe4qfp ; real_T kmpxvej3zo ; real_T bew0w1qmef ;
real_T minV ; * kykyy0cn2i = * l5jziqi0ba ; pjrshh50wf = fkbebj4drm . P_2 * *
kykyy0cn2i ; bounding_box_calc ( ovvs4bqoyp , fdhlvye24h , & pjrshh50wf , &
fkbebj4drm . P_3 , & fkbebj4drm . P_4 , & localB -> b1lxboq0nr [ 0 ] , &
localB -> jaw4jq5i4l [ 0 ] , & localB -> gbg2uum1yo [ 0 ] , & localB ->
ey5kk21gfs [ 0 ] ) ; * hajnrpkslx = * dmpt42ua2b ; fkssxtirhu = fkbebj4drm .
P_5 * * hajnrpkslx ; bounding_box_calc ( pawpwzwy5p , dvmkti5moy , &
fkssxtirhu , & fkbebj4drm . P_6 , & fkbebj4drm . P_7 , & localB -> m4zal3w0ln
[ 0 ] , & localB -> e2iohf0oaq [ 0 ] , & localB -> ccz4fezwxu [ 0 ] , &
localB -> dnkkax23uu [ 0 ] ) ; collision_between_two_robots ( & localB ->
b1lxboq0nr [ 0 ] , & localB -> jaw4jq5i4l [ 0 ] , & localB -> gbg2uum1yo [ 0
] , & localB -> ey5kk21gfs [ 0 ] , & localB -> m4zal3w0ln [ 0 ] , & localB ->
e2iohf0oaq [ 0 ] , & localB -> ccz4fezwxu [ 0 ] , & localB -> dnkkax23uu [ 0
] , & localB -> ljwmuuz4q3 , & localB -> fcboqja0ri , & localB -> kpuedxhpyi
, & localB -> ofgarm1ld3 , & j434gcuals , & dbue4nw4yt , & ees3ztokw3 , &
kw04tyy54m , & esupizzank , & avpt5fq1ig , & jxja1a4uuw , & h4ggo0qw0h , &
localB -> abffb4kyof , & localB -> bii0uc2qtt , & localB -> lifetzu3z5 , &
localB -> hgzpghkg22 , & localB -> imxxijqg21 , & localB -> fpfbc0gosq , &
localB -> acuqy4u4b1 , & localB -> p310k0tjoa , & brobepwtwc , & fahm1mfo4q ,
& eiijnll30c , & pkjknn4vog , & bcfyew0dnv , & ij1jxe4qfp , & kmpxvej3zo , &
bew0w1qmef , & localB -> ashqba03j0 , & localB -> idddua3mxb , & localB ->
m03yodakzw , & localB -> d32qz0xifn , & ( localDW -> gcuvu3m0di . rtdw ) ) ;
if ( rtmIsMajorTimeStep ( enzdlkimmo ) ) { localB -> m5gfuwsgrh = localB ->
ofgarm1ld3 ; localDW -> ng1osjo4sf = 0 ; if ( localB -> hgzpghkg22 < localB
-> ofgarm1ld3 ) { localB -> m5gfuwsgrh = localB -> hgzpghkg22 ; localDW ->
ng1osjo4sf = 1 ; } minV = localB -> ljwmuuz4q3 ; localDW -> h2ru2roh3b = 0 ;
if ( localB -> fcboqja0ri < localB -> ljwmuuz4q3 ) { minV = localB ->
fcboqja0ri ; localDW -> h2ru2roh3b = 1 ; } if ( localB -> kpuedxhpyi < minV )
{ minV = localB -> kpuedxhpyi ; localDW -> h2ru2roh3b = 2 ; } if ( localB ->
m5gfuwsgrh < minV ) { minV = localB -> m5gfuwsgrh ; localDW -> h2ru2roh3b = 3
; } if ( fkbebj4drm . P_8 < minV ) { minV = fkbebj4drm . P_8 ; localDW ->
h2ru2roh3b = 4 ; } if ( fkbebj4drm . P_8 < minV ) { minV = fkbebj4drm . P_8 ;
localDW -> h2ru2roh3b = 5 ; } if ( fkbebj4drm . P_8 < minV ) { minV =
fkbebj4drm . P_8 ; localDW -> h2ru2roh3b = 6 ; } if ( fkbebj4drm . P_8 < minV
) { minV = fkbebj4drm . P_8 ; localDW -> h2ru2roh3b = 7 ; } if ( fkbebj4drm .
P_8 < minV ) { minV = fkbebj4drm . P_8 ; localDW -> h2ru2roh3b = 8 ; } if (
fkbebj4drm . P_8 < minV ) { minV = fkbebj4drm . P_8 ; localDW -> h2ru2roh3b =
9 ; } if ( fkbebj4drm . P_8 < minV ) { minV = fkbebj4drm . P_8 ; localDW ->
h2ru2roh3b = 10 ; } if ( fkbebj4drm . P_8 < minV ) { minV = fkbebj4drm . P_8
; localDW -> h2ru2roh3b = 11 ; } if ( localB -> abffb4kyof < minV ) { minV =
localB -> abffb4kyof ; localDW -> h2ru2roh3b = 12 ; } if ( localB ->
bii0uc2qtt < minV ) { minV = localB -> bii0uc2qtt ; localDW -> h2ru2roh3b =
13 ; } if ( localB -> lifetzu3z5 < minV ) { minV = localB -> lifetzu3z5 ;
localDW -> h2ru2roh3b = 14 ; } if ( localB -> hgzpghkg22 < minV ) { minV =
localB -> hgzpghkg22 ; localDW -> h2ru2roh3b = 15 ; } localB -> d25dphbvhy =
minV ; localB -> dfurjr5qtf = localB -> p310k0tjoa ; localDW -> bjl0j4aebl =
0 ; if ( localB -> d32qz0xifn < localB -> p310k0tjoa ) { localB -> dfurjr5qtf
= localB -> d32qz0xifn ; localDW -> bjl0j4aebl = 1 ; } minV = localB ->
imxxijqg21 ; localDW -> mfqbmx4mtw = 0 ; if ( localB -> fpfbc0gosq < localB
-> imxxijqg21 ) { minV = localB -> fpfbc0gosq ; localDW -> mfqbmx4mtw = 1 ; }
if ( localB -> acuqy4u4b1 < minV ) { minV = localB -> acuqy4u4b1 ; localDW ->
mfqbmx4mtw = 2 ; } if ( localB -> dfurjr5qtf < minV ) { minV = localB ->
dfurjr5qtf ; localDW -> mfqbmx4mtw = 3 ; } if ( fkbebj4drm . P_9 < minV ) {
minV = fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw = 4 ; } if ( fkbebj4drm . P_9
< minV ) { minV = fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw = 5 ; } if (
fkbebj4drm . P_9 < minV ) { minV = fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw =
6 ; } if ( fkbebj4drm . P_9 < minV ) { minV = fkbebj4drm . P_9 ; localDW ->
mfqbmx4mtw = 7 ; } if ( fkbebj4drm . P_9 < minV ) { minV = fkbebj4drm . P_9 ;
localDW -> mfqbmx4mtw = 8 ; } if ( fkbebj4drm . P_9 < minV ) { minV =
fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw = 9 ; } if ( fkbebj4drm . P_9 < minV
) { minV = fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw = 10 ; } if ( fkbebj4drm
. P_9 < minV ) { minV = fkbebj4drm . P_9 ; localDW -> mfqbmx4mtw = 11 ; } if
( localB -> ashqba03j0 < minV ) { minV = localB -> ashqba03j0 ; localDW ->
mfqbmx4mtw = 12 ; } if ( localB -> idddua3mxb < minV ) { minV = localB ->
idddua3mxb ; localDW -> mfqbmx4mtw = 13 ; } if ( localB -> m03yodakzw < minV
) { minV = localB -> m03yodakzw ; localDW -> mfqbmx4mtw = 14 ; } if ( localB
-> d32qz0xifn < minV ) { minV = localB -> d32qz0xifn ; localDW -> mfqbmx4mtw
= 15 ; } localB -> f0aytpalcp = minV ; localB -> djevy4krgv = localB ->
m5gfuwsgrh ; localDW -> olke42stum = 0 ; if ( localB -> f0aytpalcp < localB
-> m5gfuwsgrh ) { localB -> djevy4krgv = localB -> f0aytpalcp ; localDW ->
olke42stum = 1 ; } localB -> loja1ifkyz = localB -> d25dphbvhy ; localDW ->
d2zo2mzgqj = 0 ; if ( localB -> dfurjr5qtf < localB -> d25dphbvhy ) { localB
-> loja1ifkyz = localB -> dfurjr5qtf ; localDW -> d2zo2mzgqj = 1 ; } } else {
localB -> m5gfuwsgrh = localB -> ofgarm1ld3 ; if ( localDW -> ng1osjo4sf == 1
) { localB -> m5gfuwsgrh = localB -> hgzpghkg22 ; } localB -> d25dphbvhy =
localB -> ljwmuuz4q3 ; if ( localDW -> h2ru2roh3b == 1 ) { localB ->
d25dphbvhy = localB -> fcboqja0ri ; } if ( localDW -> h2ru2roh3b == 2 ) {
localB -> d25dphbvhy = localB -> kpuedxhpyi ; } if ( localDW -> h2ru2roh3b ==
3 ) { localB -> d25dphbvhy = localB -> m5gfuwsgrh ; } if ( localDW ->
h2ru2roh3b == 4 ) { localB -> d25dphbvhy = fkbebj4drm . P_8 ; } if ( localDW
-> h2ru2roh3b == 5 ) { localB -> d25dphbvhy = fkbebj4drm . P_8 ; } if (
localDW -> h2ru2roh3b == 6 ) { localB -> d25dphbvhy = fkbebj4drm . P_8 ; } if
( localDW -> h2ru2roh3b == 7 ) { localB -> d25dphbvhy = fkbebj4drm . P_8 ; }
if ( localDW -> h2ru2roh3b == 8 ) { localB -> d25dphbvhy = fkbebj4drm . P_8 ;
} if ( localDW -> h2ru2roh3b == 9 ) { localB -> d25dphbvhy = fkbebj4drm . P_8
; } if ( localDW -> h2ru2roh3b == 10 ) { localB -> d25dphbvhy = fkbebj4drm .
P_8 ; } if ( localDW -> h2ru2roh3b == 11 ) { localB -> d25dphbvhy =
fkbebj4drm . P_8 ; } if ( localDW -> h2ru2roh3b == 12 ) { localB ->
d25dphbvhy = localB -> abffb4kyof ; } if ( localDW -> h2ru2roh3b == 13 ) {
localB -> d25dphbvhy = localB -> bii0uc2qtt ; } if ( localDW -> h2ru2roh3b ==
14 ) { localB -> d25dphbvhy = localB -> lifetzu3z5 ; } if ( localDW ->
h2ru2roh3b == 15 ) { localB -> d25dphbvhy = localB -> hgzpghkg22 ; } localB
-> dfurjr5qtf = localB -> p310k0tjoa ; if ( localDW -> bjl0j4aebl == 1 ) {
localB -> dfurjr5qtf = localB -> d32qz0xifn ; } localB -> f0aytpalcp = localB
-> imxxijqg21 ; if ( localDW -> mfqbmx4mtw == 1 ) { localB -> f0aytpalcp =
localB -> fpfbc0gosq ; } if ( localDW -> mfqbmx4mtw == 2 ) { localB ->
f0aytpalcp = localB -> acuqy4u4b1 ; } if ( localDW -> mfqbmx4mtw == 3 ) {
localB -> f0aytpalcp = localB -> dfurjr5qtf ; } if ( localDW -> mfqbmx4mtw ==
4 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; } if ( localDW -> mfqbmx4mtw
== 5 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; } if ( localDW ->
mfqbmx4mtw == 6 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; } if ( localDW
-> mfqbmx4mtw == 7 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; } if (
localDW -> mfqbmx4mtw == 8 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; } if
( localDW -> mfqbmx4mtw == 9 ) { localB -> f0aytpalcp = fkbebj4drm . P_9 ; }
if ( localDW -> mfqbmx4mtw == 10 ) { localB -> f0aytpalcp = fkbebj4drm . P_9
; } if ( localDW -> mfqbmx4mtw == 11 ) { localB -> f0aytpalcp = fkbebj4drm .
P_9 ; } if ( localDW -> mfqbmx4mtw == 12 ) { localB -> f0aytpalcp = localB ->
ashqba03j0 ; } if ( localDW -> mfqbmx4mtw == 13 ) { localB -> f0aytpalcp =
localB -> idddua3mxb ; } if ( localDW -> mfqbmx4mtw == 14 ) { localB ->
f0aytpalcp = localB -> m03yodakzw ; } if ( localDW -> mfqbmx4mtw == 15 ) {
localB -> f0aytpalcp = localB -> d32qz0xifn ; } localB -> djevy4krgv = localB
-> m5gfuwsgrh ; if ( localDW -> olke42stum == 1 ) { localB -> djevy4krgv =
localB -> f0aytpalcp ; } localB -> loja1ifkyz = localB -> d25dphbvhy ; if (
localDW -> d2zo2mzgqj == 1 ) { localB -> loja1ifkyz = localB -> dfurjr5qtf ;
} } calculate_collision_effects ( & ( localDW -> frtlkcykq2 . rtm ) , &
localB -> djevy4krgv , pawpwzwy5p , dvmkti5moy , kykyy0cn2i , obs1kj5i1i ,
gtvqdo3szi , & ( localDW -> frtlkcykq2 . rtb ) , & ( localDW -> frtlkcykq2 .
rtdw ) ) ; calculate_collision_effects ( & ( localDW -> andmdsa3j2 . rtm ) ,
& localB -> loja1ifkyz , ovvs4bqoyp , fdhlvye24h , hajnrpkslx , ovce2laicm ,
eqskzgx34o , & ( localDW -> andmdsa3j2 . rtb ) , & ( localDW -> andmdsa3j2 .
rtdw ) ) ; } void collide_betweenTID1 ( void ) {
calculate_collision_effectsTID1 ( ) ; calculate_collision_effectsTID1 ( ) ; }
void la13zfc2mh ( f0welreujf * localDW , kkquagm1v4 * const enzdlkimmo ) {
h2gdpdmrk4 ( & ( localDW -> okvgmhwpxu . rtm ) ) ; h2gdpdmrk4 ( & ( localDW
-> gxbwutzaad . rtm ) ) ; ppne3p4rj0 ( & ( localDW -> gcuvu3m0di . rtdw ) , &
( localDW -> gcuvu3m0di . rtm ) ) ; izntqovil1 ( & ( localDW -> frtlkcykq2 .
rtm ) ) ; izntqovil1 ( & ( localDW -> andmdsa3j2 . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( enzdlkimmo ->
_mdlRefSfcnS , "collide_between" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void hzpcsj4xge (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , kkquagm1v4
* const enzdlkimmo , ex0mzjx2dh * localB , f0welreujf * localDW , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( ( void * )
enzdlkimmo , 0 , sizeof ( kkquagm1v4 ) ) ; enzdlkimmo -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; enzdlkimmo -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; enzdlkimmo -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( enzdlkimmo -> _mdlRefSfcnS , "collide_between" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> b1lxboq0nr [ 0 ]
= 0.0 ; localB -> b1lxboq0nr [ 1 ] = 0.0 ; localB -> jaw4jq5i4l [ 0 ] = 0.0 ;
localB -> jaw4jq5i4l [ 1 ] = 0.0 ; localB -> gbg2uum1yo [ 0 ] = 0.0 ; localB
-> gbg2uum1yo [ 1 ] = 0.0 ; localB -> ey5kk21gfs [ 0 ] = 0.0 ; localB ->
ey5kk21gfs [ 1 ] = 0.0 ; localB -> m4zal3w0ln [ 0 ] = 0.0 ; localB ->
m4zal3w0ln [ 1 ] = 0.0 ; localB -> e2iohf0oaq [ 0 ] = 0.0 ; localB ->
e2iohf0oaq [ 1 ] = 0.0 ; localB -> ccz4fezwxu [ 0 ] = 0.0 ; localB ->
ccz4fezwxu [ 1 ] = 0.0 ; localB -> dnkkax23uu [ 0 ] = 0.0 ; localB ->
dnkkax23uu [ 1 ] = 0.0 ; localB -> ljwmuuz4q3 = 0.0 ; localB -> fcboqja0ri =
0.0 ; localB -> kpuedxhpyi = 0.0 ; localB -> ofgarm1ld3 = 0.0 ; localB ->
abffb4kyof = 0.0 ; localB -> bii0uc2qtt = 0.0 ; localB -> lifetzu3z5 = 0.0 ;
localB -> hgzpghkg22 = 0.0 ; localB -> imxxijqg21 = 0.0 ; localB ->
fpfbc0gosq = 0.0 ; localB -> acuqy4u4b1 = 0.0 ; localB -> p310k0tjoa = 0.0 ;
localB -> ashqba03j0 = 0.0 ; localB -> idddua3mxb = 0.0 ; localB ->
m03yodakzw = 0.0 ; localB -> d32qz0xifn = 0.0 ; localB -> m5gfuwsgrh = 0.0 ;
localB -> d25dphbvhy = 0.0 ; localB -> dfurjr5qtf = 0.0 ; localB ->
f0aytpalcp = 0.0 ; localB -> djevy4krgv = 0.0 ; localB -> loja1ifkyz = 0.0 ;
} ( void ) memset ( ( void * ) localDW , 0 , sizeof ( f0welreujf ) ) ;
collide_between_InitializeDataMapInfo ( enzdlkimmo , localDW , sysRanPtr ,
contextTid ) ; mwju1cce1h ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW ->
gcuvu3m0di . rtm ) , & ( localDW -> gcuvu3m0di . rtdw ) , enzdlkimmo ->
DataMapInfo . systemRan [ 0 ] , enzdlkimmo -> DataMapInfo . systemTid [ 0 ] ,
& ( enzdlkimmo -> DataMapInfo . mmi ) ,
"collide_between/Collision between two robots" , 0 , - 1 ) ; l0cizwtudm (
_mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW -> frtlkcykq2 . rtm )
, & ( localDW -> frtlkcykq2 . rtb ) , & ( localDW -> frtlkcykq2 . rtdw ) ,
enzdlkimmo -> DataMapInfo . systemRan [ 0 ] , enzdlkimmo -> DataMapInfo .
systemTid [ 0 ] , & ( enzdlkimmo -> DataMapInfo . mmi ) ,
"collide_between/Subsystem" , 1 , - 1 ) ; l0cizwtudm ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , & ( localDW -> andmdsa3j2 . rtm ) , & ( localDW
-> andmdsa3j2 . rtb ) , & ( localDW -> andmdsa3j2 . rtdw ) , enzdlkimmo ->
DataMapInfo . systemRan [ 0 ] , enzdlkimmo -> DataMapInfo . systemTid [ 0 ] ,
& ( enzdlkimmo -> DataMapInfo . mmi ) , "collide_between/Subsystem1" , 2 , -
1 ) ; bf1z3ni0yc ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> okvgmhwpxu .
rtm ) , enzdlkimmo -> DataMapInfo . systemRan [ 0 ] , enzdlkimmo ->
DataMapInfo . systemTid [ 0 ] , & ( enzdlkimmo -> DataMapInfo . mmi ) ,
"collide_between/bounding_box_CollectorA" , 3 , - 1 ) ; bf1z3ni0yc (
_mdlRefSfcnS , mdlref_TID0 , & ( localDW -> gxbwutzaad . rtm ) , enzdlkimmo
-> DataMapInfo . systemRan [ 0 ] , enzdlkimmo -> DataMapInfo . systemTid [ 0
] , & ( enzdlkimmo -> DataMapInfo . mmi ) ,
"collide_between/bounding_box_CollectorB" , 4 , - 1 ) ; if ( ( rt_ParentMMI
!= ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( *
rt_ParentMMI , rt_ChildMMIIdx , & ( enzdlkimmo -> DataMapInfo . mmi ) ) ;
rtwCAPI_SetPath ( enzdlkimmo -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( enzdlkimmo -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } } void mr_collide_between_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal = 0 ; {
boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_collision_between_two_robots_MdlInfoRegFcn ( mdlRefSfcnS ,
"collision_between_two_robots" , retVal ) ; if ( * retVal == 0 ) return ; *
retVal = 0 ; mr_calculate_collision_effects_MdlInfoRegFcn ( mdlRefSfcnS ,
"calculate_collision_effects" , retVal ) ; if ( * retVal == 0 ) return ; *
retVal = 0 ; mr_bounding_box_calc_MdlInfoRegFcn ( mdlRefSfcnS ,
"bounding_box_calc" , retVal ) ; if ( * retVal == 0 ) return ; * retVal = 0 ;
} } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_collide_between , 47 ) ; * retVal = 1 ; } static void
mr_collide_between_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int
j , const void * srcData , size_t numBytes ) ; static void
mr_collide_between_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int
j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_collide_between_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_collide_between_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_collide_between_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i ,
int j , uint_T bitVal ) ; static void
mr_collide_between_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i ,
int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_collide_between_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_collide_between_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_collide_between_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_collide_between_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_collide_between_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_collide_between_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_collide_between_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_collide_between_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_collide_between_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_collide_between_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_collide_between_GetDWork ( const
jv23mlr3c55 * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] = { "rtb"
, "rtdw" , "NULL->rtzce" , } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1
, 3 , ssDWFieldNames ) ; mr_collide_between_cacheDataAsMxArray ( ssDW , 0 , 0
, & ( mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char
* rtdwDataFieldNames [ 11 ] = { "mdlrefDW->rtdw.okvgmhwpxu" ,
"mdlrefDW->rtdw.gxbwutzaad" , "mdlrefDW->rtdw.gcuvu3m0di" ,
"mdlrefDW->rtdw.frtlkcykq2" , "mdlrefDW->rtdw.andmdsa3j2" ,
"mdlrefDW->rtdw.ng1osjo4sf" , "mdlrefDW->rtdw.h2ru2roh3b" ,
"mdlrefDW->rtdw.bjl0j4aebl" , "mdlrefDW->rtdw.mfqbmx4mtw" ,
"mdlrefDW->rtdw.olke42stum" , "mdlrefDW->rtdw.d2zo2mzgqj" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 11 , rtdwDataFieldNames ) ; {
mxArray * varData = mr_bounding_box_calc_GetDWork ( & ( mdlrefDW -> rtdw .
okvgmhwpxu ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } {
mxArray * varData = mr_bounding_box_calc_GetDWork ( & ( mdlrefDW -> rtdw .
gxbwutzaad ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } {
mxArray * varData = mr_collision_between_two_robots_GetDWork ( & ( mdlrefDW
-> rtdw . gcuvu3m0di ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 2 , varData )
; } { mxArray * varData = mr_calculate_collision_effects_GetDWork ( & (
mdlrefDW -> rtdw . frtlkcykq2 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 3 ,
varData ) ; } { mxArray * varData = mr_calculate_collision_effects_GetDWork (
& ( mdlrefDW -> rtdw . andmdsa3j2 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 4
, varData ) ; } mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 5 , &
( mdlrefDW -> rtdw . ng1osjo4sf ) , sizeof ( mdlrefDW -> rtdw . ng1osjo4sf )
) ; mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( mdlrefDW
-> rtdw . h2ru2roh3b ) , sizeof ( mdlrefDW -> rtdw . h2ru2roh3b ) ) ;
mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( mdlrefDW ->
rtdw . bjl0j4aebl ) , sizeof ( mdlrefDW -> rtdw . bjl0j4aebl ) ) ;
mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( mdlrefDW ->
rtdw . mfqbmx4mtw ) , sizeof ( mdlrefDW -> rtdw . mfqbmx4mtw ) ) ;
mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( mdlrefDW ->
rtdw . olke42stum ) , sizeof ( mdlrefDW -> rtdw . olke42stum ) ) ;
mr_collide_between_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( mdlrefDW ->
rtdw . d2zo2mzgqj ) , sizeof ( mdlrefDW -> rtdw . d2zo2mzgqj ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_collide_between_SetDWork ( jv23mlr3c55 * mdlrefDW , const mxArray * ssDW )
{ mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW ,
0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_bounding_box_calc_SetDWork ( & (
mdlrefDW -> rtdw . okvgmhwpxu ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_bounding_box_calc_SetDWork ( & ( mdlrefDW -> rtdw . gxbwutzaad ) ,
mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ;
mr_collision_between_two_robots_SetDWork ( & ( mdlrefDW -> rtdw . gcuvu3m0di
) , mxGetFieldByNumber ( rtdwData , 0 , 2 ) ) ;
mr_calculate_collision_effects_SetDWork ( & ( mdlrefDW -> rtdw . frtlkcykq2 )
, mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ;
mr_calculate_collision_effects_SetDWork ( & ( mdlrefDW -> rtdw . andmdsa3j2 )
, mxGetFieldByNumber ( rtdwData , 0 , 4 ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ng1osjo4sf
) , rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . ng1osjo4sf ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . h2ru2roh3b
) , rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . h2ru2roh3b ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . bjl0j4aebl
) , rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . bjl0j4aebl ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . mfqbmx4mtw
) , rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . mfqbmx4mtw ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . olke42stum
) , rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . olke42stum ) ) ;
mr_collide_between_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . d2zo2mzgqj
) , rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . d2zo2mzgqj ) ) ; } } void
mr_collide_between_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 2315631742U , 2482878476U , 4231125848U ,
3695911884U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"collide_between" , & chksum [ 0 ] ) ;
mr_bounding_box_calc_RegisterSimStateChecksum ( S ) ;
mr_calculate_collision_effects_RegisterSimStateChecksum ( S ) ;
mr_collision_between_two_robots_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_collide_between_GetSimStateDisallowedBlocks ( ) { mxArray * data = NULL ;
size_t numChildrenWithDisallowedBlocks = 0 ; size_t numBlocks = 0 ; mxArray *
disallowedBlocksInChild [ 3 ] ; disallowedBlocksInChild [ 0 ] =
mr_bounding_box_calc_GetSimStateDisallowedBlocks ( ) ;
disallowedBlocksInChild [ 1 ] =
mr_calculate_collision_effects_GetSimStateDisallowedBlocks ( ) ;
disallowedBlocksInChild [ 2 ] =
mr_collision_between_two_robots_GetSimStateDisallowedBlocks ( ) ; { size_t i
; for ( i = 0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [
i ] ; if ( NULL != data_i ) { if ( 0 == numChildrenWithDisallowedBlocks ++ )
{ data = data_i ; } numBlocks += mxGetM ( data_i ) ; } } } if (
numChildrenWithDisallowedBlocks > 1 ) { mwIndex subs [ 2 ] , offset ; data =
mxCreateCellMatrix ( numBlocks , 3 ) ; subs [ 0 ] = 0 ; { size_t i ; for ( i
= 0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [ i ] ; if
( NULL != data_i ) { mwIndex subs_i [ 2 ] , offset_i ; const mwIndex
numRows_i = ( mwIndex ) mxGetM ( data_i ) ; for ( subs_i [ 0 ] = 0 ; subs_i [
0 ] < numRows_i ; ++ ( subs_i [ 0 ] ) ) { mwIndex j ; for ( j = 0 ; j < 3 ;
++ j ) { mxArray * data_ij ; subs_i [ 1 ] = j ; offset_i =
mxCalcSingleSubscript ( data_i , 2 , subs_i ) ; data_ij = mxGetCell ( data_i
, offset_i ) ; data_ij = mxDuplicateArray ( data_ij ) ; subs [ 1 ] = j ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , data_ij ) ; } ++ ( subs [ 0 ] ) ; } mxDestroyArray ( data_i ) ; } }
} } return data ; }
