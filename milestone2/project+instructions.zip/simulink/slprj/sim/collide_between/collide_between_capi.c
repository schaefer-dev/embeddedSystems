#include "__cf_collide_between.h"
#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "collide_between_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "collide_between.h"
#include "collide_between_capi.h"
#include "collide_between_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , - 1
, ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1 , 0 } } ;
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "" , "" , 0 ,
0 , 0 , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 0 , 0 } } ; static uint_T rtDimensionArray [ ] = { 0 } ;
static rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( NULL ) , ( NULL ) , 0 , 0 } } ; static int_T
rtContextSystems [ 2 ] ; static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] =
{ { 0 , 0 , "" , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 2 , rtContextSystems , loggingMetaInfo , 0 , NULL ,
{ 0 , NULL , NULL } , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL
) , 0 , ( NULL ) , 0 } , { rtBlockStates , 0 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 3061189357U , 520812810U , 4166912095U ,
3156610205U } , & mmiStaticInfoLogging , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo * collide_between_GetCAPIStaticMap ( void ) {
return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void collide_between_InitializeSystemRan ( kkquagm1v4 * const
enzdlkimmo , sysRanDType * systemRan [ ] , f0welreujf * localDW , int_T
systemTid [ ] , void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER (
enzdlkimmo ) ; UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType
* ) rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemTid [ 1 ] = enzdlkimmo
-> Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ;
rtContextSystems [ 0 ] = 0 ; rtContextSystems [ 1 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void collide_between_InitializeDataMapInfo ( kkquagm1v4 * const enzdlkimmo ,
f0welreujf * localDW , void * sysRanPtr , int contextTid ) {
rtwCAPI_SetVersion ( enzdlkimmo -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( enzdlkimmo -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( enzdlkimmo -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; rtwCAPI_SetPath ( enzdlkimmo -> DataMapInfo . mmi ,
( NULL ) ) ; rtwCAPI_SetFullPath ( enzdlkimmo -> DataMapInfo . mmi , ( NULL )
) ; rtwCAPI_SetInstanceLoggingInfo ( enzdlkimmo -> DataMapInfo . mmi , &
enzdlkimmo -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
enzdlkimmo -> DataMapInfo . mmi , enzdlkimmo -> DataMapInfo . childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( enzdlkimmo -> DataMapInfo . mmi , 5 ) ;
collide_between_InitializeSystemRan ( enzdlkimmo , enzdlkimmo -> DataMapInfo
. systemRan , localDW , enzdlkimmo -> DataMapInfo . systemTid , sysRanPtr ,
contextTid ) ; rtwCAPI_SetSystemRan ( enzdlkimmo -> DataMapInfo . mmi ,
enzdlkimmo -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid ( enzdlkimmo
-> DataMapInfo . mmi , enzdlkimmo -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( enzdlkimmo -> DataMapInfo . mmi , & enzdlkimmo ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void collide_between_host_InitializeDataMapInfo (
collide_between_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
collision_between_two_robots_host_InitializeDataMapInfo ( & ( dataMap ->
child0 ) , "collide_between/Collision between two robots" ) ; dataMap ->
childMMI [ 1 ] = & ( dataMap -> child1 . mmi ) ;
calculate_collision_effects_host_InitializeDataMapInfo ( & ( dataMap ->
child1 ) , "collide_between/Subsystem" ) ; dataMap -> childMMI [ 2 ] = & (
dataMap -> child2 . mmi ) ;
calculate_collision_effects_host_InitializeDataMapInfo ( & ( dataMap ->
child2 ) , "collide_between/Subsystem1" ) ; dataMap -> childMMI [ 3 ] = & (
dataMap -> child3 . mmi ) ; bounding_box_calc_host_InitializeDataMapInfo ( &
( dataMap -> child3 ) , "collide_between/bounding_box_CollectorA" ) ; dataMap
-> childMMI [ 4 ] = & ( dataMap -> child4 . mmi ) ;
bounding_box_calc_host_InitializeDataMapInfo ( & ( dataMap -> child4 ) ,
"collide_between/bounding_box_CollectorB" ) ; rtwCAPI_SetChildMMIArray (
dataMap -> mmi , dataMap -> childMMI ) ; rtwCAPI_SetChildMMIArrayLen (
dataMap -> mmi , 5 ) ; }
#ifdef __cplusplus
}
#endif
#endif
