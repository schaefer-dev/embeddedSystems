#include "__cf_calculate_collision_effects.h"
#include "calculate_collision_effects_capi.h"
#include "calculate_collision_effects.h"
#include "calculate_collision_effects_private.h"
static RegMdlInfo rtMdlInfo_calculate_collision_effects [ 44 ] = { {
"hsv52bpfnq0" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "mwunqph4vq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "ma2qptzt31" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "h4xx5mdv5f" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "ihgdofhc2x" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "cjd2xpzqig" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "nsu2g4j0zh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "mypwpc30da" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "kog2sunb5y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "a4fff5ieyg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "kbuym0zbtf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "cymsckxckb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "ogkikousa1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "izntqovil1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "juqkmjpk5k" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "bgeo5i3ygf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "a1ej2by5tz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "l0cizwtudm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "jt2rgiume2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "jls5g3fyfc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "calculate_collision_effects" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "dtnt0lrn1w1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "ghdxkypttmq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "anjukt1pol" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "nh0jxwq4sn5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "kmnfvwldfbv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "dtnt0lrn1w" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "ghdxkypttm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "gg1ppi30jj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "hy0y0nvofh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , {
"mr_calculate_collision_effects_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "mr_calculate_collision_effects_SetDWork"
, MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "mr_calculate_collision_effects_GetDWork"
, MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"calculate_collision_effects" } , { "calculate_collision_effects.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"calculate_collision_effects.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void
* ) "calculate_collision_effects" } } ; g1j02kmnez5 g1j02kmnez = { 0.0 , 0.0
, 0.017453292519943295 , 0.0 } ; void bgeo5i3ygf ( cymsckxckb * localB ,
mwunqph4vq * localZCSV ) { localZCSV -> f1jloo2g2v = localB -> p2cp4vwpta -
g1j02kmnez . P_3 ; } void calculate_collision_effects ( hy0y0nvofh * const
jjwe0heymi , const real_T * occmobaoq0 , const real_T * heqmcl4fj5 , const
real_T * fdivlf50sk , const real_T * kyulaudqfi , real_T * feiau1mbpe ,
real_T * p2gaq3opsn , cymsckxckb * localB , kbuym0zbtf * localDW ) { real_T
oyemd1o4v3 ; real_T jhqj5jbm2p ; real_T dtlgh5n2q0 ; localB -> p2cp4vwpta = *
occmobaoq0 - rtP_collision_detection_distance ; if ( rtmIsMajorTimeStep (
jjwe0heymi ) ) { localDW -> e0hjvhmbxz = ( localB -> p2cp4vwpta > g1j02kmnez
. P_3 ) ; } if ( localDW -> e0hjvhmbxz ) { dtlgh5n2q0 = g1j02kmnez . P_2 ; }
else { dtlgh5n2q0 = rtP_push_force ; } oyemd1o4v3 = g1j02kmnez . P_4 * *
kyulaudqfi ; jhqj5jbm2p = muDoubleScalarCos ( oyemd1o4v3 ) ; oyemd1o4v3 =
muDoubleScalarSin ( oyemd1o4v3 ) ; * feiau1mbpe = ( dtlgh5n2q0 * jhqj5jbm2p -
g1j02kmnez . P_5 * oyemd1o4v3 ) + * heqmcl4fj5 ; * p2gaq3opsn = ( dtlgh5n2q0
* oyemd1o4v3 + g1j02kmnez . P_5 * jhqj5jbm2p ) + * fdivlf50sk ; } void
calculate_collision_effectsTID1 ( void ) { } void izntqovil1 ( hy0y0nvofh *
const jjwe0heymi ) { if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( jjwe0heymi -> _mdlRefSfcnS ,
"calculate_collision_effects" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT"
) ; } } void l0cizwtudm ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 ,
int_T mdlref_TID1 , hy0y0nvofh * const jjwe0heymi , cymsckxckb * localB ,
kbuym0zbtf * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) jjwe0heymi , 0 , sizeof ( hy0y0nvofh ) ) ;
jjwe0heymi -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; jjwe0heymi ->
Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; jjwe0heymi -> _mdlRefSfcnS =
( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( jjwe0heymi -> _mdlRefSfcnS ,
"calculate_collision_effects" , "START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ;
} { localB -> p2cp4vwpta = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 ,
sizeof ( kbuym0zbtf ) ) ; calculate_collision_effects_InitializeDataMapInfo (
jjwe0heymi , localDW , sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != (
NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( *
rt_ParentMMI , rt_ChildMMIIdx , & ( jjwe0heymi -> DataMapInfo . mmi ) ) ;
rtwCAPI_SetPath ( jjwe0heymi -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( jjwe0heymi -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } } void mr_calculate_collision_effects_MdlInfoRegFcn (
SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal =
0 ; { boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_calculate_collision_effects , 44 ) ; * retVal = 1 ; } static void
mr_calculate_collision_effects_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_calculate_collision_effects_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_calculate_collision_effects_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_calculate_collision_effects_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy (
( uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_calculate_collision_effects_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_calculate_collision_effects_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_calculate_collision_effects_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_calculate_collision_effects_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_calculate_collision_effects_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_calculate_collision_effects_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_calculate_collision_effects_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_calculate_collision_effects_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_calculate_collision_effects_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void
mr_calculate_collision_effects_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_calculate_collision_effects_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T
mr_calculate_collision_effects_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_calculate_collision_effects_GetDWork
( const hsv52bpfnq0 * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] =
{ "rtb" , "rtdw" , "NULL->rtzce" , } ; mxArray * ssDW = mxCreateStructMatrix
( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_calculate_collision_effects_cacheDataAsMxArray ( ssDW , 0 , 0 , & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 1 ] = { "mdlrefDW->rtdw.e0hjvhmbxz" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 1 , rtdwDataFieldNames ) ;
mr_calculate_collision_effects_cacheDataAsMxArray ( rtdwData , 0 , 0 , & (
mdlrefDW -> rtdw . e0hjvhmbxz ) , sizeof ( mdlrefDW -> rtdw . e0hjvhmbxz ) )
; mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_calculate_collision_effects_SetDWork ( hsv52bpfnq0 * mdlrefDW , const
mxArray * ssDW ) { mr_calculate_collision_effects_restoreDataFromMxArray ( &
( mdlrefDW -> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const
mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_calculate_collision_effects_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. e0hjvhmbxz ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . e0hjvhmbxz )
) ; } } void mr_calculate_collision_effects_RegisterSimStateChecksum (
SimStruct * S ) { const uint32_T chksum [ 4 ] = { 2642652488U , 1080414232U ,
1854885286U , 1460422408U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"calculate_collision_effects" , & chksum [ 0 ] ) ; } mxArray *
mr_calculate_collision_effects_GetSimStateDisallowedBlocks ( ) { return NULL
; }
