#include "__cf_generate_proximity_sensor_re0.h"
#include "generate_proximity_sensor_re0_capi.h"
#include "generate_proximity_sensor_re0.h"
#include "generate_proximity_sensor_re0_private.h"
static RegMdlInfo rtMdlInfo_generate_proximity_sensor_re0 [ 46 ] = { {
"ni4fygtiycb" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "gulhnn5cq5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "f1zj1w5sii" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "antjn1tw0e" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "db2mqdf15y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "onw2klwvfu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "jtjh0o4cry" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "gx3d3ejdeu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "mzwk3obabu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "ogclxvgxbk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "gxmdy5cswd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "acuzzpstt1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "nllnikppmj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "jefqqgv1fi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "cwhbp0r4qv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "okbmyiapud" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "hcb3tyzth3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "hrxnzil02g" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "mst44ntd3h" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "generate_proximity_sensor_re0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "oamqb1uuyyl" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "bt5zenea32l" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "bhi44j5kjy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "dzwes0atayz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "nsvbmpbxfmy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "oamqb1uuyy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "bt5zenea32" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "mk4by1p4b2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "ex4gaboq54" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , { "knl0xklyur4" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "nqg40qhj3f4" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "ppw2dwepwsm" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_generate_proximity_sensor_re0_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "generate_proximity_sensor_re0" } , {
"mr_generate_proximity_sensor_re0_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "generate_proximity_sensor_re0" } , {
"generate_proximity_sensor_re0.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
NULL ) } , { "generate_proximity_sensor_re0.c" , MDL_INFO_MODEL_FILENAME , 0
, - 1 , ( void * ) "generate_proximity_sensor_re0" } } ; nj4ihpnw4px
nj4ihpnw4p = { 0.0 , - 1.0 , 1.0 , 0.0 , 0.0 , 1.0 , 9.4 , 9.4 , 9.4 , 9.4 ,
8.6 , 9.8 , 0.017453292519943295 , 0.017453292519943295 ,
0.017453292519943295 , 0.017453292519943295 } ; void
generate_proximity_sensor_re0 ( const real_T * a4ntjzxodx , const real_T *
bhay3qtkas , const real_T * c5tqlduzuf , const real_T * i52mdgtpfz , const
real_T * l4l1ogbmfg , const real_T * gencabw5dg , const real_T * aqsonb32cv ,
const real_T * clfc5juaeg , const real_T * o3tmv33fn2 , const real_T *
mbpdop3qfq , const real_T * lxfhj4ws5i , const real_T * i3fzeactka , real_T *
labgh33fh1 , real_T * lkanuak5ro , real_T * o3pc4zsma5 , acuzzpstt1 * localB
, gxmdy5cswd * localDW ) { real_T fsgjvxubxm ; real_T nwjupkcjpb ; real_T
lrmbda01n4 ; real_T ggdvcmioo0 ; fsgjvxubxm = nj4ihpnw4p . P_12 * *
c5tqlduzuf ; nwjupkcjpb = nj4ihpnw4p . P_13 * * gencabw5dg ; lrmbda01n4 =
nj4ihpnw4p . P_14 * * o3tmv33fn2 ; ggdvcmioo0 = nj4ihpnw4p . P_15 * *
i3fzeactka ; localB -> lnjkx4saip [ 0 ] = * a4ntjzxodx ; localB -> lnjkx4saip
[ 1 ] = * bhay3qtkas ; vector_rotation ( & fsgjvxubxm , & localB ->
hwdo2csdow [ 0 ] , & localB -> pfdxihs1su [ 0 ] ) ; bounding_box_calc (
i52mdgtpfz , l4l1ogbmfg , & nwjupkcjpb , & nj4ihpnw4p . P_6 , & nj4ihpnw4p .
P_7 , & localB -> jwzojjli23 [ 0 ] , & localB -> bgketlfezd [ 0 ] , & localB
-> acheaxua4v [ 0 ] , & localB -> cqhh2fob2y [ 0 ] ) ; bounding_box_calc (
aqsonb32cv , clfc5juaeg , & lrmbda01n4 , & nj4ihpnw4p . P_8 , & nj4ihpnw4p .
P_9 , & localB -> pw50lnxfdk [ 0 ] , & localB -> dpoilg0pmh [ 0 ] , & localB
-> haxlqgijs2 [ 0 ] , & localB -> dkquwl3rfb [ 0 ] ) ; bounding_box_calc (
mbpdop3qfq , lxfhj4ws5i , & ggdvcmioo0 , & nj4ihpnw4p . P_10 , & nj4ihpnw4p .
P_11 , & localB -> lhy0osyfwu [ 0 ] , & localB -> dclefz5xak [ 0 ] , & localB
-> df4nncxac0 [ 0 ] , & localB -> g2hfe3p2wc [ 0 ] ) ; prox_sensor_gen ( &
localB -> lnjkx4saip [ 0 ] , & localB -> pfdxihs1su [ 0 ] , & localB ->
acheaxua4v [ 0 ] , & localB -> cqhh2fob2y [ 0 ] , & localB -> jwzojjli23 [ 0
] , & localB -> bgketlfezd [ 0 ] , & localB -> haxlqgijs2 [ 0 ] , & localB ->
dkquwl3rfb [ 0 ] , & localB -> pw50lnxfdk [ 0 ] , & localB -> dpoilg0pmh [ 0
] , & localB -> df4nncxac0 [ 0 ] , & localB -> g2hfe3p2wc [ 0 ] , & localB ->
lhy0osyfwu [ 0 ] , & localB -> dclefz5xak [ 0 ] , labgh33fh1 , & ( localDW ->
f3wmnofr3j . rtb ) , & ( localDW -> f3wmnofr3j . rtdw ) ) ; localB ->
jsmzi2xarx [ 0 ] = * a4ntjzxodx ; localB -> jsmzi2xarx [ 1 ] = * bhay3qtkas ;
vector_rotation ( & fsgjvxubxm , & localB -> nn10stauoa [ 0 ] , & localB ->
hdgi5ot402 [ 0 ] ) ; prox_sensor_gen ( & localB -> jsmzi2xarx [ 0 ] , &
localB -> hdgi5ot402 [ 0 ] , & localB -> acheaxua4v [ 0 ] , & localB ->
cqhh2fob2y [ 0 ] , & localB -> jwzojjli23 [ 0 ] , & localB -> bgketlfezd [ 0
] , & localB -> haxlqgijs2 [ 0 ] , & localB -> dkquwl3rfb [ 0 ] , & localB ->
pw50lnxfdk [ 0 ] , & localB -> dpoilg0pmh [ 0 ] , & localB -> df4nncxac0 [ 0
] , & localB -> g2hfe3p2wc [ 0 ] , & localB -> lhy0osyfwu [ 0 ] , & localB ->
dclefz5xak [ 0 ] , lkanuak5ro , & ( localDW -> anpvbzoi4x . rtb ) , & (
localDW -> anpvbzoi4x . rtdw ) ) ; localB -> cvcjzcoco3 [ 0 ] = * a4ntjzxodx
; localB -> cvcjzcoco3 [ 1 ] = * bhay3qtkas ; vector_rotation ( & fsgjvxubxm
, & localB -> gavupw10as [ 0 ] , & localB -> goxuovexcl [ 0 ] ) ;
prox_sensor_gen ( & localB -> cvcjzcoco3 [ 0 ] , & localB -> goxuovexcl [ 0 ]
, & localB -> acheaxua4v [ 0 ] , & localB -> cqhh2fob2y [ 0 ] , & localB ->
jwzojjli23 [ 0 ] , & localB -> bgketlfezd [ 0 ] , & localB -> haxlqgijs2 [ 0
] , & localB -> dkquwl3rfb [ 0 ] , & localB -> pw50lnxfdk [ 0 ] , & localB ->
dpoilg0pmh [ 0 ] , & localB -> df4nncxac0 [ 0 ] , & localB -> g2hfe3p2wc [ 0
] , & localB -> lhy0osyfwu [ 0 ] , & localB -> dclefz5xak [ 0 ] , o3pc4zsma5
, & ( localDW -> cq2zbvyipn . rtb ) , & ( localDW -> cq2zbvyipn . rtdw ) ) ;
} void generate_proximity_sensor_re0TID1 ( acuzzpstt1 * localB ) { localB ->
gavupw10as [ 0 ] = nj4ihpnw4p . P_0 ; localB -> gavupw10as [ 1 ] = nj4ihpnw4p
. P_1 ; localB -> nn10stauoa [ 0 ] = nj4ihpnw4p . P_2 ; localB -> nn10stauoa
[ 1 ] = nj4ihpnw4p . P_3 ; localB -> hwdo2csdow [ 0 ] = nj4ihpnw4p . P_4 ;
localB -> hwdo2csdow [ 1 ] = nj4ihpnw4p . P_5 ; prox_sensor_genTID1 ( ) ;
prox_sensor_genTID1 ( ) ; prox_sensor_genTID1 ( ) ; } void jefqqgv1fi (
gxmdy5cswd * localDW , ex4gaboq54 * const f3p40zvy1f ) { f00xw1jonj ( & (
localDW -> i5asoaa1ng . rtm ) ) ; h2gdpdmrk4 ( & ( localDW -> jkr3xz2g0j .
rtm ) ) ; h2gdpdmrk4 ( & ( localDW -> hq00zkmfph . rtm ) ) ; h2gdpdmrk4 ( & (
localDW -> jzxoyutgbz . rtm ) ) ; b0y1amyfek ( & ( localDW -> f3wmnofr3j .
rtdw ) , & ( localDW -> f3wmnofr3j . rtm ) ) ; f00xw1jonj ( & ( localDW ->
elwd2cajxx . rtm ) ) ; b0y1amyfek ( & ( localDW -> anpvbzoi4x . rtdw ) , & (
localDW -> anpvbzoi4x . rtm ) ) ; f00xw1jonj ( & ( localDW -> cq5od40nau .
rtm ) ) ; b0y1amyfek ( & ( localDW -> cq2zbvyipn . rtdw ) , & ( localDW ->
cq2zbvyipn . rtm ) ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( f3p40zvy1f -> _mdlRefSfcnS ,
"generate_proximity_sensor_re0" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void hcb3tyzth3 (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , ex4gaboq54
* const f3p40zvy1f , acuzzpstt1 * localB , gxmdy5cswd * localDW , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( ( void * )
f3p40zvy1f , 0 , sizeof ( ex4gaboq54 ) ) ; f3p40zvy1f -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; f3p40zvy1f -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; f3p40zvy1f -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( f3p40zvy1f -> _mdlRefSfcnS ,
"generate_proximity_sensor_re0" , "START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" )
; } { localB -> lnjkx4saip [ 0 ] = 0.0 ; localB -> lnjkx4saip [ 1 ] = 0.0 ;
localB -> hwdo2csdow [ 0 ] = 0.0 ; localB -> hwdo2csdow [ 1 ] = 0.0 ; localB
-> pfdxihs1su [ 0 ] = 0.0 ; localB -> pfdxihs1su [ 1 ] = 0.0 ; localB ->
jwzojjli23 [ 0 ] = 0.0 ; localB -> jwzojjli23 [ 1 ] = 0.0 ; localB ->
bgketlfezd [ 0 ] = 0.0 ; localB -> bgketlfezd [ 1 ] = 0.0 ; localB ->
acheaxua4v [ 0 ] = 0.0 ; localB -> acheaxua4v [ 1 ] = 0.0 ; localB ->
cqhh2fob2y [ 0 ] = 0.0 ; localB -> cqhh2fob2y [ 1 ] = 0.0 ; localB ->
pw50lnxfdk [ 0 ] = 0.0 ; localB -> pw50lnxfdk [ 1 ] = 0.0 ; localB ->
dpoilg0pmh [ 0 ] = 0.0 ; localB -> dpoilg0pmh [ 1 ] = 0.0 ; localB ->
haxlqgijs2 [ 0 ] = 0.0 ; localB -> haxlqgijs2 [ 1 ] = 0.0 ; localB ->
dkquwl3rfb [ 0 ] = 0.0 ; localB -> dkquwl3rfb [ 1 ] = 0.0 ; localB ->
lhy0osyfwu [ 0 ] = 0.0 ; localB -> lhy0osyfwu [ 1 ] = 0.0 ; localB ->
dclefz5xak [ 0 ] = 0.0 ; localB -> dclefz5xak [ 1 ] = 0.0 ; localB ->
df4nncxac0 [ 0 ] = 0.0 ; localB -> df4nncxac0 [ 1 ] = 0.0 ; localB ->
g2hfe3p2wc [ 0 ] = 0.0 ; localB -> g2hfe3p2wc [ 1 ] = 0.0 ; localB ->
jsmzi2xarx [ 0 ] = 0.0 ; localB -> jsmzi2xarx [ 1 ] = 0.0 ; localB ->
nn10stauoa [ 0 ] = 0.0 ; localB -> nn10stauoa [ 1 ] = 0.0 ; localB ->
hdgi5ot402 [ 0 ] = 0.0 ; localB -> hdgi5ot402 [ 1 ] = 0.0 ; localB ->
cvcjzcoco3 [ 0 ] = 0.0 ; localB -> cvcjzcoco3 [ 1 ] = 0.0 ; localB ->
gavupw10as [ 0 ] = 0.0 ; localB -> gavupw10as [ 1 ] = 0.0 ; localB ->
goxuovexcl [ 0 ] = 0.0 ; localB -> goxuovexcl [ 1 ] = 0.0 ; } ( void ) memset
( ( void * ) localDW , 0 , sizeof ( gxmdy5cswd ) ) ;
generate_proximity_sensor_re0_InitializeDataMapInfo ( f3p40zvy1f , localDW ,
sysRanPtr , contextTid ) ; f5n4h5al41 ( _mdlRefSfcnS , mdlref_TID0 ,
mdlref_TID1 , & ( localDW -> f3wmnofr3j . rtm ) , & ( localDW -> f3wmnofr3j .
rtb ) , & ( localDW -> f3wmnofr3j . rtdw ) , f3p40zvy1f -> DataMapInfo .
systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo . systemTid [ 0 ] , & (
f3p40zvy1f -> DataMapInfo . mmi ) , "generate_proximity_sensor_re0/Model" , 0
, - 1 ) ; f5n4h5al41 ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW
-> anpvbzoi4x . rtm ) , & ( localDW -> anpvbzoi4x . rtb ) , & ( localDW ->
anpvbzoi4x . rtdw ) , f3p40zvy1f -> DataMapInfo . systemRan [ 0 ] ,
f3p40zvy1f -> DataMapInfo . systemTid [ 0 ] , & ( f3p40zvy1f -> DataMapInfo .
mmi ) , "generate_proximity_sensor_re0/Model1" , 1 , - 1 ) ; f5n4h5al41 (
_mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW -> cq2zbvyipn . rtm )
, & ( localDW -> cq2zbvyipn . rtb ) , & ( localDW -> cq2zbvyipn . rtdw ) ,
f3p40zvy1f -> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo .
systemTid [ 0 ] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/Model2" , 2 , - 1 ) ; bf1z3ni0yc (
_mdlRefSfcnS , mdlref_TID0 , & ( localDW -> jzxoyutgbz . rtm ) , f3p40zvy1f
-> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo . systemTid [ 0
] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/bounding_box_CollectorB" , 3 , - 1 ) ;
bf1z3ni0yc ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> jkr3xz2g0j . rtm ) ,
f3p40zvy1f -> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo .
systemTid [ 0 ] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/bounding_box_ScoutA" , 4 , - 1 ) ; bf1z3ni0yc
( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> hq00zkmfph . rtm ) , f3p40zvy1f
-> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo . systemTid [ 0
] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/bounding_box_ScoutB" , 5 , - 1 ) ; lsmrepqzwa
( _mdlRefSfcnS , mdlref_TID0 , & ( localDW -> elwd2cajxx . rtm ) , f3p40zvy1f
-> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f -> DataMapInfo . systemTid [ 0
] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/sensor_ray_generation front/vector_rotation" ,
6 , - 1 ) ; lsmrepqzwa ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW ->
i5asoaa1ng . rtm ) , f3p40zvy1f -> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f
-> DataMapInfo . systemTid [ 0 ] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/sensor_ray_generation left/vector_rotation" ,
7 , - 1 ) ; lsmrepqzwa ( _mdlRefSfcnS , mdlref_TID0 , & ( localDW ->
cq5od40nau . rtm ) , f3p40zvy1f -> DataMapInfo . systemRan [ 0 ] , f3p40zvy1f
-> DataMapInfo . systemTid [ 0 ] , & ( f3p40zvy1f -> DataMapInfo . mmi ) ,
"generate_proximity_sensor_re0/sensor_ray_generation right/vector_rotation" ,
8 , - 1 ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) )
) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( f3p40zvy1f ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( f3p40zvy1f -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( f3p40zvy1f ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_generate_proximity_sensor_re0_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_prox_sensor_gen_MdlInfoRegFcn ( mdlRefSfcnS , "prox_sensor_gen" , retVal )
; if ( * retVal == 0 ) return ; * retVal = 0 ;
mr_bounding_box_calc_MdlInfoRegFcn ( mdlRefSfcnS , "bounding_box_calc" ,
retVal ) ; if ( * retVal == 0 ) return ; * retVal = 0 ;
mr_vector_rotation_MdlInfoRegFcn ( mdlRefSfcnS , "vector_rotation" , retVal )
; if ( * retVal == 0 ) return ; * retVal = 0 ; } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_generate_proximity_sensor_re0 , 46 ) ; * retVal = 1 ; } static void
mr_generate_proximity_sensor_re0_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_generate_proximity_sensor_re0_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_generate_proximity_sensor_re0_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_generate_proximity_sensor_re0_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_generate_proximity_sensor_re0_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) ; static void
mr_generate_proximity_sensor_re0_cacheBitFieldToMxArray ( mxArray * destArray
, mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i ,
j , mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_generate_proximity_sensor_re0_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_generate_proximity_sensor_re0_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_generate_proximity_sensor_re0_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_generate_proximity_sensor_re0_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_generate_proximity_sensor_re0_restoreDataFromMxArrayWithOffset ( void
* destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_generate_proximity_sensor_re0_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_generate_proximity_sensor_re0_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void
mr_generate_proximity_sensor_re0_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_generate_proximity_sensor_re0_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) ; static uint_T
mr_generate_proximity_sensor_re0_extractBitFieldFromCellArrayWithOffset (
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T
numBits ) { const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray *
mr_generate_proximity_sensor_re0_GetDWork ( const ni4fygtiycb * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_generate_proximity_sensor_re0_cacheDataAsMxArray ( ssDW , 0 , 0 , & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 9 ] = { "mdlrefDW->rtdw.i5asoaa1ng" ,
"mdlrefDW->rtdw.jkr3xz2g0j" , "mdlrefDW->rtdw.hq00zkmfph" ,
"mdlrefDW->rtdw.jzxoyutgbz" , "mdlrefDW->rtdw.f3wmnofr3j" ,
"mdlrefDW->rtdw.elwd2cajxx" , "mdlrefDW->rtdw.anpvbzoi4x" ,
"mdlrefDW->rtdw.cq5od40nau" , "mdlrefDW->rtdw.cq2zbvyipn" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 9 , rtdwDataFieldNames ) ; {
mxArray * varData = mr_vector_rotation_GetDWork ( & ( mdlrefDW -> rtdw .
i5asoaa1ng ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } {
mxArray * varData = mr_bounding_box_calc_GetDWork ( & ( mdlrefDW -> rtdw .
jkr3xz2g0j ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } {
mxArray * varData = mr_bounding_box_calc_GetDWork ( & ( mdlrefDW -> rtdw .
hq00zkmfph ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 2 , varData ) ; } {
mxArray * varData = mr_bounding_box_calc_GetDWork ( & ( mdlrefDW -> rtdw .
jzxoyutgbz ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 3 , varData ) ; } {
mxArray * varData = mr_prox_sensor_gen_GetDWork ( & ( mdlrefDW -> rtdw .
f3wmnofr3j ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 4 , varData ) ; } {
mxArray * varData = mr_vector_rotation_GetDWork ( & ( mdlrefDW -> rtdw .
elwd2cajxx ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 5 , varData ) ; } {
mxArray * varData = mr_prox_sensor_gen_GetDWork ( & ( mdlrefDW -> rtdw .
anpvbzoi4x ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 6 , varData ) ; } {
mxArray * varData = mr_vector_rotation_GetDWork ( & ( mdlrefDW -> rtdw .
cq5od40nau ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 7 , varData ) ; } {
mxArray * varData = mr_prox_sensor_gen_GetDWork ( & ( mdlrefDW -> rtdw .
cq2zbvyipn ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 8 , varData ) ; }
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_generate_proximity_sensor_re0_SetDWork ( ni4fygtiycb * mdlrefDW , const
mxArray * ssDW ) { mr_generate_proximity_sensor_re0_restoreDataFromMxArray (
& ( mdlrefDW -> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const
mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_vector_rotation_SetDWork ( & ( mdlrefDW -> rtdw . i5asoaa1ng ) ,
mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ; mr_bounding_box_calc_SetDWork ( &
( mdlrefDW -> rtdw . jkr3xz2g0j ) , mxGetFieldByNumber ( rtdwData , 0 , 1 ) )
; mr_bounding_box_calc_SetDWork ( & ( mdlrefDW -> rtdw . hq00zkmfph ) ,
mxGetFieldByNumber ( rtdwData , 0 , 2 ) ) ; mr_bounding_box_calc_SetDWork ( &
( mdlrefDW -> rtdw . jzxoyutgbz ) , mxGetFieldByNumber ( rtdwData , 0 , 3 ) )
; mr_prox_sensor_gen_SetDWork ( & ( mdlrefDW -> rtdw . f3wmnofr3j ) ,
mxGetFieldByNumber ( rtdwData , 0 , 4 ) ) ; mr_vector_rotation_SetDWork ( & (
mdlrefDW -> rtdw . elwd2cajxx ) , mxGetFieldByNumber ( rtdwData , 0 , 5 ) ) ;
mr_prox_sensor_gen_SetDWork ( & ( mdlrefDW -> rtdw . anpvbzoi4x ) ,
mxGetFieldByNumber ( rtdwData , 0 , 6 ) ) ; mr_vector_rotation_SetDWork ( & (
mdlrefDW -> rtdw . cq5od40nau ) , mxGetFieldByNumber ( rtdwData , 0 , 7 ) ) ;
mr_prox_sensor_gen_SetDWork ( & ( mdlrefDW -> rtdw . cq2zbvyipn ) ,
mxGetFieldByNumber ( rtdwData , 0 , 8 ) ) ; } } void
mr_generate_proximity_sensor_re0_RegisterSimStateChecksum ( SimStruct * S ) {
const uint32_T chksum [ 4 ] = { 753641169U , 3817535015U , 639824852U ,
282376227U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"generate_proximity_sensor_re0" , & chksum [ 0 ] ) ;
mr_bounding_box_calc_RegisterSimStateChecksum ( S ) ;
mr_prox_sensor_gen_RegisterSimStateChecksum ( S ) ;
mr_vector_rotation_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_generate_proximity_sensor_re0_GetSimStateDisallowedBlocks ( ) { mxArray *
data = NULL ; size_t numChildrenWithDisallowedBlocks = 0 ; size_t numBlocks =
0 ; mxArray * disallowedBlocksInChild [ 3 ] ; disallowedBlocksInChild [ 0 ] =
mr_bounding_box_calc_GetSimStateDisallowedBlocks ( ) ;
disallowedBlocksInChild [ 1 ] =
mr_prox_sensor_gen_GetSimStateDisallowedBlocks ( ) ; disallowedBlocksInChild
[ 2 ] = mr_vector_rotation_GetSimStateDisallowedBlocks ( ) ; { size_t i ; for
( i = 0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [ i ] ;
if ( NULL != data_i ) { if ( 0 == numChildrenWithDisallowedBlocks ++ ) { data
= data_i ; } numBlocks += mxGetM ( data_i ) ; } } } if (
numChildrenWithDisallowedBlocks > 1 ) { mwIndex subs [ 2 ] , offset ; data =
mxCreateCellMatrix ( numBlocks , 3 ) ; subs [ 0 ] = 0 ; { size_t i ; for ( i
= 0 ; i < 3 ; ++ i ) { mxArray * data_i = disallowedBlocksInChild [ i ] ; if
( NULL != data_i ) { mwIndex subs_i [ 2 ] , offset_i ; const mwIndex
numRows_i = ( mwIndex ) mxGetM ( data_i ) ; for ( subs_i [ 0 ] = 0 ; subs_i [
0 ] < numRows_i ; ++ ( subs_i [ 0 ] ) ) { mwIndex j ; for ( j = 0 ; j < 3 ;
++ j ) { mxArray * data_ij ; subs_i [ 1 ] = j ; offset_i =
mxCalcSingleSubscript ( data_i , 2 , subs_i ) ; data_ij = mxGetCell ( data_i
, offset_i ) ; data_ij = mxDuplicateArray ( data_ij ) ; subs [ 1 ] = j ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , data_ij ) ; } ++ ( subs [ 0 ] ) ; } mxDestroyArray ( data_i ) ; } }
} } return data ; }
