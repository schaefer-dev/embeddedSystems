#include "__cf_generate_proximity_sensor_re0.h"
#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "generate_proximity_sensor_re0_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "generate_proximity_sensor_re0.h"
#include "generate_proximity_sensor_re0_capi.h"
#include "generate_proximity_sensor_re0_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , - 1
, ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1 , 0 } } ;
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "" , "" , 0 ,
0 , 0 , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 0 , 0 } } ; static uint_T rtDimensionArray [ ] = { 0 } ;
static rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( NULL ) , ( NULL ) , 0 , 0 } } ; static int_T
rtContextSystems [ 2 ] ; static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] =
{ { 0 , 0 , "" , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 2 , rtContextSystems , loggingMetaInfo , 0 , NULL ,
{ 0 , NULL , NULL } , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL
) , 0 , ( NULL ) , 0 } , { rtBlockStates , 0 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 3667562410U , 294191955U , 2375307126U ,
2662679742U } , & mmiStaticInfoLogging , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo *
generate_proximity_sensor_re0_GetCAPIStaticMap ( void ) { return & mmiStatic
; }
#ifndef HOST_CAPI_BUILD
static void generate_proximity_sensor_re0_InitializeSystemRan ( ex4gaboq54 *
const f3p40zvy1f , sysRanDType * systemRan [ ] , gxmdy5cswd * localDW , int_T
systemTid [ ] , void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER (
f3p40zvy1f ) ; UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType
* ) rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemTid [ 1 ] = f3p40zvy1f
-> Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ;
rtContextSystems [ 0 ] = 0 ; rtContextSystems [ 1 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void generate_proximity_sensor_re0_InitializeDataMapInfo ( ex4gaboq54 * const
f3p40zvy1f , gxmdy5cswd * localDW , void * sysRanPtr , int contextTid ) {
rtwCAPI_SetVersion ( f3p40zvy1f -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( f3p40zvy1f -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( f3p40zvy1f -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; rtwCAPI_SetPath ( f3p40zvy1f -> DataMapInfo . mmi ,
( NULL ) ) ; rtwCAPI_SetFullPath ( f3p40zvy1f -> DataMapInfo . mmi , ( NULL )
) ; rtwCAPI_SetInstanceLoggingInfo ( f3p40zvy1f -> DataMapInfo . mmi , &
f3p40zvy1f -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
f3p40zvy1f -> DataMapInfo . mmi , f3p40zvy1f -> DataMapInfo . childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( f3p40zvy1f -> DataMapInfo . mmi , 9 ) ;
generate_proximity_sensor_re0_InitializeSystemRan ( f3p40zvy1f , f3p40zvy1f
-> DataMapInfo . systemRan , localDW , f3p40zvy1f -> DataMapInfo . systemTid
, sysRanPtr , contextTid ) ; rtwCAPI_SetSystemRan ( f3p40zvy1f -> DataMapInfo
. mmi , f3p40zvy1f -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid (
f3p40zvy1f -> DataMapInfo . mmi , f3p40zvy1f -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( f3p40zvy1f -> DataMapInfo . mmi , & f3p40zvy1f ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void generate_proximity_sensor_re0_host_InitializeDataMapInfo (
generate_proximity_sensor_re0_host_DataMapInfo_T * dataMap , const char *
path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap (
dataMap -> mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi ,
NULL ) ; rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetPath ( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap ->
mmi , NULL ) ; dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
prox_sensor_gen_host_InitializeDataMapInfo ( & ( dataMap -> child0 ) ,
"generate_proximity_sensor_re0/Model" ) ; dataMap -> childMMI [ 1 ] = & (
dataMap -> child1 . mmi ) ; prox_sensor_gen_host_InitializeDataMapInfo ( & (
dataMap -> child1 ) , "generate_proximity_sensor_re0/Model1" ) ; dataMap ->
childMMI [ 2 ] = & ( dataMap -> child2 . mmi ) ;
prox_sensor_gen_host_InitializeDataMapInfo ( & ( dataMap -> child2 ) ,
"generate_proximity_sensor_re0/Model2" ) ; dataMap -> childMMI [ 3 ] = & (
dataMap -> child3 . mmi ) ; bounding_box_calc_host_InitializeDataMapInfo ( &
( dataMap -> child3 ) ,
"generate_proximity_sensor_re0/bounding_box_CollectorB" ) ; dataMap ->
childMMI [ 4 ] = & ( dataMap -> child4 . mmi ) ;
bounding_box_calc_host_InitializeDataMapInfo ( & ( dataMap -> child4 ) ,
"generate_proximity_sensor_re0/bounding_box_ScoutA" ) ; dataMap -> childMMI [
5 ] = & ( dataMap -> child5 . mmi ) ;
bounding_box_calc_host_InitializeDataMapInfo ( & ( dataMap -> child5 ) ,
"generate_proximity_sensor_re0/bounding_box_ScoutB" ) ; dataMap -> childMMI [
6 ] = & ( dataMap -> child6 . mmi ) ;
vector_rotation_host_InitializeDataMapInfo ( & ( dataMap -> child6 ) ,
"generate_proximity_sensor_re0/sensor_ray_generation front/vector_rotation" )
; dataMap -> childMMI [ 7 ] = & ( dataMap -> child7 . mmi ) ;
vector_rotation_host_InitializeDataMapInfo ( & ( dataMap -> child7 ) ,
"generate_proximity_sensor_re0/sensor_ray_generation left/vector_rotation" )
; dataMap -> childMMI [ 8 ] = & ( dataMap -> child8 . mmi ) ;
vector_rotation_host_InitializeDataMapInfo ( & ( dataMap -> child8 ) ,
"generate_proximity_sensor_re0/sensor_ray_generation right/vector_rotation" )
; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , dataMap -> childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 9 ) ; }
#ifdef __cplusplus
}
#endif
#endif
