#include "__cf_collision.h"
#include "collision_capi.h"
#include "collision.h"
#include "collision_private.h"
static RegMdlInfo rtMdlInfo_collision [ 45 ] = { { "i5cbqmfwwz0" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "collision" } , {
"dq3jajg0ti" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "pidisey1bb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "d4u1yd5tyi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "b5tccas4qz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"e0jc53xwzr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "hon15lwy23" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "hoarzml5yr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "kh1gpzfj5o" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"bzofyh1bzq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "mhv1pvkcyj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "ht25has4vg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "ozvtd1q3vm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"a20usbo2aj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "oug0qlpd4m" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "eb5c3fnz2v" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "ev3vbnc2e0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"en4ldfvxah" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "jh4mwjzjdl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "krbn5m4v0u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "collision" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "pklr0bqjkhz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"prfygdkyk51" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "feqxisz35z" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "ojrp0dizsyg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "kwj0jxngiwy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"pklr0bqjkh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"collision" } , { "prfygdkyk5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "collision" } , { "p05g1t1tav" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "collision" } , { "ishptvov2y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "collision" } , {
"jv23mlr3c55" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_collision_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "collision" } , {
"mr_collision_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "collision" } , {
"mr_collision_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "collision" } , { "mr_collision_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "collision" } , { "mr_collision_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "collision" } , { "mr_collision_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "collision" } , {
"mr_collision_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"collision" } , { "collision.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "collision.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"collision" } } ; void jh4mwjzjdl ( mhv1pvkcyj * localDW ) { l4wp2x1qk5 ( & (
localDW -> hru0hqvv0x . rtdw ) ) ; l4wp2x1qk5 ( & ( localDW -> atpdaywep1 .
rtdw ) ) ; l4wp2x1qk5 ( & ( localDW -> fshvuxysp5 . rtdw ) ) ; l4wp2x1qk5 ( &
( localDW -> pr1skhjatf . rtdw ) ) ; l4wp2x1qk5 ( & ( localDW -> lplgcbmmyo .
rtdw ) ) ; l4wp2x1qk5 ( & ( localDW -> h4klopvvfg . rtdw ) ) ; } void
eb5c3fnz2v ( mhv1pvkcyj * localDW , dq3jajg0ti * localZCSV ) { a5luif514d ( &
( localDW -> hru0hqvv0x . rtb ) , & ( localDW -> hru0hqvv0x . rtdw ) , & (
localZCSV -> jqdfh500kc ) ) ; a5luif514d ( & ( localDW -> atpdaywep1 . rtb )
, & ( localDW -> atpdaywep1 . rtdw ) , & ( localZCSV -> cmqp3loboe ) ) ;
a5luif514d ( & ( localDW -> fshvuxysp5 . rtb ) , & ( localDW -> fshvuxysp5 .
rtdw ) , & ( localZCSV -> g5yc3fesen ) ) ; a5luif514d ( & ( localDW ->
pr1skhjatf . rtb ) , & ( localDW -> pr1skhjatf . rtdw ) , & ( localZCSV ->
a1rtgwbnyy ) ) ; a5luif514d ( & ( localDW -> lplgcbmmyo . rtb ) , & ( localDW
-> lplgcbmmyo . rtdw ) , & ( localZCSV -> g1bn0df1i4 ) ) ; a5luif514d ( & (
localDW -> h4klopvvfg . rtb ) , & ( localDW -> h4klopvvfg . rtdw ) , & (
localZCSV -> ns2cpkwwav ) ) ; } void collision ( const real_T * gkloj4hzlb ,
const real_T * j1ntxvbrk5 , const real_T * l3s3v2wbkr , const real_T *
htxdzzbpn3 , const real_T * jxj00te4ne , const real_T * e122ug3oyh , const
real_T * lpoxms4fcu , const real_T * i3nklqgaak , const real_T * mquz5dyheg ,
const real_T * l3yfwmf5hz , const real_T * oe5gonrsst , const real_T *
k2pttrruzv , real_T * dblbyfnrxa , real_T * epg2gonkjy , real_T * o45q3bqjts
, real_T * plxqca0zr5 , real_T * dl0wv41ziq , real_T * if2wf341a1 , real_T *
bdu4hcldkp , real_T * bvag4tknzl , real_T * h1e55gq14z , real_T * ajqacg4ysm
, real_T * ihnu4otolg , real_T * p4wsiql0dx , ht25has4vg * localB ,
mhv1pvkcyj * localDW ) { collide_between ( & ( localDW -> hru0hqvv0x . rtm )
, htxdzzbpn3 , jxj00te4ne , e122ug3oyh , l3yfwmf5hz , oe5gonrsst , k2pttrruzv
, & localB -> bxlguqnbhj , & localB -> kfgoqwrqzh , & localB -> h1lu1qlg4x ,
& localB -> f45hwaolrm , & localB -> gt3ze33ar2 , & localB -> jc5xubbrgx , &
( localDW -> hru0hqvv0x . rtb ) , & ( localDW -> hru0hqvv0x . rtdw ) ) ;
collide_between ( & ( localDW -> atpdaywep1 . rtm ) , gkloj4hzlb , j1ntxvbrk5
, l3s3v2wbkr , lpoxms4fcu , i3nklqgaak , mquz5dyheg , & localB -> fnbne5xx21
, & localB -> pz5jgtsos1 , & localB -> i13g4wrwzw , & localB -> ngyzezn00s ,
& localB -> n0vfxvswvx , & localB -> ppmum2uzrg , & ( localDW -> atpdaywep1 .
rtb ) , & ( localDW -> atpdaywep1 . rtdw ) ) ; collide_between ( & ( localDW
-> fshvuxysp5 . rtm ) , & localB -> bxlguqnbhj , & localB -> kfgoqwrqzh , &
localB -> h1lu1qlg4x , & localB -> fnbne5xx21 , & localB -> pz5jgtsos1 , &
localB -> i13g4wrwzw , & localB -> l1wb2iywhr , & localB -> k5ufmolx0d , &
localB -> d34zkelbi1 , & localB -> pcag2t1zgz , & localB -> ha4j0kuomf , &
localB -> co4fqbcbru , & ( localDW -> fshvuxysp5 . rtb ) , & ( localDW ->
fshvuxysp5 . rtdw ) ) ; collide_between ( & ( localDW -> pr1skhjatf . rtm ) ,
& localB -> f45hwaolrm , & localB -> gt3ze33ar2 , & localB -> jc5xubbrgx , &
localB -> ngyzezn00s , & localB -> n0vfxvswvx , & localB -> ppmum2uzrg , &
localB -> kdkajqjise , & localB -> eyv20szcju , & localB -> fb3ercztxy , &
localB -> bmvglm4fyq , & localB -> hsjaavowst , & localB -> gwjda0xlou , & (
localDW -> pr1skhjatf . rtb ) , & ( localDW -> pr1skhjatf . rtdw ) ) ;
collide_between ( & ( localDW -> lplgcbmmyo . rtm ) , & localB -> l1wb2iywhr
, & localB -> k5ufmolx0d , & localB -> d34zkelbi1 , & localB -> bmvglm4fyq ,
& localB -> hsjaavowst , & localB -> gwjda0xlou , plxqca0zr5 , dl0wv41ziq ,
if2wf341a1 , bdu4hcldkp , bvag4tknzl , h1e55gq14z , & ( localDW -> lplgcbmmyo
. rtb ) , & ( localDW -> lplgcbmmyo . rtdw ) ) ; collide_between ( & (
localDW -> h4klopvvfg . rtm ) , & localB -> kdkajqjise , & localB ->
eyv20szcju , & localB -> fb3ercztxy , & localB -> pcag2t1zgz , & localB ->
ha4j0kuomf , & localB -> co4fqbcbru , ajqacg4ysm , ihnu4otolg , p4wsiql0dx ,
dblbyfnrxa , epg2gonkjy , o45q3bqjts , & ( localDW -> h4klopvvfg . rtb ) , &
( localDW -> h4klopvvfg . rtdw ) ) ; } void collisionTID1 ( void ) {
collide_betweenTID1 ( ) ; collide_betweenTID1 ( ) ; collide_betweenTID1 ( ) ;
collide_betweenTID1 ( ) ; collide_betweenTID1 ( ) ; collide_betweenTID1 ( ) ;
} void a20usbo2aj ( mhv1pvkcyj * localDW , ishptvov2y * const dzwbd2guxb ) {
la13zfc2mh ( & ( localDW -> hru0hqvv0x . rtdw ) , & ( localDW -> hru0hqvv0x .
rtm ) ) ; la13zfc2mh ( & ( localDW -> atpdaywep1 . rtdw ) , & ( localDW ->
atpdaywep1 . rtm ) ) ; la13zfc2mh ( & ( localDW -> fshvuxysp5 . rtdw ) , & (
localDW -> fshvuxysp5 . rtm ) ) ; la13zfc2mh ( & ( localDW -> pr1skhjatf .
rtdw ) , & ( localDW -> pr1skhjatf . rtm ) ) ; la13zfc2mh ( & ( localDW ->
lplgcbmmyo . rtdw ) , & ( localDW -> lplgcbmmyo . rtm ) ) ; la13zfc2mh ( & (
localDW -> h4klopvvfg . rtdw ) , & ( localDW -> h4klopvvfg . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( dzwbd2guxb ->
_mdlRefSfcnS , "collision" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ;
} } void en4ldfvxah ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , ishptvov2y * const dzwbd2guxb , ht25has4vg * localB ,
mhv1pvkcyj * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; ( void ) memset ( ( void * ) dzwbd2guxb , 0 , sizeof ( ishptvov2y ) ) ;
dzwbd2guxb -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; dzwbd2guxb ->
Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; dzwbd2guxb -> _mdlRefSfcnS =
( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( dzwbd2guxb -> _mdlRefSfcnS , "collision" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> bxlguqnbhj = 0.0
; localB -> kfgoqwrqzh = 0.0 ; localB -> h1lu1qlg4x = 0.0 ; localB ->
f45hwaolrm = 0.0 ; localB -> gt3ze33ar2 = 0.0 ; localB -> jc5xubbrgx = 0.0 ;
localB -> fnbne5xx21 = 0.0 ; localB -> pz5jgtsos1 = 0.0 ; localB ->
i13g4wrwzw = 0.0 ; localB -> ngyzezn00s = 0.0 ; localB -> n0vfxvswvx = 0.0 ;
localB -> ppmum2uzrg = 0.0 ; localB -> l1wb2iywhr = 0.0 ; localB ->
k5ufmolx0d = 0.0 ; localB -> d34zkelbi1 = 0.0 ; localB -> pcag2t1zgz = 0.0 ;
localB -> ha4j0kuomf = 0.0 ; localB -> co4fqbcbru = 0.0 ; localB ->
kdkajqjise = 0.0 ; localB -> eyv20szcju = 0.0 ; localB -> fb3ercztxy = 0.0 ;
localB -> bmvglm4fyq = 0.0 ; localB -> hsjaavowst = 0.0 ; localB ->
gwjda0xlou = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
mhv1pvkcyj ) ) ; collision_InitializeDataMapInfo ( dzwbd2guxb , localDW ,
sysRanPtr , contextTid ) ; hzpcsj4xge ( _mdlRefSfcnS , mdlref_TID0 ,
mdlref_TID1 , & ( localDW -> hru0hqvv0x . rtm ) , & ( localDW -> hru0hqvv0x .
rtb ) , & ( localDW -> hru0hqvv0x . rtdw ) , dzwbd2guxb -> DataMapInfo .
systemRan [ 0 ] , dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] , & (
dzwbd2guxb -> DataMapInfo . mmi ) , "collision/CA x CB" , 0 , - 1 ) ;
hzpcsj4xge ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW ->
fshvuxysp5 . rtm ) , & ( localDW -> fshvuxysp5 . rtb ) , & ( localDW ->
fshvuxysp5 . rtdw ) , dzwbd2guxb -> DataMapInfo . systemRan [ 0 ] ,
dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] , & ( dzwbd2guxb -> DataMapInfo .
mmi ) , "collision/CA x SA" , 1 , - 1 ) ; hzpcsj4xge ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , & ( localDW -> lplgcbmmyo . rtm ) , & ( localDW
-> lplgcbmmyo . rtb ) , & ( localDW -> lplgcbmmyo . rtdw ) , dzwbd2guxb ->
DataMapInfo . systemRan [ 0 ] , dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] ,
& ( dzwbd2guxb -> DataMapInfo . mmi ) , "collision/CA x SB" , 2 , - 1 ) ;
hzpcsj4xge ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW ->
h4klopvvfg . rtm ) , & ( localDW -> h4klopvvfg . rtb ) , & ( localDW ->
h4klopvvfg . rtdw ) , dzwbd2guxb -> DataMapInfo . systemRan [ 0 ] ,
dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] , & ( dzwbd2guxb -> DataMapInfo .
mmi ) , "collision/CB x SA" , 3 , - 1 ) ; hzpcsj4xge ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , & ( localDW -> pr1skhjatf . rtm ) , & ( localDW
-> pr1skhjatf . rtb ) , & ( localDW -> pr1skhjatf . rtdw ) , dzwbd2guxb ->
DataMapInfo . systemRan [ 0 ] , dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] ,
& ( dzwbd2guxb -> DataMapInfo . mmi ) , "collision/CB x SB" , 4 , - 1 ) ;
hzpcsj4xge ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW ->
atpdaywep1 . rtm ) , & ( localDW -> atpdaywep1 . rtb ) , & ( localDW ->
atpdaywep1 . rtdw ) , dzwbd2guxb -> DataMapInfo . systemRan [ 0 ] ,
dzwbd2guxb -> DataMapInfo . systemTid [ 0 ] , & ( dzwbd2guxb -> DataMapInfo .
mmi ) , "collision/SA x SB" , 5 , - 1 ) ; if ( ( rt_ParentMMI != ( NULL ) )
&& ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( dzwbd2guxb -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
dzwbd2guxb -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( dzwbd2guxb -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } } void mr_collision_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal = 0 ; {
boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_collide_between_MdlInfoRegFcn ( mdlRefSfcnS , "collide_between" , retVal )
; if ( * retVal == 0 ) return ; * retVal = 0 ; } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName , rtMdlInfo_collision , 45 ) ;
* retVal = 1 ; } static void mr_collision_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_collision_cacheDataAsMxArray ( mxArray * destArray , mwIndex i
, int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_collision_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_collision_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_collision_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_collision_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_collision_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_collision_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_collision_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_collision_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_collision_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_collision_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_collision_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_collision_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_collision_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_collision_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_collision_GetDWork ( const i5cbqmfwwz0 * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_collision_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 6 ]
= { "mdlrefDW->rtdw.hru0hqvv0x" , "mdlrefDW->rtdw.atpdaywep1" ,
"mdlrefDW->rtdw.fshvuxysp5" , "mdlrefDW->rtdw.pr1skhjatf" ,
"mdlrefDW->rtdw.lplgcbmmyo" , "mdlrefDW->rtdw.h4klopvvfg" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 6 , rtdwDataFieldNames ) ; {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
hru0hqvv0x ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
atpdaywep1 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
fshvuxysp5 ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 2 , varData ) ; } {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
pr1skhjatf ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 3 , varData ) ; } {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
lplgcbmmyo ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 4 , varData ) ; } {
mxArray * varData = mr_collide_between_GetDWork ( & ( mdlrefDW -> rtdw .
h4klopvvfg ) ) ; mxSetFieldByNumber ( rtdwData , 0 , 5 , varData ) ; }
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_collision_SetDWork ( i5cbqmfwwz0 * mdlrefDW , const mxArray * ssDW ) {
mr_collision_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 ,
sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_collide_between_SetDWork ( & (
mdlrefDW -> rtdw . hru0hqvv0x ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_collide_between_SetDWork ( & ( mdlrefDW -> rtdw . atpdaywep1 ) ,
mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ; mr_collide_between_SetDWork ( & (
mdlrefDW -> rtdw . fshvuxysp5 ) , mxGetFieldByNumber ( rtdwData , 0 , 2 ) ) ;
mr_collide_between_SetDWork ( & ( mdlrefDW -> rtdw . pr1skhjatf ) ,
mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ; mr_collide_between_SetDWork ( & (
mdlrefDW -> rtdw . lplgcbmmyo ) , mxGetFieldByNumber ( rtdwData , 0 , 4 ) ) ;
mr_collide_between_SetDWork ( & ( mdlrefDW -> rtdw . h4klopvvfg ) ,
mxGetFieldByNumber ( rtdwData , 0 , 5 ) ) ; } } void
mr_collision_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 4035530180U , 4073240390U , 3005337389U , 1262753908U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "collision" , & chksum [ 0 ] ) ;
mr_collide_between_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_collision_GetSimStateDisallowedBlocks ( ) { return
mr_collide_between_GetSimStateDisallowedBlocks ( ) ; }
