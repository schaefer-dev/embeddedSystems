#include "__cf_bounding_box_calc.h"
#include "bounding_box_calc_capi.h"
#include "bounding_box_calc.h"
#include "bounding_box_calc_private.h"
static RegMdlInfo rtMdlInfo_bounding_box_calc [ 41 ] = { { "nqg40qhj3f4" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"crv0ubxwt0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "opq2yezytb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "eyst1ls41l" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "n114c32bkn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "lzcw0ginaj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "e1sjxqeibh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "nyruxahrbl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "chknt05uii" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "nex2dntall" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "dkfkyok50s" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "f4yjnijrdf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "fsjxlk0mrz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "h2gdpdmrk4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "ego2pvt2zr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "h24w30vr5d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "bf1z3ni0yc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "eru0pkj0qj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "po3ivxl4rs" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "bounding_box_calc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL )
} , { "p0xxksfccwj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "f2220z4n2k3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "bounding_box_calc" } , { "jmob1m1owh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "p0xxksfccw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "f2220z4n2k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "bounding_box_calc" } , { "gn2abovwjx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "bounding_box_calc" }
, { "nikjwnz44k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"bounding_box_calc" } , { "mr_bounding_box_calc_GetSimStateDisallowedBlocks"
, MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"mr_bounding_box_calc_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "bounding_box_calc" } , { "mr_bounding_box_calc_GetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "bounding_box_calc" } , {
"bounding_box_calc.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"bounding_box_calc.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"bounding_box_calc" } } ; e2klae1qjai e2klae1qja = { 0.5 , 0.5 , - 1.0 } ;
void bounding_box_calc ( const real_T * jjbxzcy0lp , const real_T *
bbfanegn12 , const real_T * d3de04htl3 , const real_T * maa0g5htwv , const
real_T * bnsoia3t3n , real_T nsr34uzau5 [ 2 ] , real_T fecvxcduov [ 2 ] ,
real_T dwf1n3odio [ 2 ] , real_T jq2pu4fofk [ 2 ] ) { real_T kb0t2zk0he ;
real_T lciyaw3heq ; real_T kudshkyacj_idx_0 ; real_T kudshkyacj_idx_1 ;
real_T dnuwh2aeab_idx_0 ; real_T dpgxnf31yd_tmp ; real_T fs4zlcxotp_tmp ;
kb0t2zk0he = e2klae1qja . P_0 * * maa0g5htwv ; dpgxnf31yd_tmp =
muDoubleScalarCos ( * d3de04htl3 ) ; lciyaw3heq = e2klae1qja . P_1 * *
bnsoia3t3n ; fs4zlcxotp_tmp = muDoubleScalarSin ( * d3de04htl3 ) ;
kudshkyacj_idx_0 = kb0t2zk0he * dpgxnf31yd_tmp - lciyaw3heq * fs4zlcxotp_tmp
; kudshkyacj_idx_1 = kb0t2zk0he * fs4zlcxotp_tmp + lciyaw3heq *
dpgxnf31yd_tmp ; kb0t2zk0he *= e2klae1qja . P_2 ; dnuwh2aeab_idx_0 =
kb0t2zk0he * dpgxnf31yd_tmp - lciyaw3heq * fs4zlcxotp_tmp ; kb0t2zk0he =
kb0t2zk0he * fs4zlcxotp_tmp + lciyaw3heq * dpgxnf31yd_tmp ; jq2pu4fofk [ 0 ]
= * jjbxzcy0lp + kudshkyacj_idx_0 ; dwf1n3odio [ 0 ] = * jjbxzcy0lp +
dnuwh2aeab_idx_0 ; fecvxcduov [ 0 ] = * jjbxzcy0lp - kudshkyacj_idx_0 ;
nsr34uzau5 [ 0 ] = * jjbxzcy0lp - dnuwh2aeab_idx_0 ; jq2pu4fofk [ 1 ] = *
bbfanegn12 + kudshkyacj_idx_1 ; dwf1n3odio [ 1 ] = * bbfanegn12 + kb0t2zk0he
; fecvxcduov [ 1 ] = * bbfanegn12 - kudshkyacj_idx_1 ; nsr34uzau5 [ 1 ] = *
bbfanegn12 - kb0t2zk0he ; } void h2gdpdmrk4 ( nikjwnz44k * const fk3v0e2etj )
{ if ( ! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent (
fk3v0e2etj -> _mdlRefSfcnS , "bounding_box_calc" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void bf1z3ni0yc (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , nikjwnz44k * const fk3v0e2etj
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( ( void * )
fk3v0e2etj , 0 , sizeof ( nikjwnz44k ) ) ; fk3v0e2etj -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; fk3v0e2etj -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( fk3v0e2etj -> _mdlRefSfcnS , "bounding_box_calc" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; }
bounding_box_calc_InitializeDataMapInfo ( fk3v0e2etj , sysRanPtr , contextTid
) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) {
rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( fk3v0e2etj ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( fk3v0e2etj -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( fk3v0e2etj ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_bounding_box_calc_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo (
mdlRefSfcnS , modelName , rtMdlInfo_bounding_box_calc , 41 ) ; * retVal = 1 ;
} static void mr_bounding_box_calc_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_bounding_box_calc_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_bounding_box_calc_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_bounding_box_calc_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_bounding_box_calc_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_bounding_box_calc_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_bounding_box_calc_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_bounding_box_calc_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_bounding_box_calc_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_bounding_box_calc_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_bounding_box_calc_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void
mr_bounding_box_calc_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_bounding_box_calc_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_bounding_box_calc_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_bounding_box_calc_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_bounding_box_calc_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_bounding_box_calc_GetDWork ( const
nqg40qhj3f4 * mdlrefDW ) { ( void ) mdlrefDW ; return NULL ; } void
mr_bounding_box_calc_SetDWork ( nqg40qhj3f4 * mdlrefDW , const mxArray * ssDW
) { ( void ) ssDW ; ( void ) mdlrefDW ; } void
mr_bounding_box_calc_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 844836899U , 893172029U , 3668035679U , 3027404360U
, } ; slmrModelRefRegisterSimStateChecksum ( S , "bounding_box_calc" , &
chksum [ 0 ] ) ; } mxArray * mr_bounding_box_calc_GetSimStateDisallowedBlocks
( ) { return NULL ; }
