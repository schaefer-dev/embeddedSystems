#include "__cf_distance_to_bounding_box.h"
#include "distance_to_bounding_box_capi.h"
#include "distance_to_bounding_box.h"
#include "distance_to_bounding_box_private.h"
static RegMdlInfo rtMdlInfo_distance_to_bounding_box [ 44 ] = { {
"d1naxt43mzk" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "d3ms0h1yoz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "j2hbgmwgoh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "nkocpvte4c" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "ohwblwpq0u" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "luckgti3jg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "fjvcnoiir5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "atpkwaojjw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "p3lljlkbae" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "iqjswpa4jz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "jqeluhxbjf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "hbmfp3kqpk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "elb4i25y3z" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "bwopfmobtw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "anzuhlyop4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "f3ablexttf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "cxzq2oqlhq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "be0s3ajg2j" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "kzslusok2u" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "distance_to_bounding_box" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "ebdcb1uu1ew" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "nymamlyxplo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "fpwfloir4j" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "em0ofdblpuh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "mu3welg5ozm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "ebdcb1uu1e" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "nymamlyxpl" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "ezq1aalfj0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "av1wmy0pwq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"distance_to_bounding_box" } , { "l20fhy3pjtc" , MDL_INFO_ID_DATA_TYPE , 0 ,
- 1 , ( NULL ) } , {
"mr_distance_to_bounding_box_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "distance_to_bounding_box"
} , { "mr_distance_to_bounding_box_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "distance_to_bounding_box" } , {
"mr_distance_to_bounding_box_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "distance_to_bounding_box" } , { "distance_to_bounding_box.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"distance_to_bounding_box.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"distance_to_bounding_box" } } ; void distance_to_bounding_box ( const real_T
lfe2dxneyr [ 2 ] , const real_T nnbn5ky45z [ 2 ] , const real_T jhymlcywfl [
2 ] , const real_T c32isnavag [ 2 ] , const real_T pwchkcvwbn [ 2 ] , const
real_T mx2cybtvzq [ 2 ] , real_T * pqafwvshxb , hbmfp3kqpk * localB ) {
calculate_intersection ( & lfe2dxneyr [ 0 ] , & nnbn5ky45z [ 0 ] , &
pwchkcvwbn [ 0 ] , & mx2cybtvzq [ 0 ] , & localB -> ox1s4nhz35 , & localB ->
gj1elvy303 ) ; calculate_intersection ( & nnbn5ky45z [ 0 ] , & jhymlcywfl [ 0
] , & pwchkcvwbn [ 0 ] , & mx2cybtvzq [ 0 ] , & localB -> hzi3jinxpw , &
localB -> oqtnjobotn ) ; calculate_intersection ( & jhymlcywfl [ 0 ] , &
c32isnavag [ 0 ] , & pwchkcvwbn [ 0 ] , & mx2cybtvzq [ 0 ] , & localB ->
ovf4xlkq5t , & localB -> j13hq4xm01 ) ; calculate_intersection ( & c32isnavag
[ 0 ] , & lfe2dxneyr [ 0 ] , & pwchkcvwbn [ 0 ] , & mx2cybtvzq [ 0 ] , &
localB -> iq3lqrngov , & localB -> m2sdyrvdxb ) ; * pqafwvshxb =
muDoubleScalarMin ( muDoubleScalarMin ( muDoubleScalarMin ( localB ->
ox1s4nhz35 , localB -> hzi3jinxpw ) , localB -> ovf4xlkq5t ) , localB ->
iq3lqrngov ) ; } void distance_to_bounding_boxTID1 ( void ) {
calculate_intersectionTID1 ( ) ; calculate_intersectionTID1 ( ) ;
calculate_intersectionTID1 ( ) ; calculate_intersectionTID1 ( ) ; } void
bwopfmobtw ( jqeluhxbjf * localDW , av1wmy0pwq * const bldvim2a1n ) {
copojq4112 ( & ( localDW -> o3fbm1gjmx . rtm ) ) ; copojq4112 ( & ( localDW
-> irmprfrtks . rtm ) ) ; copojq4112 ( & ( localDW -> b4j524tf33 . rtm ) ) ;
copojq4112 ( & ( localDW -> nuvr2vhmgn . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( bldvim2a1n ->
_mdlRefSfcnS , "distance_to_bounding_box" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void cxzq2oqlhq (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , av1wmy0pwq
* const bldvim2a1n , hbmfp3kqpk * localB , jqeluhxbjf * localDW , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( ( void * )
bldvim2a1n , 0 , sizeof ( av1wmy0pwq ) ) ; bldvim2a1n -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; bldvim2a1n -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; bldvim2a1n -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( bldvim2a1n -> _mdlRefSfcnS , "distance_to_bounding_box"
, "START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void
* ) localB ) , 0 , sizeof ( hbmfp3kqpk ) ) ; { localB -> ox1s4nhz35 = 0.0 ;
localB -> hzi3jinxpw = 0.0 ; localB -> ovf4xlkq5t = 0.0 ; localB ->
iq3lqrngov = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
jqeluhxbjf ) ) ; distance_to_bounding_box_InitializeDataMapInfo ( bldvim2a1n
, localDW , sysRanPtr , contextTid ) ; gvgkyoxgcv ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , & ( localDW -> o3fbm1gjmx . rtm ) , bldvim2a1n ->
DataMapInfo . systemRan [ 0 ] , bldvim2a1n -> DataMapInfo . systemTid [ 0 ] ,
& ( bldvim2a1n -> DataMapInfo . mmi ) , "distance_to_bounding_box/Model" , 0
, - 1 ) ; gvgkyoxgcv ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW
-> irmprfrtks . rtm ) , bldvim2a1n -> DataMapInfo . systemRan [ 0 ] ,
bldvim2a1n -> DataMapInfo . systemTid [ 0 ] , & ( bldvim2a1n -> DataMapInfo .
mmi ) , "distance_to_bounding_box/Model1" , 1 , - 1 ) ; gvgkyoxgcv (
_mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 , & ( localDW -> b4j524tf33 . rtm )
, bldvim2a1n -> DataMapInfo . systemRan [ 0 ] , bldvim2a1n -> DataMapInfo .
systemTid [ 0 ] , & ( bldvim2a1n -> DataMapInfo . mmi ) ,
"distance_to_bounding_box/Model2" , 2 , - 1 ) ; gvgkyoxgcv ( _mdlRefSfcnS ,
mdlref_TID0 , mdlref_TID1 , & ( localDW -> nuvr2vhmgn . rtm ) , bldvim2a1n ->
DataMapInfo . systemRan [ 0 ] , bldvim2a1n -> DataMapInfo . systemTid [ 0 ] ,
& ( bldvim2a1n -> DataMapInfo . mmi ) , "distance_to_bounding_box/Model3" , 3
, - 1 ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) )
{ rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( bldvim2a1n ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( bldvim2a1n -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( bldvim2a1n ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_distance_to_bounding_box_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T
* modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_calculate_intersection_MdlInfoRegFcn ( mdlRefSfcnS ,
"calculate_intersection" , retVal ) ; if ( * retVal == 0 ) return ; * retVal
= 0 ; } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_distance_to_bounding_box , 44 ) ; * retVal = 1 ; } static void
mr_distance_to_bounding_box_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_distance_to_bounding_box_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_distance_to_bounding_box_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_distance_to_bounding_box_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_distance_to_bounding_box_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_distance_to_bounding_box_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_distance_to_bounding_box_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_distance_to_bounding_box_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_distance_to_bounding_box_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_distance_to_bounding_box_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_distance_to_bounding_box_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_distance_to_bounding_box_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_distance_to_bounding_box_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_distance_to_bounding_box_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_distance_to_bounding_box_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T
mr_distance_to_bounding_box_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_distance_to_bounding_box_GetDWork (
const d1naxt43mzk * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] = {
"rtb" , "rtdw" , "NULL->rtzce" , } ; mxArray * ssDW = mxCreateStructMatrix (
1 , 1 , 3 , ssDWFieldNames ) ; mr_distance_to_bounding_box_cacheDataAsMxArray
( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; {
static const char * rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.o3fbm1gjmx"
, "mdlrefDW->rtdw.irmprfrtks" , "mdlrefDW->rtdw.b4j524tf33" ,
"mdlrefDW->rtdw.nuvr2vhmgn" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; { mxArray * varData =
mr_calculate_intersection_GetDWork ( & ( mdlrefDW -> rtdw . o3fbm1gjmx ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; } { mxArray * varData =
mr_calculate_intersection_GetDWork ( & ( mdlrefDW -> rtdw . irmprfrtks ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 1 , varData ) ; } { mxArray * varData =
mr_calculate_intersection_GetDWork ( & ( mdlrefDW -> rtdw . b4j524tf33 ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 2 , varData ) ; } { mxArray * varData =
mr_calculate_intersection_GetDWork ( & ( mdlrefDW -> rtdw . nuvr2vhmgn ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 3 , varData ) ; } mxSetFieldByNumber (
ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_distance_to_bounding_box_SetDWork ( d1naxt43mzk * mdlrefDW , const mxArray
* ssDW ) { mr_distance_to_bounding_box_restoreDataFromMxArray ( & ( mdlrefDW
-> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray *
rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_calculate_intersection_SetDWork ( & ( mdlrefDW -> rtdw . o3fbm1gjmx ) ,
mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_calculate_intersection_SetDWork ( & ( mdlrefDW -> rtdw . irmprfrtks ) ,
mxGetFieldByNumber ( rtdwData , 0 , 1 ) ) ;
mr_calculate_intersection_SetDWork ( & ( mdlrefDW -> rtdw . b4j524tf33 ) ,
mxGetFieldByNumber ( rtdwData , 0 , 2 ) ) ;
mr_calculate_intersection_SetDWork ( & ( mdlrefDW -> rtdw . nuvr2vhmgn ) ,
mxGetFieldByNumber ( rtdwData , 0 , 3 ) ) ; } } void
mr_distance_to_bounding_box_RegisterSimStateChecksum ( SimStruct * S ) {
const uint32_T chksum [ 4 ] = { 918808489U , 2742722325U , 4236210708U ,
1340926001U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"distance_to_bounding_box" , & chksum [ 0 ] ) ;
mr_calculate_intersection_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_distance_to_bounding_box_GetSimStateDisallowedBlocks ( ) { return
mr_calculate_intersection_GetSimStateDisallowedBlocks ( ) ; }
