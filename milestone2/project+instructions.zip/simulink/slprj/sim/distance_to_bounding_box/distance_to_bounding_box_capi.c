#include "__cf_distance_to_bounding_box.h"
#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "distance_to_bounding_box_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "distance_to_bounding_box.h"
#include "distance_to_bounding_box_capi.h"
#include "distance_to_bounding_box_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , - 1
, ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1 , 0 } } ;
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "" , "" , 0 ,
0 , 0 , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 0 , 0 } } ; static uint_T rtDimensionArray [ ] = { 0 } ;
static rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( NULL ) , ( NULL ) , 0 , 0 } } ; static int_T
rtContextSystems [ 2 ] ; static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] =
{ { 0 , 0 , "" , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 2 , rtContextSystems , loggingMetaInfo , 0 , NULL ,
{ 0 , NULL , NULL } , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL
) , 0 , ( NULL ) , 0 } , { rtBlockStates , 0 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 414923456U , 1022355736U , 1506073875U ,
352712278U } , & mmiStaticInfoLogging , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo * distance_to_bounding_box_GetCAPIStaticMap (
void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void distance_to_bounding_box_InitializeSystemRan ( av1wmy0pwq * const
bldvim2a1n , sysRanDType * systemRan [ ] , jqeluhxbjf * localDW , int_T
systemTid [ ] , void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER (
bldvim2a1n ) ; UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType
* ) rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemTid [ 1 ] = bldvim2a1n
-> Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ;
rtContextSystems [ 0 ] = 0 ; rtContextSystems [ 1 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void distance_to_bounding_box_InitializeDataMapInfo ( av1wmy0pwq * const
bldvim2a1n , jqeluhxbjf * localDW , void * sysRanPtr , int contextTid ) {
rtwCAPI_SetVersion ( bldvim2a1n -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( bldvim2a1n -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( bldvim2a1n -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; rtwCAPI_SetPath ( bldvim2a1n -> DataMapInfo . mmi ,
( NULL ) ) ; rtwCAPI_SetFullPath ( bldvim2a1n -> DataMapInfo . mmi , ( NULL )
) ; rtwCAPI_SetInstanceLoggingInfo ( bldvim2a1n -> DataMapInfo . mmi , &
bldvim2a1n -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
bldvim2a1n -> DataMapInfo . mmi , bldvim2a1n -> DataMapInfo . childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( bldvim2a1n -> DataMapInfo . mmi , 4 ) ;
distance_to_bounding_box_InitializeSystemRan ( bldvim2a1n , bldvim2a1n ->
DataMapInfo . systemRan , localDW , bldvim2a1n -> DataMapInfo . systemTid ,
sysRanPtr , contextTid ) ; rtwCAPI_SetSystemRan ( bldvim2a1n -> DataMapInfo .
mmi , bldvim2a1n -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid (
bldvim2a1n -> DataMapInfo . mmi , bldvim2a1n -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( bldvim2a1n -> DataMapInfo . mmi , & bldvim2a1n ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void distance_to_bounding_box_host_InitializeDataMapInfo (
distance_to_bounding_box_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
calculate_intersection_host_InitializeDataMapInfo ( & ( dataMap -> child0 ) ,
"distance_to_bounding_box/Model" ) ; dataMap -> childMMI [ 1 ] = & ( dataMap
-> child1 . mmi ) ; calculate_intersection_host_InitializeDataMapInfo ( & (
dataMap -> child1 ) , "distance_to_bounding_box/Model1" ) ; dataMap ->
childMMI [ 2 ] = & ( dataMap -> child2 . mmi ) ;
calculate_intersection_host_InitializeDataMapInfo ( & ( dataMap -> child2 ) ,
"distance_to_bounding_box/Model2" ) ; dataMap -> childMMI [ 3 ] = & ( dataMap
-> child3 . mmi ) ; calculate_intersection_host_InitializeDataMapInfo ( & (
dataMap -> child3 ) , "distance_to_bounding_box/Model3" ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , dataMap -> childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 4 ) ; }
#ifdef __cplusplus
}
#endif
#endif
