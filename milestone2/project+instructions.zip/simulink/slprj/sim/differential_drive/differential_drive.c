#include "__cf_differential_drive.h"
#include "differential_drive_capi.h"
#include "differential_drive.h"
#include "differential_drive_private.h"
static RegMdlInfo rtMdlInfo_differential_drive [ 48 ] = { { "ceyldc12a32" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "differential_drive" } , {
"dgl2ktxaof" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "devq5mhm54" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "aslryh0fym" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "nes2y3gbqk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "itsu1yon4s" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "mxwnril02s" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "jm42yhk5t3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "mmzx3s3tyv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "eg1otexkuj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "hpc5obccij" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "nngfmk01le" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "dpknwvksgu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "bfhsp2jlnv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "ixbotbolfu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "hcgq5pfjcy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "h5vubb4liy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "mjzcgvjfr5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "a0atpmh4a1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "gcf02wcldj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "k0ljbsbawd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "mn0c0dajpf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "iw14e4se0s" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "mlgkpl0ay0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "differential_drive" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "majom2nf3nh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "f45rpybgw5e" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "af0xmfsvt1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "hqapnn3aud2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "cmjm4hla3w1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "majom2nf3n" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , { "f45rpybgw5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "differential_drive"
} , { "ps0zay3oej" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"differential_drive" } , { "hedh2b3jua" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "differential_drive" } , {
"mr_differential_drive_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "differential_drive" } , { "mr_differential_drive_GetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "differential_drive" } , {
"differential_drive.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"differential_drive.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"differential_drive" } } ; ebuxoc15ksn ebuxoc15ks = { 0.0 ,
3.1415926535897931 , 180.0 , 1.7 , 0.5 , 0.0 , 0.0 , 9.3 , 50.0 , 255.0 ,
50.0 , 255.0 , 360.0 , 360.0 , 360.0 , 57.295779513082323 , 180.0 , - 1.0 ,
180.0 } ; void k0ljbsbawd ( itsu1yon4s * localX ) { localX -> ckrr0jnvvu =
ebuxoc15ks . P_0 ; localX -> a4tu5mgaff = ebuxoc15ks . P_5 ; localX ->
mhruw5rpf2 = ebuxoc15ks . P_6 ; } void gcf02wcldj ( itsu1yon4s * localX ) {
localX -> ckrr0jnvvu = ebuxoc15ks . P_0 ; localX -> a4tu5mgaff = ebuxoc15ks .
P_5 ; localX -> mhruw5rpf2 = ebuxoc15ks . P_6 ; } void differential_drive (
hedh2b3jua * const pg4evny104 , const real_T * lpvqnpovh4 , const real_T *
pzfzkyvfyq , const real_T * nfh4bqjny5 , const real_T * jpn0h34cyd , const
real_T * jmer1cslj0 , const real_T * ogzd4gktpv , real_T * g53rnik0s3 ,
real_T * pmto4vhzwe , real_T * h1kkaqpw03 , nngfmk01le * localB , itsu1yon4s
* localX , jm42yhk5t3 * localZCE ) { boolean_T resetSolver ; ZCEventType
zcEvent ; real_T c53nebge2b_p ; real_T oyeccicvlx_p ; real_T pmrjnf2oin_p ;
real_T kwpzqug1wa_p ; if ( rtmIsMajorTimeStep ( pg4evny104 ) ) { resetSolver
= false ; zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & localZCE ->
e50ylcfiu0 , ( * ogzd4gktpv ) ) ; if ( zcEvent != NO_ZCEVENT ) { resetSolver
= true ; localX -> ckrr0jnvvu = ebuxoc15ks . P_0 ; } if ( resetSolver ) {
ssSetBlockStateForSolverChangedAtMajorStep ( pg4evny104 -> _mdlRefSfcnS ) ; }
} c53nebge2b_p = * jmer1cslj0 * localB -> azrkzx4crj + localX -> ckrr0jnvvu ;
if ( rtmIsMajorTimeStep ( pg4evny104 ) ) { resetSolver = false ; zcEvent =
rt_ZCFcn ( RISING_ZERO_CROSSING , & localZCE -> fyppxoio4p , ( * ogzd4gktpv )
) ; if ( zcEvent != NO_ZCEVENT ) { resetSolver = true ; localX -> a4tu5mgaff
= ebuxoc15ks . P_5 ; } if ( resetSolver ) {
ssSetBlockStateForSolverChangedAtMajorStep ( pg4evny104 -> _mdlRefSfcnS ) ; }
} kwpzqug1wa_p = localX -> a4tu5mgaff ; if ( rtmIsMajorTimeStep ( pg4evny104
) ) { resetSolver = false ; zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , &
localZCE -> k52pxx0anh , ( * ogzd4gktpv ) ) ; if ( zcEvent != NO_ZCEVENT ) {
resetSolver = true ; localX -> mhruw5rpf2 = ebuxoc15ks . P_6 ; } if (
resetSolver ) { ssSetBlockStateForSolverChangedAtMajorStep ( pg4evny104 ->
_mdlRefSfcnS ) ; } } oyeccicvlx_p = * lpvqnpovh4 / ebuxoc15ks . P_9 * localB
-> hvxgoycklj ; pmrjnf2oin_p = * pzfzkyvfyq / ebuxoc15ks . P_11 * localB ->
gizsjmodix ; localB -> nwadgopbjt = 1.0 / ebuxoc15ks . P_3 / ebuxoc15ks . P_7
* ( oyeccicvlx_p - pmrjnf2oin_p ) ; oyeccicvlx_p += pmrjnf2oin_p ; localB ->
gge3jipdg0 = localB -> os331bzduo * muDoubleScalarCos ( c53nebge2b_p ) *
oyeccicvlx_p ; localB -> egjk0w3cbn = localB -> os331bzduo *
muDoubleScalarSin ( c53nebge2b_p ) * oyeccicvlx_p ; c53nebge2b_p =
muDoubleScalarMod ( ebuxoc15ks . P_15 * c53nebge2b_p , ebuxoc15ks . P_14 ) ;
if ( c53nebge2b_p > ebuxoc15ks . P_16 ) { c53nebge2b_p -= ebuxoc15ks . P_12 ;
} if ( ebuxoc15ks . P_17 * c53nebge2b_p > ebuxoc15ks . P_18 ) { * h1kkaqpw03
= ebuxoc15ks . P_13 + c53nebge2b_p ; } else { * h1kkaqpw03 = c53nebge2b_p ; }
* g53rnik0s3 = * nfh4bqjny5 + localX -> mhruw5rpf2 ; * pmto4vhzwe =
kwpzqug1wa_p + * jpn0h34cyd ; } void differential_driveTID1 ( nngfmk01le *
localB ) { localB -> azrkzx4crj = ebuxoc15ks . P_1 / ebuxoc15ks . P_2 ;
localB -> os331bzduo = ebuxoc15ks . P_4 * ebuxoc15ks . P_3 ; localB ->
hvxgoycklj = ebuxoc15ks . P_8 / ebuxoc15ks . P_3 ; localB -> gizsjmodix =
ebuxoc15ks . P_10 / ebuxoc15ks . P_3 ; } void a0atpmh4a1 ( void ) { } void
a0atpmh4a1TID1 ( void ) { } void mjzcgvjfr5 ( nngfmk01le * localB ,
nes2y3gbqk * localXdot ) { localXdot -> ckrr0jnvvu = localB -> nwadgopbjt ;
localXdot -> a4tu5mgaff = localB -> egjk0w3cbn ; localXdot -> mhruw5rpf2 =
localB -> gge3jipdg0 ; } void h5vubb4liy ( const real_T * ogzd4gktpv ,
dgl2ktxaof * localZCSV ) { localZCSV -> nzo1nwwdie = * ogzd4gktpv ; localZCSV
-> l5tjjo4ube = * ogzd4gktpv ; localZCSV -> d2srs4xkue = * ogzd4gktpv ; }
void bfhsp2jlnv ( hedh2b3jua * const pg4evny104 ) { if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( pg4evny104 ->
_mdlRefSfcnS , "differential_drive" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void mn0c0dajpf (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , hedh2b3jua
* const pg4evny104 , nngfmk01le * localB , itsu1yon4s * localX , jm42yhk5t3 *
localZCE , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( void ) memset ( (
void * ) pg4evny104 , 0 , sizeof ( hedh2b3jua ) ) ; pg4evny104 -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; pg4evny104 -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; pg4evny104 -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( pg4evny104 -> _mdlRefSfcnS , "differential_drive" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> azrkzx4crj = 0.0
; localB -> os331bzduo = 0.0 ; localB -> hvxgoycklj = 0.0 ; localB ->
gizsjmodix = 0.0 ; localB -> nwadgopbjt = 0.0 ; localB -> gge3jipdg0 = 0.0 ;
localB -> egjk0w3cbn = 0.0 ; } differential_drive_InitializeDataMapInfo (
pg4evny104 , localX , sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != (
NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( *
rt_ParentMMI , rt_ChildMMIIdx , & ( pg4evny104 -> DataMapInfo . mmi ) ) ;
rtwCAPI_SetPath ( pg4evny104 -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( pg4evny104 -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } localZCE -> e50ylcfiu0 = UNINITIALIZED_ZCSIG ; localZCE ->
fyppxoio4p = UNINITIALIZED_ZCSIG ; localZCE -> k52pxx0anh =
UNINITIALIZED_ZCSIG ; } void mr_differential_drive_MdlInfoRegFcn ( SimStruct
* mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal = 0 ; {
boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_differential_drive , 48 ) ; * retVal = 1 ; } static void
mr_differential_drive_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) ; static void
mr_differential_drive_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_differential_drive_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ;
static void mr_differential_drive_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_differential_drive_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) ; static void
mr_differential_drive_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_differential_drive_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_differential_drive_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_differential_drive_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_differential_drive_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_differential_drive_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void
mr_differential_drive_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_differential_drive_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_differential_drive_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_differential_drive_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_differential_drive_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_differential_drive_GetDWork ( const
ceyldc12a32 * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] = { "rtb"
, "NULL->rtdw" , "rtzce" , } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1
, 3 , ssDWFieldNames ) ; mr_differential_drive_cacheDataAsMxArray ( ssDW , 0
, 0 , & ( mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ;
mr_differential_drive_cacheDataAsMxArray ( ssDW , 0 , 2 , & ( mdlrefDW ->
rtzce ) , sizeof ( mdlrefDW -> rtzce ) ) ; return ssDW ; } void
mr_differential_drive_SetDWork ( ceyldc12a32 * mdlrefDW , const mxArray *
ssDW ) { mr_differential_drive_restoreDataFromMxArray ( & ( mdlrefDW -> rtb )
, ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ;
mr_differential_drive_restoreDataFromMxArray ( & ( mdlrefDW -> rtzce ) , ssDW
, 0 , 2 , sizeof ( mdlrefDW -> rtzce ) ) ; } void
mr_differential_drive_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 321429374U , 446856611U , 1788762406U , 1129510515U
, } ; slmrModelRefRegisterSimStateChecksum ( S , "differential_drive" , &
chksum [ 0 ] ) ; } mxArray *
mr_differential_drive_GetSimStateDisallowedBlocks ( ) { return NULL ; }
