#ifndef SHARE_rt_urand_Upu32_Yd_f_pw_snf
#define SHARE_rt_urand_Upu32_Yd_f_pw_snf
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u);

#endif
