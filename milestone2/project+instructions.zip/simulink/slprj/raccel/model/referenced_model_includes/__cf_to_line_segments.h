#ifndef CF_to_line_segments_H__
#define CF_to_line_segments_H__
#endif
