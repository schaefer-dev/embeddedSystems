#include "__cf_distance_to_bounding_box.h"
#ifndef RTW_HEADER_distance_to_bounding_box_capi_h_
#define RTW_HEADER_distance_to_bounding_box_capi_h_
#include "distance_to_bounding_box.h"
extern void distance_to_bounding_box_InitializeDataMapInfo ( av1wmy0pwq *
const bldvim2a1n , jqeluhxbjf * localDW , void * sysRanPtr , int contextTid )
;
#endif
