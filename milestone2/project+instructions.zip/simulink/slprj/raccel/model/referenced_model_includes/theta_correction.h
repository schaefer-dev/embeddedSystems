#include "__cf_theta_correction.h"
#ifndef RTW_HEADER_theta_correction_h_
#define RTW_HEADER_theta_correction_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef theta_correction_COMMON_INCLUDES_
#define theta_correction_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "theta_correction_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T noumd5sm3y ; } enfdh5aith ; typedef struct {
boolean_T bi3arrqr35 ; boolean_T altyuhlf4n ; } ozjhelv2xk ; typedef struct {
real_T dwswfe0nam ; real_T pvtjxbcyj3 ; } kiif3lkxev ; struct ag4o1hq5eci_ {
real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ;
real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; } ; struct
ft2sg4iq0z { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 7 ] ; int_T systemTid [ 7 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { enfdh5aith rtb ; ozjhelv2xk rtdw ; nci50w0kfs rtm ; }
kevw5qu2wxg ; extern void pckfge0fgo ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , nci50w0kfs * const cigb32oe2e , enfdh5aith
* localB , ozjhelv2xk * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_theta_correction_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray * mr_theta_correction_GetDWork
( const kevw5qu2wxg * mdlrefDW ) ; extern void mr_theta_correction_SetDWork (
kevw5qu2wxg * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_theta_correction_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_theta_correction_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * theta_correction_GetCAPIStaticMap ( void ) ;
extern void pdvunnwa5j ( enfdh5aith * localB , kiif3lkxev * localZCSV ) ;
extern void theta_correction ( nci50w0kfs * const cigb32oe2e , const real_T *
kwpomzsxrw , const real_T * bhqmiiaei4 , real_T * bylhqnf4zp , real_T *
fhdwtdpomf , enfdh5aith * localB , ozjhelv2xk * localDW ) ; extern void
theta_correctionTID1 ( void ) ; extern void bwb4mgvz4x ( nci50w0kfs * const
cigb32oe2e ) ;
#endif
