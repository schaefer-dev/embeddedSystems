#include "__cf_differential_drive.h"
#ifndef RTW_HEADER_differential_drive_capi_h_
#define RTW_HEADER_differential_drive_capi_h_
#include "differential_drive.h"
extern void differential_drive_InitializeDataMapInfo ( hedh2b3jua * const
pg4evny104 , itsu1yon4s * localX , void * sysRanPtr , int contextTid ) ;
#endif
