#include "__cf_prox_sensor_gen.h"
#ifndef RTW_HEADER_prox_sensor_gen_types_h_
#define RTW_HEADER_prox_sensor_gen_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct ej2zfvfm5dc_ ej2zfvfm5dc ; typedef struct jvwqtcmqai
d2rk1h1tve ;
#endif
