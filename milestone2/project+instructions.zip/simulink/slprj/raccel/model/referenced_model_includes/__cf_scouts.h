#ifndef CF_scouts_H__
#define CF_scouts_H__
#endif
