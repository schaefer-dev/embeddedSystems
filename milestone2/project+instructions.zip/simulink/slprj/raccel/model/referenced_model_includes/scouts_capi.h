#include "__cf_scouts.h"
#ifndef RTW_HEADER_scouts_capi_h_
#define RTW_HEADER_scouts_capi_h_
#include "scouts.h"
extern void scouts_InitializeDataMapInfo ( ewygduyfhk * const n4wvtqyiky ,
bow3ugaxbk * localDW , void * sysRanPtr , int contextTid ) ;
#endif
