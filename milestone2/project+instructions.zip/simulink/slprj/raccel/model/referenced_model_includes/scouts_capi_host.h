#include "__cf_scouts.h"
#ifndef RTW_HEADER_scouts_cap_host_h_
#define RTW_HEADER_scouts_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "differential_drive_capi_host.h"
#include "enable_hold_capi_host.h"
#include "enable_hold_capi_host.h"
#include "theta_correction_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 4 ] ; differential_drive_host_DataMapInfo_T child0 ;
enable_hold_host_DataMapInfo_T child1 ; enable_hold_host_DataMapInfo_T child2
; theta_correction_host_DataMapInfo_T child3 ; } scouts_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void scouts_host_InitializeDataMapInfo ( scouts_host_DataMapInfo_T * dataMap
, const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
