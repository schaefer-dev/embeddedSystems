#include "__cf_collectors.h"
#ifndef RTW_HEADER_collectors_capi_h_
#define RTW_HEADER_collectors_capi_h_
#include "collectors.h"
extern void collectors_InitializeDataMapInfo ( pdhslryz2b * const npwdrebuui
, jma5b1bq35 * localDW , void * sysRanPtr , int contextTid ) ;
#endif
