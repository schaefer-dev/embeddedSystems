#include "__cf_oob_detector.h"
#ifndef RTW_HEADER_oob_detector_capi_h_
#define RTW_HEADER_oob_detector_capi_h_
#include "oob_detector.h"
extern void oob_detector_InitializeDataMapInfo ( oiwtoi0qfk * const
ls5dxafs0b , gpas0afkqt * localDW , void * sysRanPtr , int contextTid ) ;
#endif
