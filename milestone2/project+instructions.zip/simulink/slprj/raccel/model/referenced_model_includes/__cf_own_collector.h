#ifndef CF_own_collector_H__
#define CF_own_collector_H__
#endif
