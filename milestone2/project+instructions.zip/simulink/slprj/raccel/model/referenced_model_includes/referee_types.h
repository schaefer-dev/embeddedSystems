#include "__cf_referee.h"
#ifndef RTW_HEADER_referee_types_h_
#define RTW_HEADER_referee_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct ddqvav324h_ ddqvav324h ; typedef struct iodzcxfysu1_
iodzcxfysu1 ; typedef struct olitrjin0r ondkm4so4b ;
#endif
