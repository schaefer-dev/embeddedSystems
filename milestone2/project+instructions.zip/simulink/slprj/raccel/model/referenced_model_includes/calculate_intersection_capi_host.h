#include "__cf_calculate_intersection.h"
#ifndef RTW_HEADER_calculate_intersection_cap_host_h_
#define RTW_HEADER_calculate_intersection_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; }
calculate_intersection_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void calculate_intersection_host_InitializeDataMapInfo (
calculate_intersection_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
