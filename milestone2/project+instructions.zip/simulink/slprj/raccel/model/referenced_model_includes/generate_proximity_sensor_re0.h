#include "__cf_generate_proximity_sensor_re0.h"
#ifndef RTW_HEADER_generate_proximity_sensor_re0_h_
#define RTW_HEADER_generate_proximity_sensor_re0_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef generate_proximity_sensor_re0_COMMON_INCLUDES_
#define generate_proximity_sensor_re0_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "generate_proximity_sensor_re0_types.h"
#include "multiword_types.h"
#include "vector_rotation.h"
#include "prox_sensor_gen.h"
#include "bounding_box_calc.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
typedef struct { real_T lnjkx4saip [ 2 ] ; real_T hwdo2csdow [ 2 ] ; real_T
pfdxihs1su [ 2 ] ; real_T jwzojjli23 [ 2 ] ; real_T bgketlfezd [ 2 ] ; real_T
acheaxua4v [ 2 ] ; real_T cqhh2fob2y [ 2 ] ; real_T pw50lnxfdk [ 2 ] ; real_T
dpoilg0pmh [ 2 ] ; real_T haxlqgijs2 [ 2 ] ; real_T dkquwl3rfb [ 2 ] ; real_T
lhy0osyfwu [ 2 ] ; real_T dclefz5xak [ 2 ] ; real_T df4nncxac0 [ 2 ] ; real_T
g2hfe3p2wc [ 2 ] ; real_T jsmzi2xarx [ 2 ] ; real_T nn10stauoa [ 2 ] ; real_T
hdgi5ot402 [ 2 ] ; real_T cvcjzcoco3 [ 2 ] ; real_T gavupw10as [ 2 ] ; real_T
goxuovexcl [ 2 ] ; } acuzzpstt1 ; typedef struct { knl0xklyur4 i5asoaa1ng ;
nqg40qhj3f4 jkr3xz2g0j ; nqg40qhj3f4 hq00zkmfph ; nqg40qhj3f4 jzxoyutgbz ;
ppw2dwepwsm f3wmnofr3j ; knl0xklyur4 elwd2cajxx ; ppw2dwepwsm anpvbzoi4x ;
knl0xklyur4 cq5od40nau ; ppw2dwepwsm cq2zbvyipn ; } gxmdy5cswd ; struct
nj4ihpnw4px_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T
P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
} ; struct mk4by1p4b2 { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 9 ] ; sysRanDType
* systemRan [ 2 ] ; int_T systemTid [ 2 ] ; } DataMapInfo ; struct { uint8_T
rtmDbBufReadBuf1 ; uint8_T rtmDbBufWriteBuf1 ; boolean_T rtmDbBufLastBufWr1 ;
real_T rtmDbBufContT1 [ 2 ] ; int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { acuzzpstt1 rtb ; gxmdy5cswd rtdw ; ex4gaboq54 rtm ; }
ni4fygtiycb ; extern void hcb3tyzth3 ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , ex4gaboq54 * const f3p40zvy1f , acuzzpstt1
* localB , gxmdy5cswd * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_generate_proximity_sensor_re0_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_generate_proximity_sensor_re0_GetDWork ( const ni4fygtiycb * mdlrefDW ) ;
extern void mr_generate_proximity_sensor_re0_SetDWork ( ni4fygtiycb *
mdlrefDW , const mxArray * ssDW ) ; extern void
mr_generate_proximity_sensor_re0_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_generate_proximity_sensor_re0_GetSimStateDisallowedBlocks
( ) ; extern const rtwCAPI_ModelMappingStaticInfo *
generate_proximity_sensor_re0_GetCAPIStaticMap ( void ) ; extern void
generate_proximity_sensor_re0 ( const real_T * a4ntjzxodx , const real_T *
bhay3qtkas , const real_T * c5tqlduzuf , const real_T * i52mdgtpfz , const
real_T * l4l1ogbmfg , const real_T * gencabw5dg , const real_T * aqsonb32cv ,
const real_T * clfc5juaeg , const real_T * o3tmv33fn2 , const real_T *
mbpdop3qfq , const real_T * lxfhj4ws5i , const real_T * i3fzeactka , real_T *
labgh33fh1 , real_T * lkanuak5ro , real_T * o3pc4zsma5 , acuzzpstt1 * localB
, gxmdy5cswd * localDW ) ; extern void generate_proximity_sensor_re0TID1 (
acuzzpstt1 * localB ) ; extern void jefqqgv1fi ( gxmdy5cswd * localDW ,
ex4gaboq54 * const f3p40zvy1f ) ;
#endif
