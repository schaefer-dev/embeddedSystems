#include "__cf_generate_proximity_sensor_re0.h"
#ifndef RTW_HEADER_generate_proximity_sensor_re0_types_h_
#define RTW_HEADER_generate_proximity_sensor_re0_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct nj4ihpnw4px_ nj4ihpnw4px ; typedef struct mk4by1p4b2
ex4gaboq54 ;
#endif
