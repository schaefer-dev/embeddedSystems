#include "__cf_referee.h"
#ifndef RTW_HEADER_referee_capi_h_
#define RTW_HEADER_referee_capi_h_
#include "referee.h"
extern void referee_InitializeDataMapInfo ( ondkm4so4b * const cyqsf0f3xu ,
appkse231e * localDW , ht5eljqmzr * localX , void * sysRanPtr , int
contextTid ) ;
#endif
