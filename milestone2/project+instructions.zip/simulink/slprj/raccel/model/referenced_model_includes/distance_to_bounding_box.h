#include "__cf_distance_to_bounding_box.h"
#ifndef RTW_HEADER_distance_to_bounding_box_h_
#define RTW_HEADER_distance_to_bounding_box_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef distance_to_bounding_box_COMMON_INCLUDES_
#define distance_to_bounding_box_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "distance_to_bounding_box_types.h"
#include "multiword_types.h"
#include "calculate_intersection.h"
#include "rtGetInf.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T ox1s4nhz35 ; real_T hzi3jinxpw ; real_T ovf4xlkq5t ;
real_T iq3lqrngov ; boolean_T gj1elvy303 ; boolean_T oqtnjobotn ; boolean_T
j13hq4xm01 ; boolean_T m2sdyrvdxb ; } hbmfp3kqpk ; typedef struct {
l20fhy3pjtc o3fbm1gjmx ; l20fhy3pjtc irmprfrtks ; l20fhy3pjtc b4j524tf33 ;
l20fhy3pjtc nuvr2vhmgn ; } jqeluhxbjf ; struct ezq1aalfj0 { struct
SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 4 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf1 ;
uint8_T rtmDbBufWriteBuf1 ; boolean_T rtmDbBufLastBufWr1 ; real_T
rtmDbBufContT1 [ 2 ] ; int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef
struct { hbmfp3kqpk rtb ; jqeluhxbjf rtdw ; av1wmy0pwq rtm ; } d1naxt43mzk ;
extern void cxzq2oqlhq ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , av1wmy0pwq * const bldvim2a1n , hbmfp3kqpk * localB ,
jqeluhxbjf * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_distance_to_bounding_box_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T
* modelName , int_T * retVal ) ; extern mxArray *
mr_distance_to_bounding_box_GetDWork ( const d1naxt43mzk * mdlrefDW ) ;
extern void mr_distance_to_bounding_box_SetDWork ( d1naxt43mzk * mdlrefDW ,
const mxArray * ssDW ) ; extern void
mr_distance_to_bounding_box_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_distance_to_bounding_box_GetSimStateDisallowedBlocks ( )
; extern const rtwCAPI_ModelMappingStaticInfo *
distance_to_bounding_box_GetCAPIStaticMap ( void ) ; extern void
distance_to_bounding_box ( const real_T lfe2dxneyr [ 2 ] , const real_T
nnbn5ky45z [ 2 ] , const real_T jhymlcywfl [ 2 ] , const real_T c32isnavag [
2 ] , const real_T pwchkcvwbn [ 2 ] , const real_T mx2cybtvzq [ 2 ] , real_T
* pqafwvshxb , hbmfp3kqpk * localB ) ; extern void
distance_to_bounding_boxTID1 ( void ) ; extern void bwopfmobtw ( jqeluhxbjf *
localDW , av1wmy0pwq * const bldvim2a1n ) ;
#endif
