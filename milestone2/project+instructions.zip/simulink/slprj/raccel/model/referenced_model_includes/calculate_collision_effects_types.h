#include "__cf_calculate_collision_effects.h"
#ifndef RTW_HEADER_calculate_collision_effects_types_h_
#define RTW_HEADER_calculate_collision_effects_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct g1j02kmnez5_ g1j02kmnez5 ; typedef struct gg1ppi30jj
hy0y0nvofh ;
#endif
