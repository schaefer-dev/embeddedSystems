#include "__cf_check_collision_with_bounding.h"
#ifndef RTW_HEADER_check_collision_with_bounding_cap_host_h_
#define RTW_HEADER_check_collision_with_bounding_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "to_line_segments_capi_host.h"
#include "to_line_segments_capi_host.h"
#include "to_line_segments_capi_host.h"
#include "to_line_segments_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 4 ] ; to_line_segments_host_DataMapInfo_T child0 ;
to_line_segments_host_DataMapInfo_T child1 ;
to_line_segments_host_DataMapInfo_T child2 ;
to_line_segments_host_DataMapInfo_T child3 ; }
check_collision_with_bounding_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void check_collision_with_bounding_host_InitializeDataMapInfo (
check_collision_with_bounding_host_DataMapInfo_T * dataMap , const char *
path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
