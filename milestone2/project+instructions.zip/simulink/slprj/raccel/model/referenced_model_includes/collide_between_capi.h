#include "__cf_collide_between.h"
#ifndef RTW_HEADER_collide_between_capi_h_
#define RTW_HEADER_collide_between_capi_h_
#include "collide_between.h"
extern void collide_between_InitializeDataMapInfo ( kkquagm1v4 * const
enzdlkimmo , f0welreujf * localDW , void * sysRanPtr , int contextTid ) ;
#endif
