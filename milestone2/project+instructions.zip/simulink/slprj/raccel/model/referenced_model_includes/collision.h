#include "__cf_collision.h"
#ifndef RTW_HEADER_collision_h_
#define RTW_HEADER_collision_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef collision_COMMON_INCLUDES_
#define collision_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "collision_types.h"
#include "multiword_types.h"
#include "collide_between.h"
#include "rt_nonfinite.h"
typedef struct { real_T bxlguqnbhj ; real_T kfgoqwrqzh ; real_T h1lu1qlg4x ;
real_T f45hwaolrm ; real_T gt3ze33ar2 ; real_T jc5xubbrgx ; real_T fnbne5xx21
; real_T pz5jgtsos1 ; real_T i13g4wrwzw ; real_T ngyzezn00s ; real_T
n0vfxvswvx ; real_T ppmum2uzrg ; real_T l1wb2iywhr ; real_T k5ufmolx0d ;
real_T d34zkelbi1 ; real_T pcag2t1zgz ; real_T ha4j0kuomf ; real_T co4fqbcbru
; real_T kdkajqjise ; real_T eyv20szcju ; real_T fb3ercztxy ; real_T
bmvglm4fyq ; real_T hsjaavowst ; real_T gwjda0xlou ; } ht25has4vg ; typedef
struct { jv23mlr3c55 hru0hqvv0x ; jv23mlr3c55 atpdaywep1 ; jv23mlr3c55
fshvuxysp5 ; jv23mlr3c55 pr1skhjatf ; jv23mlr3c55 lplgcbmmyo ; jv23mlr3c55
h4klopvvfg ; } mhv1pvkcyj ; typedef struct { lupwujirzg jqdfh500kc ;
lupwujirzg cmqp3loboe ; lupwujirzg g5yc3fesen ; lupwujirzg a1rtgwbnyy ;
lupwujirzg g1bn0df1i4 ; lupwujirzg ns2cpkwwav ; } dq3jajg0ti ; struct
p05g1t1tav { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 6 ] ; sysRanDType
* systemRan [ 2 ] ; int_T systemTid [ 2 ] ; } DataMapInfo ; struct { uint8_T
rtmDbBufReadBuf1 ; uint8_T rtmDbBufWriteBuf1 ; boolean_T rtmDbBufLastBufWr1 ;
real_T rtmDbBufContT1 [ 2 ] ; int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { ht25has4vg rtb ; mhv1pvkcyj rtdw ; ishptvov2y rtm ; }
i5cbqmfwwz0 ; extern real_T rtP_collision_detection_distance ; extern real_T
rtP_push_force ; extern void en4ldfvxah ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , ishptvov2y * const dzwbd2guxb , ht25has4vg
* localB , mhv1pvkcyj * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_collision_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_collision_GetDWork ( const i5cbqmfwwz0
* mdlrefDW ) ; extern void mr_collision_SetDWork ( i5cbqmfwwz0 * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_collision_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_collision_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * collision_GetCAPIStaticMap
( void ) ; extern void jh4mwjzjdl ( mhv1pvkcyj * localDW ) ; extern void
eb5c3fnz2v ( mhv1pvkcyj * localDW , dq3jajg0ti * localZCSV ) ; extern void
collision ( const real_T * gkloj4hzlb , const real_T * j1ntxvbrk5 , const
real_T * l3s3v2wbkr , const real_T * htxdzzbpn3 , const real_T * jxj00te4ne ,
const real_T * e122ug3oyh , const real_T * lpoxms4fcu , const real_T *
i3nklqgaak , const real_T * mquz5dyheg , const real_T * l3yfwmf5hz , const
real_T * oe5gonrsst , const real_T * k2pttrruzv , real_T * dblbyfnrxa ,
real_T * epg2gonkjy , real_T * o45q3bqjts , real_T * plxqca0zr5 , real_T *
dl0wv41ziq , real_T * if2wf341a1 , real_T * bdu4hcldkp , real_T * bvag4tknzl
, real_T * h1e55gq14z , real_T * ajqacg4ysm , real_T * ihnu4otolg , real_T *
p4wsiql0dx , ht25has4vg * localB , mhv1pvkcyj * localDW ) ; extern void
collisionTID1 ( void ) ; extern void a20usbo2aj ( mhv1pvkcyj * localDW ,
ishptvov2y * const dzwbd2guxb ) ;
#endif
