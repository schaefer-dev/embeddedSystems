#include "__cf_random_communication_loss.h"
#ifndef RTW_HEADER_random_communication_loss_capi_h_
#define RTW_HEADER_random_communication_loss_capi_h_
#include "random_communication_loss.h"
extern void random_communication_loss_InitializeDataMapInfo ( muyutmqs5w *
const b3qc4axbif , o5coxopmp3 * localDW , void * sysRanPtr , int contextTid )
;
#endif
