#include "__cf_calculate_intersection.h"
#ifndef RTW_HEADER_calculate_intersection_types_h_
#define RTW_HEADER_calculate_intersection_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct ka2ttq1dcfe_ ka2ttq1dcfe ; typedef struct bvctzapre3
kvlk4iofhp ;
#endif
