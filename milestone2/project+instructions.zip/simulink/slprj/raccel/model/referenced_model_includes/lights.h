#include "__cf_lights.h"
#ifndef RTW_HEADER_lights_h_
#define RTW_HEADER_lights_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef lights_COMMON_INCLUDES_
#define lights_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "lights_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "enable_hold.h"
#include "differential_drive.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T o3wvvahhjo ; real_T pxeijbceyi ; real_T n4dmokbw53 ;
real_T hil4e1zv4r ; real_T bdf0s4rbfy ; real_T bnysluxp3m ; real_T d2ufn4ceie
; real_T c4jwy31sqk ; real_T judpeb4vwe ; real_T b504xabvzk ; real_T
ozxt53wmv4 ; real_T fe1cm44yzr ; real_T mdfqekexkb ; real_T b5ik1n0nca ;
real_T je3usdceje ; real_T f4qlzyndtm ; real_T hzuhv2cj4x ; real_T iwacwebge1
; real_T k15gjpnada ; real_T pimzhf3xi5 ; real_T m3s2ezl5du ; real_T
dwaxemrfqs ; real_T jns21jwnfs ; real_T k20gjxyoe1 ; boolean_T p5v40l3pve ; }
d3wnqrfn5d ; typedef struct { real_T dgilreueej ; real_T j2dxxo0gzf ; real_T
amb3dns0yp ; real_T hhzsbopqvm ; struct { void * AQHandles ; void * SlioLTF ;
} pxo331nxlm ; struct { void * AQHandles ; void * SlioLTF ; } guqmej4ilt ;
struct { void * AQHandles ; void * SlioLTF ; } edirmiyxv2 ; int_T ktyinynyjc
; int_T hlhxttxjc5 ; boolean_T cc1dnfy34n ; boolean_T a151ms4yri ; boolean_T
cymoijuqjm ; boolean_T apxmmf4od0 ; boolean_T o3u00n0tl0 ; boolean_T
mrf3aksz4v ; boolean_T fodehstvzs ; boolean_T l4qbtmmgj4 ; boolean_T
akviqotr0g ; boolean_T gbvd0s0d1e ; boolean_T iuu34evr4g ; boolean_T
g03xucm1oq ; boolean_T oze5dcjbri ; boolean_T ik3aoiaa2r ; n1ljxg42ztp
hetd5pmsvm ; n1ljxg42ztp pl1cbnmcvp ; ceyldc12a32 a1el0zd03f ; } prtjfggemg ;
typedef struct { itsu1yon4s glg4l1dfsi ; } e1c2zrj1nx ; typedef struct {
nes2y3gbqk glg4l1dfsi ; } gyxtjka3et ; typedef struct { aslryh0fym glg4l1dfsi
; } bi2e23yu4p ; typedef struct { devq5mhm54 glg4l1dfsi ; } jqsqsjzuph ;
typedef struct { ayscym2s52 d5cxu5sa1c ; ayscym2s52 csbhbltzmr ; real_T
eossn0dvzw ; real_T iqaostiw12 ; dgl2ktxaof d50u4r3wyv ; real_T jyq3ar0mt0 ;
real_T akpckgpqnm ; real_T ngmg4iofsq ; real_T id2oric23o ; real_T fm05tgz4p4
; real_T oshlm1zykn ; real_T gn05zphnxs ; real_T lenuso55cv ; real_T
d1wlchdjat ; real_T ix3rsvjjhr ; real_T a3bsckc05s ; real_T k11lrrjfzc ;
real_T n130kbsq1t ; } fd2rr2yo0s ; struct brh0zkskzdo_ { real_T P_0 ; real_T
P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T
P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ;
real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T
P_18 ; real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ;
real_T P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T
P_29 ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ;
real_T P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T
P_40 ; real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ;
real_T P_46 ; real_T P_47 ; boolean_T P_48 ; } ; struct ocfq1uquo5 { struct
SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ; real_T
mr_nonContSig1 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 2 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 3 ] ; sysRanDType
* systemRan [ 11 ] ; int_T systemTid [ 11 ] ; } DataMapInfo ; struct {
uint8_T rtmDbBufReadBuf2 ; uint8_T rtmDbBufWriteBuf2 ; boolean_T
rtmDbBufLastBufWr2 ; real_T rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3
] ; } Timing ; } ; typedef struct { d3wnqrfn5d rtb ; prtjfggemg rtdw ;
ieoalh2akm rtm ; } fvnxaixuz2i ; extern void gwpf3ggmmf ( SimStruct *
_mdlRefSfcnS , ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray ,
int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , ieoalh2akm *
const hvf2ni0bda , d3wnqrfn5d * localB , prtjfggemg * localDW , e1c2zrj1nx *
localX , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_lights_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_lights_GetDWork ( const fvnxaixuz2i * mdlrefDW ) ; extern void
mr_lights_SetDWork ( fvnxaixuz2i * mdlrefDW , const mxArray * ssDW ) ; extern
void mr_lights_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_lights_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * lights_GetCAPIStaticMap ( void ) ; extern
void elcscuhjzv ( d3wnqrfn5d * localB , prtjfggemg * localDW , e1c2zrj1nx *
localX ) ; extern void ikrgtv4yyh ( prtjfggemg * localDW , e1c2zrj1nx *
localX ) ; extern void fkpprgoc32 ( ieoalh2akm * const hvf2ni0bda ,
prtjfggemg * localDW ) ; extern void lidek34nw0 ( prtjfggemg * localDW ,
gyxtjka3et * localXdot ) ; extern void bicwzzfaof ( const real_T * hh3r341ak2
, d3wnqrfn5d * localB , prtjfggemg * localDW , fd2rr2yo0s * localZCSV ) ;
extern void f1wlkix5s3 ( prtjfggemg * localDW ) ; extern void fsvrbizxxj (
ieoalh2akm * const hvf2ni0bda , d3wnqrfn5d * localB , prtjfggemg * localDW )
; extern void fsvrbizxxjTID2 ( void ) ; extern void lights ( ieoalh2akm *
const hvf2ni0bda , const real_T * j4w5mhc45v , const real_T * jjnokicmeg ,
const real_T * hh3r341ak2 , const real_T * m2ovqoeajk , const real_T *
agyyuzhiuq , const real_T * ikh2afczmf , const real_T * ctjs5en4e3 , const
real_T * mdcsqp1iwc , const real_T * fexus5mpfe , real_T * bf22moulgm ,
real_T * mlkbxcqx4e , real_T * o5djdn0l4r , real_T * fx5fynalt3 , real_T *
phvcugpgkw , real_T * hjxo2qotrl , real_T * gbfsfotejr , d3wnqrfn5d * localB
, prtjfggemg * localDW , e1c2zrj1nx * localX ) ; extern void lightsTID2 (
prtjfggemg * localDW ) ; extern void dvug2jx5xw ( ieoalh2akm * const
hvf2ni0bda , prtjfggemg * localDW ) ;
#endif
