#include "__cf_check_collision_with_bounding.h"
#ifndef RTW_HEADER_check_collision_with_bounding_capi_h_
#define RTW_HEADER_check_collision_with_bounding_capi_h_
#include "check_collision_with_bounding.h"
extern void check_collision_with_bounding_InitializeDataMapInfo ( lv1w310d1o
* const ne0pyymecy , efinskpodg * localDW , void * sysRanPtr , int contextTid
) ;
#endif
