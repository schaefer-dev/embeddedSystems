#include "__cf_own_collector.h"
#ifndef RTW_HEADER_own_collector_h_
#define RTW_HEADER_own_collector_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef own_collector_COMMON_INCLUDES_
#define own_collector_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "own_collector_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "vector_rotation.h"
#include "theta_correction.h"
#include "enable_hold.h"
#include "differential_drive.h"
#include "calculate_intersection.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
typedef struct { real_T nohjxzlbn3 ; real_T fdvgonzlty ; real_T lyvsjguqdz ;
real_T f5nso50wvn ; real_T kv4dcudach ; real_T om0hgczur0 ; real_T h55ht1nzqj
; real_T cwduo52ri2 ; real_T ab3r4zcwxd ; real_T bot11ggwqi ; real_T
bcssetxhd1 ; real_T ffzdw4o3pq ; real_T d3ihks5rgy ; real_T ehegul31lb ;
real_T duhttykvo4 ; real_T dcicygvsle ; real_T fofprnxegc ; real_T lembeityuo
; real_T d4p0v0vss4 ; real_T ay2cptztad ; real_T exv3p1v4jj ; real_T
e4j5r50f21 ; real_T kanttbbdxn ; real_T bwh0yvwve3 ; real_T knjqkuouf4 ;
real_T ggjvedpwyt ; real_T dxdgysgdtg ; real_T oa3cfmycwb ; real_T h0gemmgwqr
; real_T ned4cc5vzt ; real_T fdhaztcoc2 ; real_T pu5lktlcas ; real_T
g0o1wpdbxg [ 2 ] ; real_T epu1od2z3b [ 2 ] ; real_T csnrzy0iqi [ 2 ] ; real_T
d0ybc50sf5 [ 2 ] ; real_T c35mnyoypo [ 2 ] ; real_T iw5hzk5ywo ; real_T
mw3ltyhgaq ; real_T lmhlh5bg0f ; real_T nzxtwlwo5a ; real_T orec4knmbq ;
real_T g2zxdezbqj ; boolean_T iuu4gu1wyz ; boolean_T jkdvwizaew ; boolean_T
balyysqv1b ; } ge35uyxws2 ; typedef struct { real_T fvusqauovt ; real_T
gmbbulyulz ; real_T lldq10kdgi ; real_T dqiyqlugl0 ; real_T bp5rhabkf5 ;
real_T nbgtroohkg ; real_T jn3040zvov ; real_T eaityd5ajk ; real_T imgm0rpqwi
; real_T og2pwjuh10 ; real_T mqr1hldpqu ; real_T jpewultcy5 ; struct { void *
AQHandles ; void * SlioLTF ; } pltpaynpls ; struct { void * AQHandles ; void
* SlioLTF ; } jkwi220iqz ; struct { void * AQHandles ; void * SlioLTF ; }
cu05nxaf40 ; struct { void * AQHandles ; void * SlioLTF ; } n155mxzhw5 ;
int_T m14qcaqwit ; int_T ounvmam0u1 ; int_T kzfftoj5za ; int8_T nxxxvt2tsy ;
int8_T gscwjg2ssg ; int8_T ne4s5y0g5x ; int8_T nsrjoadkqv ; int8_T jrfcvp5vk0
; boolean_T gbfkdy5hae ; boolean_T chnacr0xou ; boolean_T iwppuvv1ur ;
boolean_T cjgcjykoqm ; boolean_T oni231igvs ; boolean_T niprcnjzdl ;
boolean_T osw5avj40o ; boolean_T diynwgxlml ; boolean_T lhlel1ynfr ;
boolean_T cyr4ai4mvm ; boolean_T geybp5fzrq ; boolean_T osp05gkx4d ;
boolean_T l1mdkuohlj ; boolean_T edqwqku41b ; boolean_T fkpjrs4o24 ;
boolean_T n0rpckw41r ; boolean_T iqpmfwoqds ; boolean_T aeif0xwhyn ;
boolean_T hemp4yskou ; boolean_T it2u2rr5yn ; n1ljxg42ztp glqdunu2lj ;
n1ljxg42ztp okhenkpr2y ; ceyldc12a32 eluq2mb3wb ; kevw5qu2wxg ixf1adrdko ;
knl0xklyur4 gwzkxzfyqn ; l20fhy3pjtc dnnf50yoyi ; } pjrkh50oo5 ; typedef
struct { itsu1yon4s cmyhlb5dcn ; } kffjcg2trg ; typedef struct { nes2y3gbqk
cmyhlb5dcn ; } k0l4gtazue ; typedef struct { aslryh0fym cmyhlb5dcn ; }
fchgvwri0g ; typedef struct { devq5mhm54 cmyhlb5dcn ; } hh1vgedtlr ; typedef
struct { ayscym2s52 goqy3tpyj1 ; real_T jpohlri3ou ; real_T jyslrxnvgo ;
ayscym2s52 nszvxcrb2e ; real_T hsbig4gxzs ; real_T e0vngtj0jc ; dgl2ktxaof
ebxpj0bebg ; real_T e5vcpzpc4e ; real_T ia5r3aldah ; real_T h3byc5nxpu ;
real_T nm1jxurgoo ; real_T pway4swfql ; real_T g01zqht5it ; real_T gatter2g3w
; real_T ffmic3unrt ; real_T iqvwk4zy2o ; kiif3lkxev cy1b34uw2i ; real_T
nj5zqkye1h ; real_T euszyri155 ; real_T ltgggczqzs ; real_T nwipxusnt5 ; }
gffsp5zqsa ; struct asft2rxf2k4_ { real_T P_0 ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ;
real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T
P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ;
real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T
P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ;
real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T
P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ;
real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T
P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ;
real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T
P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ;
real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T P_68 ; real_T
P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ;
real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T P_79 ; real_T
P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ; real_T P_84 ; real_T P_85 ;
real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T P_89 ; real_T P_90 ; real_T
P_91 ; real_T P_92 ; real_T P_93 ; boolean_T P_94 ; boolean_T P_95 ;
boolean_T P_96 ; } ; struct nklcg3tso3 { struct SimStruct_tag * _mdlRefSfcnS
; struct { real_T mr_nonContSig0 [ 1 ] ; real_T mr_nonContSig1 [ 1 ] ; }
NonContDerivMemory ; ssNonContDerivSigInfo nonContDerivSignal [ 2 ] ; const
rtTimingBridge * timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 6 ] ; sysRanDType * systemRan [ 14 ] ;
int_T systemTid [ 14 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf2 ;
uint8_T rtmDbBufWriteBuf2 ; boolean_T rtmDbBufLastBufWr2 ; real_T
rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3 ] ; } Timing ; } ; typedef
struct { ge35uyxws2 rtb ; pjrkh50oo5 rtdw ; cmwsj44kkr rtm ; } lfq44zo2ofx ;
extern void gxfigcng3t ( SimStruct * _mdlRefSfcnS ,
ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray , int_T
mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , cmwsj44kkr * const
bblcy0xiwg , ge35uyxws2 * localB , pjrkh50oo5 * localDW , kffjcg2trg * localX
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ;
extern void mr_own_collector_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T
* modelName , int_T * retVal ) ; extern mxArray * mr_own_collector_GetDWork (
const lfq44zo2ofx * mdlrefDW ) ; extern void mr_own_collector_SetDWork (
lfq44zo2ofx * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_own_collector_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray
* mr_own_collector_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * own_collector_GetCAPIStaticMap ( void ) ;
extern void pvqrrt4gzr ( ge35uyxws2 * localB , pjrkh50oo5 * localDW ,
kffjcg2trg * localX ) ; extern void kx4txi4cp1 ( pjrkh50oo5 * localDW ,
kffjcg2trg * localX ) ; extern void j2x2cw1i3d ( cmwsj44kkr * const
bblcy0xiwg , pjrkh50oo5 * localDW ) ; extern void ijykioko0c ( pjrkh50oo5 *
localDW , k0l4gtazue * localXdot ) ; extern void ady1rfwkfk ( const real_T *
mm153lcsxe , const real_T * ivnvul0bp5 , const real_T * nmrcnm4heg ,
ge35uyxws2 * localB , pjrkh50oo5 * localDW , gffsp5zqsa * localZCSV ) ;
extern void bcrwow1epr ( pjrkh50oo5 * localDW ) ; extern void lgz2y4ylku (
cmwsj44kkr * const bblcy0xiwg , real_T * gj4d11rx00 , real_T * hmvzqi50b2 ,
ge35uyxws2 * localB , pjrkh50oo5 * localDW ) ; extern void lgz2y4ylkuTID2 (
void ) ; extern void own_collector ( cmwsj44kkr * const bblcy0xiwg , const
real_T * mm153lcsxe , const real_T * ivnvul0bp5 , const boolean_T *
l4bbktq3gc , const real_T * jgc1ccpwgd , const real_T * gfzex4yvzj , const
real_T * aibhxf3a2l , const real_T * mvtigwhmg0 , const real_T * mnh1zfnwqk ,
const real_T * nmrcnm4heg , const real_T * h0w0gyoplk , const real_T *
ai0dhcuqnv , const real_T * f5y3azqr4h , const real_T * lhbtoj2edj , const
real_T * ddtwzb5eam , real_T * hdkfaxw2gj , real_T * pejvsxnego , real_T *
crq5en5cw1 , real_T * gj4d11rx00 , real_T * hmvzqi50b2 , real_T * hlcts02lmw
, real_T * lxit2jc2vj , ge35uyxws2 * localB , pjrkh50oo5 * localDW ,
kffjcg2trg * localX ) ; extern void own_collectorTID2 ( ge35uyxws2 * localB ,
pjrkh50oo5 * localDW ) ; extern void ljztqzzhfd ( cmwsj44kkr * const
bblcy0xiwg , pjrkh50oo5 * localDW ) ;
#endif
