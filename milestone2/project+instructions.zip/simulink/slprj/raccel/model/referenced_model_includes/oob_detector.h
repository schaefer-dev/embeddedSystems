#include "__cf_oob_detector.h"
#ifndef RTW_HEADER_oob_detector_h_
#define RTW_HEADER_oob_detector_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef oob_detector_COMMON_INCLUDES_
#define oob_detector_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "oob_detector_types.h"
#include "multiword_types.h"
#include "rt_nonfinite.h"
typedef struct { boolean_T h4co5hwant ; } ku31qekfgz ; typedef struct {
boolean_T aml1plg3fs ; } gpas0afkqt ; struct enq4kvqylxp_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; boolean_T P_11 ; } ;
struct k2eeinuyze { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { ku31qekfgz rtb ; gpas0afkqt rtdw ; oiwtoi0qfk rtm ; }
ehskdstrnzo ; extern void hj4ja2w2cq ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , oiwtoi0qfk * const ls5dxafs0b , ku31qekfgz
* localB , gpas0afkqt * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_oob_detector_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName
, int_T * retVal ) ; extern mxArray * mr_oob_detector_GetDWork ( const
ehskdstrnzo * mdlrefDW ) ; extern void mr_oob_detector_SetDWork ( ehskdstrnzo
* mdlrefDW , const mxArray * ssDW ) ; extern void
mr_oob_detector_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_oob_detector_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * oob_detector_GetCAPIStaticMap ( void ) ;
extern void o0lwzfbtnn ( gpas0afkqt * localDW ) ; extern void p3mvulmkdi (
gpas0afkqt * localDW ) ; extern void kq3phz0cki ( ku31qekfgz * localB ,
gpas0afkqt * localDW ) ; extern void kq3phz0ckiTID1 ( void ) ; extern void
oob_detector ( const real_T * epxbfliq2l , const real_T * b4klmdsoxd , const
real_T * jnd5qwcxq4 , const real_T * f21sto55h4 , boolean_T * ecjmu3u1jl ,
ku31qekfgz * localB , gpas0afkqt * localDW ) ; extern void oob_detectorTID1 (
void ) ; extern void fzr211oaq0 ( oiwtoi0qfk * const ls5dxafs0b ) ;
#endif
