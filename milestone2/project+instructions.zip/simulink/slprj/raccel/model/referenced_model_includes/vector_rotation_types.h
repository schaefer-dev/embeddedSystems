#include "__cf_vector_rotation.h"
#ifndef RTW_HEADER_vector_rotation_types_h_
#define RTW_HEADER_vector_rotation_types_h_
typedef struct ncxgkknqwk f2yyvn3djo ;
#endif
