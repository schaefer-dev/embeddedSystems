#include "__cf_lights.h"
#ifndef RTW_HEADER_lights_capi_h_
#define RTW_HEADER_lights_capi_h_
#include "lights.h"
extern void lights_InitializeDataMapInfo ( ieoalh2akm * const hvf2ni0bda ,
prtjfggemg * localDW , void * sysRanPtr , int contextTid ) ;
#endif
