#include "__cf_theta_correction.h"
#ifndef RTW_HEADER_theta_correction_capi_h_
#define RTW_HEADER_theta_correction_capi_h_
#include "theta_correction.h"
extern void theta_correction_InitializeDataMapInfo ( nci50w0kfs * const
cigb32oe2e , ozjhelv2xk * localDW , void * sysRanPtr , int contextTid ) ;
#endif
