#include "__cf_referee.h"
#ifndef RTW_HEADER_referee_h_
#define RTW_HEADER_referee_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef referee_COMMON_INCLUDES_
#define referee_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "referee_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "oob_detector.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T azjqpqx5ad ; real_T imdcbgvhzw ; real_T epr3amh12f ;
} bitvvssvml ; typedef struct { real_T cofcfbst4n ; real_T pf1oeq2lz2 ;
real_T hybgzvhdlx ; real_T fmohgpvyin ; real_T dazfd1encs ; real_T jmup03onu0
; real_T gctcsvbw0e ; real_T mrt4lxgryi ; real_T bv5hgpc5p5 ; real_T
puvumt3q1v ; real_T b34c1fp01a ; boolean_T e1uikcfzby ; boolean_T n5npuejdw3
; bitvvssvml pydbwlglcz ; bitvvssvml ga5p2iwx2s ; bitvvssvml ec2qvb3goi ;
bitvvssvml h1qerrq5kfi ; } nodzjf11vb ; typedef struct { real_T kzdud5czgz ;
real_T oye1ko42cb ; int_T kgsk0zpmuq ; int_T di2kqf2aax ; int_T jggfach0in ;
int_T n1adionjkr ; int8_T jwl1wopfjl ; int8_T oq5ljrqwxc ; boolean_T
jgq0x2aouo ; boolean_T awwljmrsm0 ; ehskdstrnzo cesfexowcc ; ehskdstrnzo
jpte2jfdpi ; ehskdstrnzo lr4441zqxa ; ehskdstrnzo oknbmx5ah5 ; } appkse231e ;
typedef struct { real_T hku43al4zc ; real_T ekhmf5nkqn ; } ht5eljqmzr ;
typedef struct { real_T hku43al4zc ; real_T ekhmf5nkqn ; } enfmk51rhf ;
typedef struct { boolean_T hku43al4zc ; boolean_T ekhmf5nkqn ; } ewqsq3nueu ;
typedef struct { real_T hku43al4zc ; real_T ekhmf5nkqn ; } fl5hh3aqjo ;
typedef struct { real_T azzpscu0ww ; real_T j20ez42wub ; real_T ohha4ec3id ;
real_T bcuenxigx3 ; } cy0dgds3yt ; struct ddqvav324h_ { real_T P_0 ; } ;
struct iodzcxfysu1_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ;
real_T P_10 ; real_T P_11 ; ddqvav324h pydbwlglcz ; ddqvav324h ga5p2iwx2s ;
ddqvav324h ec2qvb3goi ; ddqvav324h h1qerrq5kfi ; } ; struct olitrjin0r {
struct SimStruct_tag * _mdlRefSfcnS ; struct { boolean_T mr_nonContSig0 [ 1 ]
; } NonContDerivMemory ; ssNonContDerivSigInfo nonContDerivSignal [ 1 ] ;
const rtTimingBridge * timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
2 ] ; int32_T * vardimsAddress [ 2 ] ; RTWLoggingFcnPtr loggingPtrs [ 2 ] ;
rtwCAPI_ModelMappingInfo * childMMI [ 4 ] ; sysRanDType * systemRan [ 18 ] ;
int_T systemTid [ 18 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 4
] ; } Timing ; } ; typedef struct { nodzjf11vb rtb ; appkse231e rtdw ;
ondkm4so4b rtm ; } oak5mylmriv ; extern void bizwd1ewox ( SimStruct *
_mdlRefSfcnS , ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray ,
int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , int_T mdlref_TID3
, ondkm4so4b * const cyqsf0f3xu , nodzjf11vb * localB , appkse231e * localDW
, ht5eljqmzr * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void mr_referee_MdlInfoRegFcn
( SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern
mxArray * mr_referee_GetDWork ( const oak5mylmriv * mdlrefDW ) ; extern void
mr_referee_SetDWork ( oak5mylmriv * mdlrefDW , const mxArray * ssDW ) ;
extern void mr_referee_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_referee_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * referee_GetCAPIStaticMap ( void ) ; extern
void h1qerrq5kf ( boolean_T chdmf5o235 , const real_T * i0wj0mygob , const
real_T * p1waebxs1r , const real_T * jg0ggc5j34 , const real_T * jy4wznl4kl ,
real_T * pitjsw4hwr , real_T * lesa5dn2zy , real_T * atjdki5tta , bitvvssvml
* localB , ddqvav324h * localP ) ; extern void ek3ozf0cq4 ( ondkm4so4b *
const cyqsf0f3xu , appkse231e * localDW , ht5eljqmzr * localX ) ; extern void
bkjktesovd ( ondkm4so4b * const cyqsf0f3xu , appkse231e * localDW ,
ht5eljqmzr * localX ) ; extern void pyx2inetck ( nodzjf11vb * localB ,
appkse231e * localDW ) ; extern void ilqjwbwvk1 ( nodzjf11vb * localB ,
enfmk51rhf * localXdot ) ; extern void iom21vwq3d ( nodzjf11vb * localB ,
appkse231e * localDW , cy0dgds3yt * localZCSV ) ; extern void grtuha5m30 (
ondkm4so4b * const cyqsf0f3xu , nodzjf11vb * localB , appkse231e * localDW )
; extern void grtuha5m30TID3 ( void ) ; extern void referee ( ondkm4so4b *
const cyqsf0f3xu , const real_T * faeloedmai , const real_T * d2uulqnvkx ,
const real_T * o5islpesz3 , const real_T * hyxiki45ww , const real_T *
gjp4avxxqk , const real_T * l43dhjciaa , const real_T * hvi0grbpxe , const
real_T * jgbjqxpamn , const real_T * oumzrqvskp , const real_T * po504okman ,
const real_T * ndgc5z2qq4 , const real_T * cvhdjadrqy , const real_T *
n43chvautz , const real_T * eoyvoay3ob , const real_T * fgnaiqe52w , const
real_T * km4fleofn0 , const real_T * dlnb0gvg3k , const real_T * fwgnj5wgpf ,
const real_T * akl5ido2g0 , real_T * cgltflh2jt , real_T * m2i1r44z5y ,
real_T * dp2vbzotbq , real_T * cn52noxqhh , real_T * lruvxfb5ei , real_T *
pmy2omej21 , real_T * cgbkbtf2xi , real_T * eqnjk3fy3s , boolean_T *
apayuiniyz , boolean_T * etanksvt44 , real_T * ff4fgsbwx0 , real_T *
hq3e0gq1rh , real_T * dgzwvzs205 , real_T * mr331uy2xc , real_T * gntl10ca5l
, real_T * kjdqgmx2fp , boolean_T * h02jp2kx0l , boolean_T * ot2uaao3cb ,
nodzjf11vb * localB , appkse231e * localDW , ht5eljqmzr * localX ) ; extern
void refereeTID3 ( nodzjf11vb * localB ) ; extern void jbgnykfk4w (
appkse231e * localDW , ondkm4so4b * const cyqsf0f3xu ) ;
#endif
