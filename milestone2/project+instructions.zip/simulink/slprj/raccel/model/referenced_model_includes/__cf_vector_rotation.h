#ifndef CF_vector_rotation_H__
#define CF_vector_rotation_H__
#endif
