#include "__cf_collision_between_two_robots.h"
#ifndef RTW_HEADER_collision_between_two_robots_h_
#define RTW_HEADER_collision_between_two_robots_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef collision_between_two_robots_COMMON_INCLUDES_
#define collision_between_two_robots_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "collision_between_two_robots_types.h"
#include "multiword_types.h"
#include "check_collision_with_bounding.h"
#include "rt_nonfinite.h"
typedef struct { pwumfdjokh3 ddmunrklls ; pwumfdjokh3 pveuch1us5 ;
pwumfdjokh3 omy5bzwku5 ; pwumfdjokh3 c2p4x13tse ; pwumfdjokh3 lud0lsws1r ;
pwumfdjokh3 d052an5vz3 ; pwumfdjokh3 lkijrf5rww ; pwumfdjokh3 m0zpvbz51r ; }
hmfgq0pduk ; typedef struct { a4o4bify4r owuxdtzoig ; a4o4bify4r eeozmf2aou ;
a4o4bify4r a5ajufwhl4 ; a4o4bify4r g3fyfyg2z5 ; a4o4bify4r lebxfuu3gd ;
a4o4bify4r khy5m1sv2i ; a4o4bify4r la2ajilz3t ; a4o4bify4r l5zg5q0eg0 ; }
iimqbbjb2z ; struct ooflf54s5f { struct SimStruct_tag * _mdlRefSfcnS ; struct
{ rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 8 ] ; sysRanDType
* systemRan [ 2 ] ; int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T
mdlref_GlobalTID [ 1 ] ; } Timing ; } ; typedef struct { hmfgq0pduk rtdw ;
gvmzk0fl4d rtm ; } alscpsbetdd ; extern void mwju1cce1h ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , gvmzk0fl4d * const cle1hx0fby , hmfgq0pduk
* localDW , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_collision_between_two_robots_MdlInfoRegFcn (
SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern
mxArray * mr_collision_between_two_robots_GetDWork ( const alscpsbetdd *
mdlrefDW ) ; extern void mr_collision_between_two_robots_SetDWork (
alscpsbetdd * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_collision_between_two_robots_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_collision_between_two_robots_GetSimStateDisallowedBlocks
( ) ; extern const rtwCAPI_ModelMappingStaticInfo *
collision_between_two_robots_GetCAPIStaticMap ( void ) ; extern void
hrcfg5ieq3 ( hmfgq0pduk * localDW ) ; extern void lykin54hlj ( hmfgq0pduk *
localDW , iimqbbjb2z * localZCSV ) ; extern void collision_between_two_robots
( const real_T cqnf1hvbbq [ 2 ] , const real_T kgq5gprc4c [ 2 ] , const
real_T ea0wflbvz5 [ 2 ] , const real_T akxeqwc2of [ 2 ] , const real_T
hazmue4lk1 [ 2 ] , const real_T cqbom3utsp [ 2 ] , const real_T bh1kmek4w4 [
2 ] , const real_T flh2dyfykp [ 2 ] , real_T * kdaes4ewfm , real_T *
btrcky5iv0 , real_T * f53nk1solk , real_T * nejzdpvfk3 , real_T * azlp514mtk
, real_T * eqaslwac2f , real_T * fosinrpole , real_T * pp1bob34u4 , real_T *
fn31plbhb3 , real_T * j2e4k0fal2 , real_T * lbamjxjn3j , real_T * j3xj1j3h2f
, real_T * l2vgl4d2e4 , real_T * pjj5yv04cg , real_T * ouupl0cdgc , real_T *
afjol4u5nf , real_T * g10tao1zsn , real_T * mgpl4k3ppa , real_T * pkcbyilhxw
, real_T * jdrlhzvtev , real_T * dx2y3gq1u4 , real_T * kotkzrgcsa , real_T *
ptmzf1eebl , real_T * pd5vefvn4n , real_T * dffsuv5xm0 , real_T * clmcpj43dq
, real_T * h4hpoqrnra , real_T * n5ga5jisx1 , real_T * nnohfvoqbc , real_T *
fefoxb05bs , real_T * jushde1qle , real_T * pnp4saief2 , hmfgq0pduk * localDW
) ; extern void ppne3p4rj0 ( hmfgq0pduk * localDW , gvmzk0fl4d * const
cle1hx0fby ) ;
#endif
