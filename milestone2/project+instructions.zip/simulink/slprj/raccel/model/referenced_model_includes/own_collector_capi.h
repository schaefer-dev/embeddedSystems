#include "__cf_own_collector.h"
#ifndef RTW_HEADER_own_collector_capi_h_
#define RTW_HEADER_own_collector_capi_h_
#include "own_collector.h"
extern void own_collector_InitializeDataMapInfo ( cmwsj44kkr * const
bblcy0xiwg , pjrkh50oo5 * localDW , void * sysRanPtr , int contextTid ) ;
#endif
