#include "__cf_check_collision_with_bounding.h"
#ifndef RTW_HEADER_check_collision_with_bounding_h_
#define RTW_HEADER_check_collision_with_bounding_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef check_collision_with_bounding_COMMON_INCLUDES_
#define check_collision_with_bounding_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "check_collision_with_bounding_types.h"
#include "multiword_types.h"
#include "to_line_segments.h"
#include "rt_nonfinite.h"
typedef struct { real_T i33aua3itk ; real_T hsak5qsaji ; real_T gujgvxpe5h ;
real_T pawgmgahze ; } pqr3o0henh ; typedef struct { int_T nujdfx1zvk ; int_T
dytv4pfvv3 ; int_T airptslae2 ; int_T a1rwb52k02 ; hiop4a4wknb blairxx1vj ;
hiop4a4wknb arprv3o2vz ; hiop4a4wknb o30mbzurqt ; hiop4a4wknb gc4fzs2b2z ; }
efinskpodg ; typedef struct { real_T pegcidfdsy ; real_T oacisbyhw1 ; real_T
ihbii4vefz ; real_T cpvzfdd0fy ; } a4o4bify4r ; struct baldpu2bah { struct
SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 4 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 1 ]
; } Timing ; } ; typedef struct { pqr3o0henh rtb ; efinskpodg rtdw ;
lv1w310d1o rtm ; } pwumfdjokh3 ; extern void pliranin35 ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , lv1w310d1o * const ne0pyymecy , pqr3o0henh
* localB , efinskpodg * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_check_collision_with_bounding_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_check_collision_with_bounding_GetDWork ( const pwumfdjokh3 * mdlrefDW ) ;
extern void mr_check_collision_with_bounding_SetDWork ( pwumfdjokh3 *
mdlrefDW , const mxArray * ssDW ) ; extern void
mr_check_collision_with_bounding_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_check_collision_with_bounding_GetSimStateDisallowedBlocks
( ) ; extern const rtwCAPI_ModelMappingStaticInfo *
check_collision_with_bounding_GetCAPIStaticMap ( void ) ; extern void
i4c20is4cv ( efinskpodg * localDW ) ; extern void pdwmgeosum ( pqr3o0henh *
localB , a4o4bify4r * localZCSV ) ; extern void check_collision_with_bounding
( lv1w310d1o * const ne0pyymecy , const real_T lry1xnto3a [ 2 ] , const
real_T p0u2sizukj [ 2 ] , const real_T eehn2nro0z [ 2 ] , const real_T
minwt0uhrb [ 2 ] , const real_T nljvsh4hie [ 2 ] , real_T * kdf2ekgda1 ,
real_T * hcsviezkmc , real_T * ftwulus2t5 , real_T * lymbh00sji , pqr3o0henh
* localB , efinskpodg * localDW ) ; extern void agrzpxqxax ( efinskpodg *
localDW , lv1w310d1o * const ne0pyymecy ) ;
#endif
