#include "__cf_generate_proximity_sensor_re0.h"
#ifndef RTW_HEADER_generate_proximity_sensor_re0_capi_h_
#define RTW_HEADER_generate_proximity_sensor_re0_capi_h_
#include "generate_proximity_sensor_re0.h"
extern void generate_proximity_sensor_re0_InitializeDataMapInfo ( ex4gaboq54
* const f3p40zvy1f , gxmdy5cswd * localDW , void * sysRanPtr , int contextTid
) ;
#endif
