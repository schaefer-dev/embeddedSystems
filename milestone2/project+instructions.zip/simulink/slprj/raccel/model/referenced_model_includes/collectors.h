#include "__cf_collectors.h"
#ifndef RTW_HEADER_collectors_h_
#define RTW_HEADER_collectors_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef collectors_COMMON_INCLUDES_
#define collectors_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "collectors_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "theta_correction.h"
#include "enable_hold.h"
#include "differential_drive.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
typedef struct { real_T pdc0nmj4hf ; real_T hngyfvqpgw ; real_T ozn2fano21 ;
real_T b01fd3houa ; real_T diaxldekhu ; real_T gogt1d2csu ; real_T h4ffw12002
; real_T pnrmy5pt0a ; real_T oktwnaytk1 ; real_T lhpteadr0x ; real_T
bo3yk1zi4u ; real_T izkax3ozd2 ; real_T dgvdxeiddq ; real_T pydz3y3yv5 ;
real_T gsyfdaw4em ; real_T bj3y0ixfut ; real_T amefm4tzmg ; real_T dobjugjpu2
; real_T l11apivhsv ; real_T gdr2ioefwl ; real_T ngiofh2aao ; real_T
nut0um4ywp ; real_T ga3g0ygafw ; boolean_T n3ue5eu4ae ; boolean_T lu1gaeouvr
; } hyovovrsd4 ; typedef struct { real_T neijca2aa0 ; real_T c3kby1aas1 ;
real_T pyv54bcszh ; real_T l2uesssmqp ; real_T oedmhddfuu ; struct { void *
AQHandles ; void * SlioLTF ; } cfwuamncbt ; struct { void * AQHandles ; void
* SlioLTF ; } a1ke0ybzoy ; struct { void * AQHandles ; void * SlioLTF ; }
kzdmj1p3ja ; struct { void * AQHandles ; void * SlioLTF ; } j2jhbbnvxa ;
int_T odyseg1rwq ; int_T dkvmcj4vbo ; int_T ph53rkyasy ; int8_T kpdlqt3sqz ;
boolean_T cue4epbxs1 ; boolean_T f5mq4pxf3g ; boolean_T i2kfaargqy ;
boolean_T dlwhmkwakq ; boolean_T goc2stz4xv ; boolean_T kyrqx4vhbt ;
boolean_T j4xzkmpvu5 ; boolean_T hgxsmjezq5 ; n1ljxg42ztp ndumhg2xop ;
n1ljxg42ztp pcu5iliyv2 ; ceyldc12a32 kfqrefdtma ; kevw5qu2wxg g0r4ymcmco ; }
jma5b1bq35 ; typedef struct { itsu1yon4s mlafm4a2kv ; } b42hzqgmbd ; typedef
struct { nes2y3gbqk mlafm4a2kv ; } ncpvkuj3c4 ; typedef struct { aslryh0fym
mlafm4a2kv ; } b55xret0yr ; typedef struct { devq5mhm54 mlafm4a2kv ; }
hxzibpq3xb ; typedef struct { ayscym2s52 lhktdszytm ; ayscym2s52 kpxvmmdk2t ;
dgl2ktxaof a25f4a5nee ; real_T oz2vdctrir ; real_T a3mmezjzek ; real_T
fnooglxgja ; real_T fpvzakf51m ; real_T fwxu1jsfre ; real_T ii2bzafydq ;
real_T l3tf2z02z5 ; kiif3lkxev nh0mog2na5 ; } gqs0ayjk3c ; struct
eqobxgoyezm_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T
P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T
P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ;
real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T
P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ;
real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T
P_43 ; boolean_T P_44 ; boolean_T P_45 ; } ; struct jfa1zfim0v { struct
SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ; real_T
mr_nonContSig1 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 2 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 4 ] ; sysRanDType
* systemRan [ 11 ] ; int_T systemTid [ 11 ] ; } DataMapInfo ; struct {
uint8_T rtmDbBufReadBuf2 ; uint8_T rtmDbBufWriteBuf2 ; boolean_T
rtmDbBufLastBufWr2 ; real_T rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3
] ; } Timing ; } ; typedef struct { hyovovrsd4 rtb ; jma5b1bq35 rtdw ;
pdhslryz2b rtm ; } n2raavie0r3 ; extern void fskm0v2x2z ( SimStruct *
_mdlRefSfcnS , ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray ,
int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , pdhslryz2b *
const npwdrebuui , hyovovrsd4 * localB , jma5b1bq35 * localDW , b42hzqgmbd *
localX , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_collectors_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_collectors_GetDWork ( const n2raavie0r3 * mdlrefDW ) ; extern void
mr_collectors_SetDWork ( n2raavie0r3 * mdlrefDW , const mxArray * ssDW ) ;
extern void mr_collectors_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_collectors_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * collectors_GetCAPIStaticMap ( void ) ;
extern void a0x1yrikye ( hyovovrsd4 * localB , jma5b1bq35 * localDW ,
b42hzqgmbd * localX ) ; extern void kyhcohuznm ( jma5b1bq35 * localDW ,
b42hzqgmbd * localX ) ; extern void a4pd0ca5cg ( pdhslryz2b * const
npwdrebuui , jma5b1bq35 * localDW ) ; extern void lqizubt0d2 ( jma5b1bq35 *
localDW , ncpvkuj3c4 * localXdot ) ; extern void iqwtbjefxp ( const real_T *
dvjucuzzmu , hyovovrsd4 * localB , jma5b1bq35 * localDW , gqs0ayjk3c *
localZCSV ) ; extern void dn5sevcmw0 ( jma5b1bq35 * localDW ) ; extern void
ixdd0mmlc0 ( pdhslryz2b * const npwdrebuui , real_T * k2du1qrl5u , real_T *
a1bh0yxhhi , hyovovrsd4 * localB , jma5b1bq35 * localDW ) ; extern void
ixdd0mmlc0TID2 ( void ) ; extern void collectors ( pdhslryz2b * const
npwdrebuui , const real_T * fk2c0ccj2c , const real_T * btvo5en4ud , const
boolean_T * iotnreyvax , const real_T * dz1jubqcyh , const real_T *
ef3k1j1yal , const real_T * k45bautdum , const real_T * mxofui1bba , const
real_T * hkwpse42jr , const real_T * dvjucuzzmu , real_T * d4huorahpr ,
real_T * anibmz4x0j , real_T * hnta3h5b0t , real_T * cyxhubwqby , real_T *
nsorbwa4pw , real_T * k2du1qrl5u , real_T * a1bh0yxhhi , hyovovrsd4 * localB
, jma5b1bq35 * localDW , b42hzqgmbd * localX ) ; extern void collectorsTID2 (
jma5b1bq35 * localDW ) ; extern void ccpkj4xp2g ( pdhslryz2b * const
npwdrebuui , jma5b1bq35 * localDW ) ;
#endif
