#include "__cf_enable_hold.h"
#ifndef RTW_HEADER_enable_hold_capi_h_
#define RTW_HEADER_enable_hold_capi_h_
#include "enable_hold.h"
extern void enable_hold_InitializeDataMapInfo ( j40hacjaod * const m5524orqff
, isbf0vjqji * localDW , void * sysRanPtr , int contextTid ) ;
#endif
