#include "__cf_collide_between.h"
#ifndef RTW_HEADER_collide_between_h_
#define RTW_HEADER_collide_between_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef collide_between_COMMON_INCLUDES_
#define collide_between_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "collide_between_types.h"
#include "multiword_types.h"
#include "collision_between_two_robots.h"
#include "calculate_collision_effects.h"
#include "bounding_box_calc.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T b1lxboq0nr [ 2 ] ; real_T jaw4jq5i4l [ 2 ] ; real_T
gbg2uum1yo [ 2 ] ; real_T ey5kk21gfs [ 2 ] ; real_T m4zal3w0ln [ 2 ] ; real_T
e2iohf0oaq [ 2 ] ; real_T ccz4fezwxu [ 2 ] ; real_T dnkkax23uu [ 2 ] ; real_T
ljwmuuz4q3 ; real_T fcboqja0ri ; real_T kpuedxhpyi ; real_T ofgarm1ld3 ;
real_T abffb4kyof ; real_T bii0uc2qtt ; real_T lifetzu3z5 ; real_T hgzpghkg22
; real_T imxxijqg21 ; real_T fpfbc0gosq ; real_T acuqy4u4b1 ; real_T
p310k0tjoa ; real_T ashqba03j0 ; real_T idddua3mxb ; real_T m03yodakzw ;
real_T d32qz0xifn ; real_T m5gfuwsgrh ; real_T d25dphbvhy ; real_T dfurjr5qtf
; real_T f0aytpalcp ; real_T djevy4krgv ; real_T loja1ifkyz ; } ex0mzjx2dh ;
typedef struct { int_T ng1osjo4sf ; int_T h2ru2roh3b ; int_T bjl0j4aebl ;
int_T mfqbmx4mtw ; int_T olke42stum ; int_T d2zo2mzgqj ; nqg40qhj3f4
okvgmhwpxu ; nqg40qhj3f4 gxbwutzaad ; alscpsbetdd gcuvu3m0di ; hsv52bpfnq0
frtlkcykq2 ; hsv52bpfnq0 andmdsa3j2 ; } f0welreujf ; typedef struct {
iimqbbjb2z pq5i5waaj2 ; real_T f3bl4bzknt ; real_T btelntelql ; real_T
ejfuhrskm1 ; real_T bp1owqberd ; real_T n4bnuf0fyv ; real_T mnp1bce0oj ;
mwunqph4vq blsvh33yee ; mwunqph4vq pmp1m4elur ; } lupwujirzg ; struct
fkbebj4drm1_ { real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6
; real_T P_7 ; real_T P_8 ; real_T P_9 ; } ; struct gvluteqd3x { struct
SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 5 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf1 ;
uint8_T rtmDbBufWriteBuf1 ; boolean_T rtmDbBufLastBufWr1 ; real_T
rtmDbBufContT1 [ 2 ] ; int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef
struct { ex0mzjx2dh rtb ; f0welreujf rtdw ; kkquagm1v4 rtm ; } jv23mlr3c55 ;
extern real_T rtP_collision_detection_distance ; extern real_T rtP_push_force
; extern void hzpcsj4xge ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 ,
int_T mdlref_TID1 , kkquagm1v4 * const enzdlkimmo , ex0mzjx2dh * localB ,
f0welreujf * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_collide_between_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray * mr_collide_between_GetDWork (
const jv23mlr3c55 * mdlrefDW ) ; extern void mr_collide_between_SetDWork (
jv23mlr3c55 * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_collide_between_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_collide_between_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * collide_between_GetCAPIStaticMap ( void ) ;
extern void l4wp2x1qk5 ( f0welreujf * localDW ) ; extern void a5luif514d (
ex0mzjx2dh * localB , f0welreujf * localDW , lupwujirzg * localZCSV ) ;
extern void collide_between ( kkquagm1v4 * const enzdlkimmo , const real_T *
ovvs4bqoyp , const real_T * fdhlvye24h , const real_T * l5jziqi0ba , const
real_T * pawpwzwy5p , const real_T * dvmkti5moy , const real_T * dmpt42ua2b ,
real_T * ovce2laicm , real_T * eqskzgx34o , real_T * kykyy0cn2i , real_T *
obs1kj5i1i , real_T * gtvqdo3szi , real_T * hajnrpkslx , ex0mzjx2dh * localB
, f0welreujf * localDW ) ; extern void collide_betweenTID1 ( void ) ; extern
void la13zfc2mh ( f0welreujf * localDW , kkquagm1v4 * const enzdlkimmo ) ;
#endif
