#include "__cf_god.h"
#ifndef RTW_HEADER_god_capi_h_
#define RTW_HEADER_god_capi_h_
#include "god.h"
extern void god_InitializeDataMapInfo ( edxhad3kdx * const acvxkx2edu ,
nllisfxscj * localDW , void * sysRanPtr , int contextTid ) ;
#endif
