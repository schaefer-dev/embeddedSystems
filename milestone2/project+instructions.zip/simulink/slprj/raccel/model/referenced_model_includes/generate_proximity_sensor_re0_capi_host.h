#include "__cf_generate_proximity_sensor_re0.h"
#ifndef RTW_HEADER_generate_proximity_sensor_re0_cap_host_h_
#define RTW_HEADER_generate_proximity_sensor_re0_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "prox_sensor_gen_capi_host.h"
#include "prox_sensor_gen_capi_host.h"
#include "prox_sensor_gen_capi_host.h"
#include "bounding_box_calc_capi_host.h"
#include "bounding_box_calc_capi_host.h"
#include "bounding_box_calc_capi_host.h"
#include "vector_rotation_capi_host.h"
#include "vector_rotation_capi_host.h"
#include "vector_rotation_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 9 ] ; prox_sensor_gen_host_DataMapInfo_T child0 ;
prox_sensor_gen_host_DataMapInfo_T child1 ;
prox_sensor_gen_host_DataMapInfo_T child2 ;
bounding_box_calc_host_DataMapInfo_T child3 ;
bounding_box_calc_host_DataMapInfo_T child4 ;
bounding_box_calc_host_DataMapInfo_T child5 ;
vector_rotation_host_DataMapInfo_T child6 ;
vector_rotation_host_DataMapInfo_T child7 ;
vector_rotation_host_DataMapInfo_T child8 ; }
generate_proximity_sensor_re0_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void generate_proximity_sensor_re0_host_InitializeDataMapInfo (
generate_proximity_sensor_re0_host_DataMapInfo_T * dataMap , const char *
path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
