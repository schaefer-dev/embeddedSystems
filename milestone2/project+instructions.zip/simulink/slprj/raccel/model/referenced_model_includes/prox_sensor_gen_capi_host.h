#include "__cf_prox_sensor_gen.h"
#ifndef RTW_HEADER_prox_sensor_gen_cap_host_h_
#define RTW_HEADER_prox_sensor_gen_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "distance_to_bounding_box_capi_host.h"
#include "distance_to_bounding_box_capi_host.h"
#include "distance_to_bounding_box_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 3 ] ; distance_to_bounding_box_host_DataMapInfo_T child0 ;
distance_to_bounding_box_host_DataMapInfo_T child1 ;
distance_to_bounding_box_host_DataMapInfo_T child2 ; }
prox_sensor_gen_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void prox_sensor_gen_host_InitializeDataMapInfo (
prox_sensor_gen_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
