#include "__cf_scouts.h"
#ifndef RTW_HEADER_scouts_h_
#define RTW_HEADER_scouts_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef scouts_COMMON_INCLUDES_
#define scouts_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "scouts_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "theta_correction.h"
#include "enable_hold.h"
#include "differential_drive.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
typedef struct { real_T jzd4wh0c0z ; real_T izqhq0fvs5 ; real_T bajrzqdsj5 ;
real_T ne54duwrgn ; real_T hlpgye4ahe ; real_T c1yvhzqtyu ; real_T l15zdm5xsf
; real_T oxuspe1cf5 ; real_T h2t4mlmeo4 ; real_T dxizrt5lmi ; real_T
nfsvfgven2 ; real_T d4bodhuzry ; real_T l5mg5vjcu2 ; real_T cgi1hg1azq ;
real_T jaydjsincg ; real_T ht4pgkuzrw ; real_T ewawdplrzw ; real_T nrwinw5m0f
; real_T mykd1ajr2y ; real_T duhcqi21ky ; real_T eogyjmtfe4 ; real_T
il42cdldxr ; real_T peqqaivc0k ; boolean_T cqe5ktnx1l ; boolean_T loqidzjj1u
; } jnxob1m1u0 ; typedef struct { real_T fhqjpufx4r ; real_T pq1abk02oy ;
real_T pz5daxmvrj ; real_T odp4jw0lcb ; real_T lgmtxk21fv ; struct { void *
AQHandles ; void * SlioLTF ; } int0v2v5ds ; struct { void * AQHandles ; void
* SlioLTF ; } mbvpjzfbow ; struct { void * AQHandles ; void * SlioLTF ; }
dulbqxttso ; struct { void * AQHandles ; void * SlioLTF ; } l0iky3vj3y ;
int_T jvqopsdtpy ; int_T eblfk0i4bo ; int_T pumttxegti ; int8_T gc5e2vcmq1 ;
boolean_T l4tk0rw3gi ; boolean_T o2noeq1rso ; boolean_T hte32bnfrh ;
boolean_T pgq10ilrhn ; boolean_T azfzylimta ; boolean_T jk3f4wytuc ;
boolean_T arpfu3fcjx ; boolean_T mo1k0jyfup ; n1ljxg42ztp khdf0jki5r ;
n1ljxg42ztp i14am5vnhw ; ceyldc12a32 j0akg24tkk ; kevw5qu2wxg fu2f255ckh ; }
bow3ugaxbk ; typedef struct { itsu1yon4s nyzroxj105 ; } aacr0kzepk ; typedef
struct { nes2y3gbqk nyzroxj105 ; } efjetl2o44 ; typedef struct { aslryh0fym
nyzroxj105 ; } ipk2smqibi ; typedef struct { devq5mhm54 nyzroxj105 ; }
esxs3zlw1c ; typedef struct { ayscym2s52 lhgxfi5gh0 ; ayscym2s52 k050zhdeor ;
dgl2ktxaof irfnm5cfxr ; real_T ivmrwueseo ; real_T nklmeibpbg ; real_T
hq30tmtufg ; real_T lyrtervbxm ; real_T fzxknwqhsa ; real_T iwe3fdv43y ;
real_T k4ggs5lqhs ; kiif3lkxev bfh2051djj ; } h1iwueqcbz ; struct
oxmi3muauge_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T
P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T
P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ;
real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T
P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ;
real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T
P_43 ; boolean_T P_44 ; boolean_T P_45 ; } ; struct p4kos3gfqq { struct
SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ; real_T
mr_nonContSig1 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 2 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 4 ] ; sysRanDType
* systemRan [ 11 ] ; int_T systemTid [ 11 ] ; } DataMapInfo ; struct {
uint8_T rtmDbBufReadBuf2 ; uint8_T rtmDbBufWriteBuf2 ; boolean_T
rtmDbBufLastBufWr2 ; real_T rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3
] ; } Timing ; } ; typedef struct { jnxob1m1u0 rtb ; bow3ugaxbk rtdw ;
ewygduyfhk rtm ; } mawva2btrby ; extern void big1aezyga ( SimStruct *
_mdlRefSfcnS , ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray ,
int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , ewygduyfhk *
const n4wvtqyiky , jnxob1m1u0 * localB , bow3ugaxbk * localDW , aacr0kzepk *
localX , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_scouts_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_scouts_GetDWork ( const mawva2btrby * mdlrefDW ) ; extern void
mr_scouts_SetDWork ( mawva2btrby * mdlrefDW , const mxArray * ssDW ) ; extern
void mr_scouts_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_scouts_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * scouts_GetCAPIStaticMap ( void ) ; extern
void mgaytvphwb ( jnxob1m1u0 * localB , bow3ugaxbk * localDW , aacr0kzepk *
localX ) ; extern void kvbnrzyvwe ( bow3ugaxbk * localDW , aacr0kzepk *
localX ) ; extern void iye1b0cl0o ( ewygduyfhk * const n4wvtqyiky ,
bow3ugaxbk * localDW ) ; extern void ond1dtpl2z ( bow3ugaxbk * localDW ,
efjetl2o44 * localXdot ) ; extern void adhdkiifhg ( const real_T * cxinyismzw
, jnxob1m1u0 * localB , bow3ugaxbk * localDW , h1iwueqcbz * localZCSV ) ;
extern void lntfmkv4fx ( bow3ugaxbk * localDW ) ; extern void gjw25kr3ka (
ewygduyfhk * const n4wvtqyiky , real_T * er4j3j3wrq , real_T * oyhnn5sot1 ,
jnxob1m1u0 * localB , bow3ugaxbk * localDW ) ; extern void gjw25kr3kaTID2 (
void ) ; extern void scouts ( ewygduyfhk * const n4wvtqyiky , const real_T *
m2hcy2zuzc , const real_T * mqp2kvs0yj , const boolean_T * eq4wc1go4p , const
real_T * idffkznrqh , const real_T * c3jlywns15 , const real_T * m0hffeqcim ,
const real_T * jn3eshpc1j , const real_T * e00mvbiinh , const real_T *
cxinyismzw , real_T * ksxk20k0us , real_T * ga0mvcqlq3 , real_T * hihc0x3ahe
, real_T * jsab22j13l , real_T * fwcjsjhiso , real_T * er4j3j3wrq , real_T *
oyhnn5sot1 , jnxob1m1u0 * localB , bow3ugaxbk * localDW , aacr0kzepk * localX
) ; extern void scoutsTID2 ( bow3ugaxbk * localDW ) ; extern void l3jkn4q33m
( ewygduyfhk * const n4wvtqyiky , bow3ugaxbk * localDW ) ;
#endif
