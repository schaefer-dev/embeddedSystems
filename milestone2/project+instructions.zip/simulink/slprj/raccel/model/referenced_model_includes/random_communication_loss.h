#include "__cf_random_communication_loss.h"
#ifndef RTW_HEADER_random_communication_loss_h_
#define RTW_HEADER_random_communication_loss_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef random_communication_loss_COMMON_INCLUDES_
#define random_communication_loss_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "random_communication_loss_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T jc1wvdpqvx ; uint32_T cyo0zax1jj ; } o5coxopmp3 ;
struct c1ce1drol13_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; } ; struct lgpev4jyf0 { struct SimStruct_tag * _mdlRefSfcnS ;
struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { o5coxopmp3 rtdw ; muyutmqs5w rtm ; } jj23ys45opf ; extern
void lnnomofp20 ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , muyutmqs5w * const b3qc4axbif , o5coxopmp3 * localDW , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern
void mr_random_communication_loss_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_random_communication_loss_GetDWork ( const jj23ys45opf * mdlrefDW ) ;
extern void mr_random_communication_loss_SetDWork ( jj23ys45opf * mdlrefDW ,
const mxArray * ssDW ) ; extern void
mr_random_communication_loss_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_random_communication_loss_GetSimStateDisallowedBlocks ( )
; extern const rtwCAPI_ModelMappingStaticInfo *
random_communication_loss_GetCAPIStaticMap ( void ) ; extern void fqs3kh3vbe
( o5coxopmp3 * localDW ) ; extern void hi4iqbr3xm ( o5coxopmp3 * localDW ) ;
extern void nfcmvisjsv ( o5coxopmp3 * localDW ) ; extern void nfcmvisjsvTID1
( void ) ; extern void random_communication_loss ( const real_T * k3ityuiswy
, real_T * esbowwtnvt , o5coxopmp3 * localDW ) ; extern void
random_communication_lossTID1 ( void ) ; extern void djey55erwv ( muyutmqs5w
* const b3qc4axbif ) ;
#endif
