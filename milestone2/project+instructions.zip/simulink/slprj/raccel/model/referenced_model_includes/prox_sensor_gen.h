#include "__cf_prox_sensor_gen.h"
#ifndef RTW_HEADER_prox_sensor_gen_h_
#define RTW_HEADER_prox_sensor_gen_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef prox_sensor_gen_COMMON_INCLUDES_
#define prox_sensor_gen_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "prox_sensor_gen_types.h"
#include "multiword_types.h"
#include "distance_to_bounding_box.h"
#include "rtGetInf.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T n3h3q2pxfs ; real_T ldacv1h1sd ; real_T hhkcdp3twi ;
} hj4ls4vouj ; typedef struct { d1naxt43mzk eiphricdpb ; d1naxt43mzk
nwwqtscubl ; d1naxt43mzk fchty0gvdl ; } kwarn23huf ; struct ej2zfvfm5dc_ {
real_T P_0 ; real_T P_1 ; real_T P_2 ; } ; struct jvwqtcmqai { struct
SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 3 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf1 ;
uint8_T rtmDbBufWriteBuf1 ; boolean_T rtmDbBufLastBufWr1 ; real_T
rtmDbBufContT1 [ 2 ] ; int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef
struct { hj4ls4vouj rtb ; kwarn23huf rtdw ; d2rk1h1tve rtm ; } ppw2dwepwsm ;
extern void f5n4h5al41 ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , d2rk1h1tve * const jhvh3r1toz , hj4ls4vouj * localB ,
kwarn23huf * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_prox_sensor_gen_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray * mr_prox_sensor_gen_GetDWork (
const ppw2dwepwsm * mdlrefDW ) ; extern void mr_prox_sensor_gen_SetDWork (
ppw2dwepwsm * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_prox_sensor_gen_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_prox_sensor_gen_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * prox_sensor_gen_GetCAPIStaticMap ( void ) ;
extern void prox_sensor_gen ( const real_T hlzfznk23t [ 2 ] , const real_T
a0apouv41f [ 2 ] , const real_T cw2rb1k143 [ 2 ] , const real_T bzowjox05s [
2 ] , const real_T p5qvuwomwg [ 2 ] , const real_T o2p0abn2w1 [ 2 ] , const
real_T ga3bkykjmc [ 2 ] , const real_T dhzfjmumjz [ 2 ] , const real_T
gybzbf4yho [ 2 ] , const real_T oirnwj4nfs [ 2 ] , const real_T ja1alwwnze [
2 ] , const real_T p0tvhy0xxe [ 2 ] , const real_T assujlh45g [ 2 ] , const
real_T jayfffbh5x [ 2 ] , real_T * mconfzjc5q , hj4ls4vouj * localB ,
kwarn23huf * localDW ) ; extern void prox_sensor_genTID1 ( void ) ; extern
void b0y1amyfek ( kwarn23huf * localDW , d2rk1h1tve * const jhvh3r1toz ) ;
#endif
