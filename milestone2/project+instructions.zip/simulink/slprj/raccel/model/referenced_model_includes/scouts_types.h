#include "__cf_scouts.h"
#ifndef RTW_HEADER_scouts_types_h_
#define RTW_HEADER_scouts_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct oxmi3muauge_ oxmi3muauge ; typedef struct p4kos3gfqq
ewygduyfhk ;
#endif
