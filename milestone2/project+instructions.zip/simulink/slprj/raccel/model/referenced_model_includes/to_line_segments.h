#include "__cf_to_line_segments.h"
#ifndef RTW_HEADER_to_line_segments_h_
#define RTW_HEADER_to_line_segments_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef to_line_segments_COMMON_INCLUDES_
#define to_line_segments_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "to_line_segments_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { int8_T nkvsevxzsc ; int8_T fdbzsgjhbn ; int8_T mm4ids1f00 ;
} oxh54ew2sr ; struct etvcjghmtj { struct SimStruct_tag * _mdlRefSfcnS ;
struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 1 ] ; } Timing ; } ;
typedef struct { oxh54ew2sr rtdw ; ouu5lrosbi rtm ; } hiop4a4wknb ; extern
void kcfnbd3ym4 ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , ouu5lrosbi *
const gpglj2bx1v , oxh54ew2sr * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_to_line_segments_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray * mr_to_line_segments_GetDWork
( const hiop4a4wknb * mdlrefDW ) ; extern void mr_to_line_segments_SetDWork (
hiop4a4wknb * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_to_line_segments_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_to_line_segments_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * to_line_segments_GetCAPIStaticMap ( void ) ;
extern void bwtbvc0a4j ( oxh54ew2sr * localDW ) ; extern void
to_line_segments ( ouu5lrosbi * const gpglj2bx1v , const real_T ne0fyfxidj [
2 ] , const real_T duoeqqprm2 [ 2 ] , const real_T gh501tzinn [ 2 ] , real_T
* a3ursx4npg , real_T * jx1ujifd3p , real_T * bz0z3ryabu , oxh54ew2sr *
localDW ) ; extern void f13vsqxakx ( ouu5lrosbi * const gpglj2bx1v ) ;
#endif
