#include "__cf_own_collector.h"
#ifndef RTW_HEADER_own_collector_cap_host_h_
#define RTW_HEADER_own_collector_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "differential_drive_capi_host.h"
#include "enable_hold_capi_host.h"
#include "enable_hold_capi_host.h"
#include "theta_correction_capi_host.h"
#include "calculate_intersection_capi_host.h"
#include "vector_rotation_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 6 ] ; differential_drive_host_DataMapInfo_T child0 ;
enable_hold_host_DataMapInfo_T child1 ; enable_hold_host_DataMapInfo_T child2
; theta_correction_host_DataMapInfo_T child3 ;
calculate_intersection_host_DataMapInfo_T child4 ;
vector_rotation_host_DataMapInfo_T child5 ; }
own_collector_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void own_collector_host_InitializeDataMapInfo (
own_collector_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
