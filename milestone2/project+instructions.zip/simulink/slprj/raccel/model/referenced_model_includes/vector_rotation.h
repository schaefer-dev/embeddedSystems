#include "__cf_vector_rotation.h"
#ifndef RTW_HEADER_vector_rotation_h_
#define RTW_HEADER_vector_rotation_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef vector_rotation_COMMON_INCLUDES_
#define vector_rotation_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "vector_rotation_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
struct ncxgkknqwk { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 1 ] ; } Timing ; } ;
typedef struct { f2yyvn3djo rtm ; } knl0xklyur4 ; extern void lsmrepqzwa (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , f2yyvn3djo * const exrnoff1k1
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ;
extern void mr_vector_rotation_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_vector_rotation_GetDWork ( const knl0xklyur4 * mdlrefDW ) ; extern void
mr_vector_rotation_SetDWork ( knl0xklyur4 * mdlrefDW , const mxArray * ssDW )
; extern void mr_vector_rotation_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_vector_rotation_GetSimStateDisallowedBlocks ( ) ; extern
const rtwCAPI_ModelMappingStaticInfo * vector_rotation_GetCAPIStaticMap (
void ) ; extern void vector_rotation ( const real_T * kvqlwkp2fh , const
real_T jf2yl52kg5 [ 2 ] , real_T pqgqzgaw5e [ 2 ] ) ; extern void f00xw1jonj
( f2yyvn3djo * const exrnoff1k1 ) ;
#endif
