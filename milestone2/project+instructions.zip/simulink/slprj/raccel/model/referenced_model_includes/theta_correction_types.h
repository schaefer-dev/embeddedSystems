#include "__cf_theta_correction.h"
#ifndef RTW_HEADER_theta_correction_types_h_
#define RTW_HEADER_theta_correction_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct ag4o1hq5eci_ ag4o1hq5eci ; typedef struct ft2sg4iq0z
nci50w0kfs ;
#endif
