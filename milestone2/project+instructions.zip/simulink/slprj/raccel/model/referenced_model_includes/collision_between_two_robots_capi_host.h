#include "__cf_collision_between_two_robots.h"
#ifndef RTW_HEADER_collision_between_two_robots_cap_host_h_
#define RTW_HEADER_collision_between_two_robots_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
#include "check_collision_with_bounding_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 8 ] ; check_collision_with_bounding_host_DataMapInfo_T child0 ;
check_collision_with_bounding_host_DataMapInfo_T child1 ;
check_collision_with_bounding_host_DataMapInfo_T child2 ;
check_collision_with_bounding_host_DataMapInfo_T child3 ;
check_collision_with_bounding_host_DataMapInfo_T child4 ;
check_collision_with_bounding_host_DataMapInfo_T child5 ;
check_collision_with_bounding_host_DataMapInfo_T child6 ;
check_collision_with_bounding_host_DataMapInfo_T child7 ; }
collision_between_two_robots_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void collision_between_two_robots_host_InitializeDataMapInfo (
collision_between_two_robots_host_DataMapInfo_T * dataMap , const char * path
) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
