#include "__cf_own_scout.h"
#ifndef RTW_HEADER_own_scout_types_h_
#define RTW_HEADER_own_scout_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct olf4lh4n1md_ olf4lh4n1md ; typedef struct ktlkho0fjr
j25xj2hqqj ;
#endif
