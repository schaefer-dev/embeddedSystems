#include "__cf_calculate_intersection.h"
#ifndef RTW_HEADER_calculate_intersection_capi_h_
#define RTW_HEADER_calculate_intersection_capi_h_
#include "calculate_intersection.h"
extern void calculate_intersection_InitializeDataMapInfo ( kvlk4iofhp * const
cagiuqgwmu , void * sysRanPtr , int contextTid ) ;
#endif
