#include "__cf_collide_between.h"
#ifndef RTW_HEADER_collide_between_cap_host_h_
#define RTW_HEADER_collide_between_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "collision_between_two_robots_capi_host.h"
#include "calculate_collision_effects_capi_host.h"
#include "calculate_collision_effects_capi_host.h"
#include "bounding_box_calc_capi_host.h"
#include "bounding_box_calc_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 5 ] ; collision_between_two_robots_host_DataMapInfo_T child0 ;
calculate_collision_effects_host_DataMapInfo_T child1 ;
calculate_collision_effects_host_DataMapInfo_T child2 ;
bounding_box_calc_host_DataMapInfo_T child3 ;
bounding_box_calc_host_DataMapInfo_T child4 ; }
collide_between_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void collide_between_host_InitializeDataMapInfo (
collide_between_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
