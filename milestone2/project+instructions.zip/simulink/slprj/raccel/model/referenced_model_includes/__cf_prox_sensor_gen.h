#ifndef CF_prox_sensor_gen_H__
#define CF_prox_sensor_gen_H__
#endif
