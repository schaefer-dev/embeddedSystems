#include "__cf_god.h"
#ifndef RTW_HEADER_god_h_
#define RTW_HEADER_god_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef god_COMMON_INCLUDES_
#define god_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "god_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "lights.h"
#include "generate_proximity_sensor_re0.h"
#include "differential_drive.h"
#include "collision.h"
#include "rtGetInf.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T iohxihe4qi ; real_T jfq5qamois ; real_T iba20de2ue ;
real_T jqzam3xknc ; real_T iamqx5i433 ; real_T cxudtzzbmt ; real_T nbmpsk1xcg
; real_T nyuxmd5peu ; real_T dbgz21mop5 ; real_T nwxjrlikuc ; real_T
hilrs5yfrm ; real_T jt204jjfrg ; real_T nujntxudug ; real_T p5jgvc5tth ;
real_T i5pfpztjck ; real_T agshqnwfmh ; real_T phqcpzrsjd ; real_T hmf2bd2kkt
; real_T b4ydiura24 ; real_T eddjt5urz5 ; real_T f1dodwbaql ; real_T
cgiwlqsmhn ; real_T i1e3umwp4q ; real_T m0cscgflay ; real_T ljnyui5bl2 ;
real_T mrjbxxrqv4 ; real_T oz2zvy1b53 ; real_T i0w0wdm0et ; real_T niaaojaurk
; real_T ldv3iunb1y ; real_T hrw3pmbjvl ; real_T mehqzqtteg ; real_T
pqvkpjso1b ; real_T irw3ndaxvr ; real_T p1moiebvka ; real_T fo5hgf4pgc ;
real_T kopvzzdwmf ; real_T d4edk4ryvn ; real_T mj2uo1upwd ; real_T lpqxmhfxln
; real_T bwbdp01cxz ; real_T g4eywisp5j ; real_T eeve0bjpev ; real_T
a5ujzl2q3d ; real_T eskipkzqwo ; real_T cybuxj3ifz ; real_T erpdpfilsw ;
real_T ksh0bqhxnq ; real_T j13oq2srkq ; real_T cbar2x00wq ; real_T lvaciiohvc
; real_T hiuggcavzc ; real_T kk15l1qktl ; real_T hgczpl00ip ; real_T
b5nbs02p03 ; real_T fqvvfgx05m ; real_T ked0todbc1 ; real_T p14gehad5x ;
real_T fig1orsrb5 ; real_T mg1jp0mwad ; real_T djqxcvfwog ; real_T mk21rb04co
; real_T hthuzoulsl ; real_T dmnwpbbi2l ; real_T jnlzovd54j ; real_T
igdo20ncl0 ; real_T pa0hedpjzr ; real_T iv15emwvgj ; real_T nugfzxekc0 ;
real_T cyvkzn550y ; real_T bzzhday5v3 ; real_T jc0b224cri ; real_T gjhe0xo21p
; real_T ceajl5pmnm ; real_T jar0fiuwyz ; real_T bjfw33qiqp ; real_T
brov1gxrso ; real_T k4ylgej4ok ; real_T ivkoezecve ; real_T c4w3s3llql ;
real_T ckuhz35pby ; real_T chxuft5ve0 ; real_T lkvwmpj5wi ; real_T ff2w2czsel
; real_T hggcr5tqw3 ; real_T p33bxbfizw ; real_T pf3bjws1kz ; real_T
c1g0yl1psz ; real_T f2xeryvldq ; real_T g4pfuemnaa ; real_T plvyrphyqv ;
real_T mlm031a1zj ; real_T pg0bgvzjru ; real_T p0f0fbgltp ; real_T iv5f5adkns
; real_T dk35p0ndv4 ; real_T g2z2mkvugx ; real_T nurydscgsa ; real_T
pfppgkw4dt ; real_T drqmcnmpzx ; real_T npwdy1s3me ; real_T a4o25acwus ;
real_T djhwmpnsua ; real_T ilrakxuygn ; real_T gk3n5f0phc ; real_T i4jbuhdzqi
; real_T lwktiw0o1a ; real_T goo21ctaub ; real_T ikdsen0ikd ; real_T
fzyriblubz ; real_T er2fudpa21 ; real_T ih1gasoai4 ; real_T f240jcnc4z ;
real_T kpmxnrvyzk ; real_T arwpr0xqdf ; real_T eabcvl2zat ; real_T kk3a3o20pp
; real_T j2sgkhuwrf ; real_T l1ywr420ax ; real_T icgs5zzfyi ; real_T
j2gvjuvnna ; real_T ez3vq2na0x ; real_T etcl1vdwm0 ; real_T dlb3f5a1t4 ;
real_T mq2nfq35ss ; real_T h0moc50zbt ; real_T egzld4rzgh ; real_T im40pjxgkl
; real_T bck24tthnn ; real_T n5ciapyy5v ; real_T che02etilj ; real_T
ok3u15bo3u ; real_T mhgwe1mbl3 ; real_T amztgqxl3b ; } lgjvpsubwu ; typedef
struct { real_T kqfke5c5qm ; real_T kgblpnhfwx ; real_T pyjkgod2oo ; real_T
h22t22phsc ; real_T adethabke0 ; real_T ih1izzstqp ; real_T kfosllcla1 ;
real_T akbxqs1ybe ; real_T iteywdvms4 ; real_T jcs2kt51mr ; real_T d3clr1lwwe
; real_T d43ycmbti3 ; real_T opd3hqwdpg ; real_T juvmmxpwdf ; real_T
gf3wyv2qny ; real_T fdjougz5b3 ; real_T oa3zz32nt0 ; real_T orp2nay3t1 ;
real_T iflkepo3rj ; real_T h1fflngtkf ; real_T bqfetl4a4d ; real_T jmk1thrh1q
; real_T mz1j55a1td ; real_T efuhhyjcp2 ; real_T lg0okoazw4 ; real_T
p0yimhmywh ; real_T fogb24eelk ; real_T gp0paogmj4 ; real_T kje0mdgvek ;
real_T mffnroepl1 ; real_T dom0mllde1 ; real_T j20n0woz5p ; real_T jhho4w5rsb
; real_T iofsyazssx ; real_T pllkejszrw ; real_T d3ecve4yfb ; real_T
mf5qmpvxju ; real_T iqfuk0jbxo ; real_T gzfxdvjk4j ; real_T nb5qy553gx ;
real_T ogvqpd5ebw ; real_T jjv11rj3dx ; real_T bmowbepvo4 ; real_T kn4rvyb3wi
; real_T l0i52gjvyu ; real_T i2ktyobj02 ; real_T d3lyydn5px ; real_T
m5anmskgil ; uint32_T eqnmw54dyg ; uint32_T mjk5rykzt0 ; uint32_T n0e0zetgro
; uint32_T plsn2hdvrh ; uint32_T n305c1avpc ; uint32_T avzpze1pqp ; uint32_T
kdtydqut3i ; uint32_T aam0oyrmzt ; uint32_T omauz2dsaq ; uint32_T dhl2c5aw0w
; uint32_T bd2nhdbf5o ; uint32_T ku1q5kiejy ; uint32_T dqk1wzoe0z ; int_T
g2svnlhocg ; int_T hybeearbxq ; int_T i3yr2qb2ov ; int_T pstl1lfj0a ; int_T
o2qsb3k2qp ; int_T hggj3xrxla ; int_T eo5osqnwkc ; int_T buyteipbw4 ; int_T
osqvjs1efa ; int_T iou1kqhpas ; int_T k5hejcwul2 ; int_T a3mjmjipzv ; int8_T
i1xjbwiva4 ; int8_T n3xtiu2zu1 ; int8_T mm5xoypsxh ; int8_T eafz5sgfpe ;
int8_T kgrzbukzvb ; int8_T b3zwil5njk ; int8_T f5zqw4kvpf ; int8_T fxbreqyncg
; int8_T nko1og1ced ; int8_T pwyf23yx3i ; int8_T bua1rxyvfu ; int8_T
dk4glnxiy1 ; int8_T a5eu5llzfw ; int8_T gv1tt5wh0f ; int8_T nadksmcz5d ;
int8_T bqiy2czdjb ; int8_T ko4nenwgqq ; int8_T bo4z1hby05 ; int8_T oavabakca0
; int8_T a2nkpbg5xh ; int8_T l1ot2neuqb ; int8_T lhxqwzllsx ; int8_T
cv0hto2q0c ; int8_T hj5pbfnixl ; boolean_T heqcqecz52 ; boolean_T owpew2s3ij
; boolean_T eur1spzcgc ; boolean_T ijaainzzsk ; boolean_T nawoi3p34p ;
boolean_T pwuryz5ivz ; boolean_T nww1pq0322 ; boolean_T f2g12x5zn5 ;
boolean_T aebi2rosha ; boolean_T ifcuj001u4 ; boolean_T ldmcsqvrnl ;
boolean_T nmgb45zbmm ; boolean_T fypdf3s3pk ; boolean_T isjep3wvqe ;
boolean_T af5sjmh1mk ; boolean_T ejkzkggnbh ; boolean_T cmo5foryu4 ;
boolean_T ke2hbn4dbl ; boolean_T hyktzirepv ; boolean_T aq0cpvqv3c ;
boolean_T beqvxjpio2 ; boolean_T eq1ezegy50 ; boolean_T jlnw51atyf ;
boolean_T opdza1wpcq ; boolean_T icn3buuwvg ; boolean_T bipdjysod4 ;
boolean_T avgrwzcbtm ; boolean_T puazuzbphf ; boolean_T mhuesu2sqp ;
boolean_T axhhgpmkep ; boolean_T irighmc2i0 ; boolean_T o3002zpznn ;
boolean_T hjzr5cc2fj ; boolean_T eflww0ubtv ; boolean_T ome5cyrezs ;
boolean_T jvnmqdpl5e ; boolean_T gdk225mlhl ; boolean_T laujhud0ux ;
boolean_T avcazrts4r ; boolean_T ngs5thg4sz ; boolean_T b0meyql0fc ;
boolean_T nguam4iet2 ; boolean_T lajk21ioe5 ; boolean_T ej512gnelx ;
boolean_T czhisyt20r ; boolean_T hhri5eohqd ; boolean_T lk5agqqmju ;
boolean_T bicvbtswnd ; boolean_T ordnui1ynl ; fvnxaixuz2i fasufuzqey ;
ceyldc12a32 hgvhryixdd ; ceyldc12a32 m4skasgend ; ceyldc12a32 lcjgoqinlj ;
ceyldc12a32 bxlai03yuo ; i5cbqmfwwz0 a5xxplvd1e ; ni4fygtiycb jbt0cwwbd2 ; }
nllisfxscj ; typedef struct { e1c2zrj1nx eltvkzj04z ; itsu1yon4s mymjn30rjb ;
itsu1yon4s av24ccidll ; itsu1yon4s ez52li0gu0 ; itsu1yon4s odx0rth3ok ; }
hxbik2dpvc ; typedef struct { gyxtjka3et eltvkzj04z ; nes2y3gbqk mymjn30rjb ;
nes2y3gbqk av24ccidll ; nes2y3gbqk ez52li0gu0 ; nes2y3gbqk odx0rth3ok ; }
e1bl4ewqak ; typedef struct { bi2e23yu4p eltvkzj04z ; aslryh0fym mymjn30rjb ;
aslryh0fym av24ccidll ; aslryh0fym ez52li0gu0 ; aslryh0fym odx0rth3ok ; }
bzj52dkamz ; typedef struct { jqsqsjzuph eltvkzj04z ; devq5mhm54 mymjn30rjb ;
devq5mhm54 av24ccidll ; devq5mhm54 ez52li0gu0 ; devq5mhm54 odx0rth3ok ; }
fhtpdw1g0r ; typedef struct { real_T in2k0gtf04 ; real_T bst5koqgfc ; real_T
hlicfs5yov ; fd2rr2yo0s lyxego5l3x ; real_T jjgi5w0dwq ; real_T ddiyomhuot ;
real_T h51xevbtnt ; real_T fukwl35nnu ; dgl2ktxaof jp3rsaieqn ; real_T
bpt505opzm ; real_T ebu2bfxv1u ; real_T otlnvzxner ; real_T bh3awn13ub ;
dgl2ktxaof hmkhfw1wv1 ; dgl2ktxaof ifufare4st ; dgl2ktxaof dcqrgzete1 ;
dq3jajg0ti ez2lepiafx ; real_T j32qjxurpq ; real_T c4wkery5xk ; real_T
ls1ympkqp0 ; real_T eq0fnnci0u ; real_T lcmgyjbbzp ; real_T ofjyaqzfo3 ;
real_T gzfoj01vsl ; real_T cljonlyrm2 ; real_T o3tpxyuucj ; real_T fokcggcal0
; real_T ne1h5nnuu3 ; real_T ffcct3zxxm ; real_T fuvafipdvk ; real_T
ijffnm0qk2 ; real_T a53ia44jlo ; real_T a04xylhdwb ; real_T nu03cvgper ;
real_T bavifievnl ; real_T d3h2gbtjey ; real_T fk0lxbhu4j ; real_T ibrchhtmz3
; real_T a204tsch4a ; real_T dld1youtnn ; real_T ld40bgcj3u ; real_T
jx312hcchb ; real_T m0ait2tvdv ; real_T nmmokctyyu ; real_T mg0kfoafbg ;
real_T i2wdjybfib ; real_T golwxglm2x ; real_T df30mpaunv ; real_T of0cs0xw33
; real_T lbkuddrsok ; real_T bmxpqglmvb ; real_T pmkksla314 ; real_T
mkfzpmwkmu ; real_T hunv2en4cm ; real_T fdnuyg0lsx ; } mkb4sv52uy ; struct
mo2beyb4gil_ { real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6
; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ;
real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T
P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ;
real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T
P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ;
real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T
P_45 ; real_T P_46 ; real_T P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ;
real_T P_51 ; real_T P_52 ; real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T
P_56 ; real_T P_57 ; real_T P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ;
real_T P_62 ; real_T P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T
P_67 ; real_T P_68 ; real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ;
real_T P_73 ; real_T P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T
P_78 ; real_T P_79 ; real_T P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ;
real_T P_84 ; real_T P_85 ; real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T
P_89 ; real_T P_90 ; real_T P_91 ; real_T P_92 ; real_T P_93 ; real_T P_94 ;
real_T P_95 ; real_T P_96 ; real_T P_97 ; real_T P_98 ; real_T P_99 ; real_T
P_100 ; real_T P_101 ; real_T P_102 ; real_T P_103 ; real_T P_104 ; real_T
P_105 ; real_T P_106 ; real_T P_107 ; real_T P_108 ; real_T P_109 ; real_T
P_110 ; real_T P_111 ; real_T P_112 ; real_T P_113 ; real_T P_114 ; real_T
P_115 ; real_T P_116 ; real_T P_117 ; real_T P_118 ; real_T P_119 ; real_T
P_120 ; real_T P_121 ; real_T P_122 ; real_T P_123 ; real_T P_124 ; real_T
P_125 ; real_T P_126 ; real_T P_127 ; real_T P_128 ; real_T P_129 ; real_T
P_130 ; real_T P_131 ; real_T P_132 ; real_T P_133 ; real_T P_134 ; real_T
P_135 ; real_T P_136 ; real_T P_137 ; real_T P_138 ; real_T P_139 ; real_T
P_140 ; real_T P_141 ; real_T P_142 ; real_T P_143 ; real_T P_144 ; real_T
P_145 ; real_T P_146 ; real_T P_147 ; real_T P_148 ; real_T P_149 ; real_T
P_150 ; real_T P_151 ; real_T P_152 ; real_T P_153 ; real_T P_154 ; real_T
P_155 ; real_T P_156 ; real_T P_157 ; real_T P_158 ; real_T P_159 ; real_T
P_160 ; real_T P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T
P_165 ; real_T P_166 ; real_T P_167 ; real_T P_168 ; real_T P_169 ; real_T
P_170 ; real_T P_171 ; real_T P_172 ; real_T P_173 ; real_T P_174 ; real_T
P_175 ; real_T P_176 ; real_T P_177 ; real_T P_178 ; real_T P_179 ; real_T
P_180 ; real_T P_181 ; real_T P_182 ; real_T P_183 ; real_T P_184 ; real_T
P_185 ; real_T P_186 ; real_T P_187 ; real_T P_188 ; real_T P_189 ; real_T
P_190 ; real_T P_191 ; real_T P_192 ; real_T P_193 ; real_T P_194 ; real_T
P_195 ; real_T P_196 ; real_T P_197 ; real_T P_198 ; real_T P_199 ; real_T
P_200 ; real_T P_201 ; real_T P_202 ; real_T P_203 ; real_T P_204 ; real_T
P_205 ; real_T P_206 ; real_T P_207 ; real_T P_208 ; real_T P_209 ; real_T
P_210 ; real_T P_211 ; real_T P_212 ; real_T P_213 ; real_T P_214 ; real_T
P_215 ; real_T P_216 ; real_T P_217 ; real_T P_218 ; real_T P_219 ; real_T
P_220 ; real_T P_221 ; real_T P_222 ; real_T P_223 ; real_T P_224 ; real_T
P_225 ; real_T P_226 ; real_T P_227 ; real_T P_228 ; real_T P_229 ; real_T
P_230 ; real_T P_231 ; real_T P_232 ; real_T P_233 ; real_T P_234 ; real_T
P_235 ; real_T P_236 ; real_T P_237 ; real_T P_238 ; real_T P_239 ; real_T
P_240 ; real_T P_241 ; real_T P_242 ; real_T P_243 ; real_T P_244 ; real_T
P_245 ; real_T P_246 ; real_T P_247 ; real_T P_248 ; real_T P_249 ; real_T
P_250 ; real_T P_251 ; real_T P_252 ; real_T P_253 ; real_T P_254 ; real_T
P_255 ; real_T P_256 ; real_T P_257 ; real_T P_258 ; real_T P_259 ; real_T
P_260 ; real_T P_261 ; real_T P_262 ; real_T P_263 ; real_T P_264 ; real_T
P_265 ; real_T P_266 ; real_T P_267 ; real_T P_268 ; real_T P_269 ; real_T
P_270 ; real_T P_271 ; real_T P_272 ; real_T P_273 ; real_T P_274 ; real_T
P_275 ; real_T P_276 ; real_T P_277 ; real_T P_278 ; real_T P_279 ; real_T
P_280 ; real_T P_281 ; real_T P_282 ; real_T P_283 ; real_T P_284 ; real_T
P_285 ; real_T P_286 ; real_T P_287 ; real_T P_288 ; real_T P_289 ; real_T
P_290 ; real_T P_291 ; real_T P_292 ; real_T P_293 ; real_T P_294 ; real_T
P_295 ; real_T P_296 ; real_T P_297 ; real_T P_298 ; real_T P_299 ; real_T
P_300 ; real_T P_301 ; real_T P_302 ; real_T P_303 ; real_T P_304 ; real_T
P_305 ; real_T P_306 ; real_T P_307 ; real_T P_308 ; real_T P_309 ; real_T
P_310 ; real_T P_311 ; real_T P_312 ; real_T P_313 ; real_T P_314 ; real_T
P_315 ; real_T P_316 ; real_T P_317 ; real_T P_318 ; real_T P_319 ; real_T
P_320 ; real_T P_321 ; real_T P_322 ; real_T P_323 ; real_T P_324 ; real_T
P_325 ; real_T P_326 ; real_T P_327 ; real_T P_328 ; } ; struct iwsjsnvbha {
struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ;
real_T mr_nonContSig1 [ 1 ] ; real_T mr_nonContSig2 [ 1 ] ; real_T
mr_nonContSig3 [ 1 ] ; real_T mr_nonContSig4 [ 1 ] ; real_T mr_nonContSig5 [
1 ] ; real_T mr_nonContSig6 [ 1 ] ; real_T mr_nonContSig7 [ 1 ] ; real_T
mr_nonContSig8 [ 1 ] ; real_T mr_nonContSig9 [ 1 ] ; real_T mr_nonContSig10 [
1 ] ; real_T mr_nonContSig11 [ 1 ] ; real_T mr_nonContSig12 [ 1 ] ; real_T
mr_nonContSig13 [ 1 ] ; real_T mr_nonContSig14 [ 1 ] ; real_T mr_nonContSig15
[ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo nonContDerivSignal [ 16
] ; const rtTimingBridge * timingBridge ; struct { rtwCAPI_ModelMappingInfo
mmi ; rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ;
rtwCAPI_ModelMappingInfo * childMMI [ 7 ] ; sysRanDType * systemRan [ 33 ] ;
int_T systemTid [ 33 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf5 ;
uint8_T rtmDbBufWriteBuf5 ; boolean_T rtmDbBufLastBufWr5 ; real_T
rtmDbBufContT5 [ 2 ] ; int_T mdlref_GlobalTID [ 6 ] ; } Timing ; } ; typedef
struct { lgjvpsubwu rtb ; nllisfxscj rtdw ; edxhad3kdx rtm ; } nfown5ry3ad ;
extern real_T rtP_collision_detection_distance ; extern real_T rtP_push_force
; extern void e3e3a5fnaz ( real_T * nhdd2vkb44 , real_T * lg5gx4f3ws ,
SimStruct * _mdlRefSfcnS , ssNonContDerivSigFeedingOutports * *
mr_nonContOutputArray , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , int_T mdlref_TID3 , int_T mdlref_TID4 , int_T mdlref_TID5 ,
edxhad3kdx * const acvxkx2edu , lgjvpsubwu * localB , nllisfxscj * localDW ,
hxbik2dpvc * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void mr_god_MdlInfoRegFcn (
SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern
mxArray * mr_god_GetDWork ( const nfown5ry3ad * mdlrefDW ) ; extern void
mr_god_SetDWork ( nfown5ry3ad * mdlrefDW , const mxArray * ssDW ) ; extern
void mr_god_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_god_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * god_GetCAPIStaticMap ( void ) ; extern void
pykdmtgjty ( lgjvpsubwu * localB , nllisfxscj * localDW , hxbik2dpvc * localX
) ; extern void bvh4ummiv1 ( nllisfxscj * localDW , hxbik2dpvc * localX ) ;
extern void pxqhp1clgc ( nllisfxscj * localDW ) ; extern void d1aa5vzq1u (
nllisfxscj * localDW , e1bl4ewqak * localXdot ) ; extern void cyjocqr4y5 (
edxhad3kdx * const acvxkx2edu , const real_T * krlupghufn , real_T *
b5qtpqzvnf , real_T * dbgmxrlstz , real_T * jvq1uviptm , real_T * lcuynsbk14
, real_T * ez4uzajf0q , real_T * mcrec2pmlp , real_T * pudj1lt5kq , real_T *
bji2e3shdv , lgjvpsubwu * localB , nllisfxscj * localDW , mkb4sv52uy *
localZCSV ) ; extern void dsbvh1kmob ( nllisfxscj * localDW ) ; extern void
iscjv5cqys ( edxhad3kdx * const acvxkx2edu , const real_T * nghrwwzx4v ,
const real_T * iqvyjoagah , const real_T * gwwu3ky5it , const real_T *
aywv55bxlp , const real_T * cs4w1axlw5 , const real_T * krqbvulio1 , const
real_T * lrdxmu50ql , const real_T * hjmtrsu1eh , real_T * b5qtpqzvnf ,
real_T * dbgmxrlstz , real_T * jvq1uviptm , real_T * lcuynsbk14 , real_T *
ez4uzajf0q , real_T * mcrec2pmlp , real_T * pudj1lt5kq , real_T * bji2e3shdv
, lgjvpsubwu * localB , nllisfxscj * localDW ) ; extern void iscjv5cqysTID5 (
void ) ; extern void god ( edxhad3kdx * const acvxkx2edu , const real_T *
poxvsdybt4 , const real_T * adrm2ifisy , const real_T * mb1mvzwiwf , const
real_T * hr1k5xhs1z , const real_T * pehauh5nrk , const real_T * aso1garixm ,
const real_T * okzoinhk3w , const real_T * krlupghufn , real_T * nhdd2vkb44 ,
real_T * lg5gx4f3ws , real_T * b5qtpqzvnf , real_T * dbgmxrlstz , real_T *
ibf2ffwxzg , real_T * jvq1uviptm , real_T * lcuynsbk14 , real_T * hxfitxbzwp
, real_T * ez4uzajf0q , real_T * mcrec2pmlp , real_T * l4lvc21jo0 , real_T *
pudj1lt5kq , real_T * bji2e3shdv , real_T * k2riaw25fu , real_T * ddyza5l4tn
, real_T * ghzsotqsmb , real_T * dlmyhkv0er , real_T * ci2p2megp5 , real_T *
kq35po3psq , real_T * htdzxhyroh , real_T * isu1cub0io , lgjvpsubwu * localB
, nllisfxscj * localDW , hxbik2dpvc * localX ) ; extern void godTID5 (
nllisfxscj * localDW ) ; extern void ladlaj0sg3 ( nllisfxscj * localDW ,
edxhad3kdx * const acvxkx2edu ) ;
#endif
