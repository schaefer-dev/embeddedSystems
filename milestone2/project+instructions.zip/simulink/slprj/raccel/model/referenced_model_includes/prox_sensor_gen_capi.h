#include "__cf_prox_sensor_gen.h"
#ifndef RTW_HEADER_prox_sensor_gen_capi_h_
#define RTW_HEADER_prox_sensor_gen_capi_h_
#include "prox_sensor_gen.h"
extern void prox_sensor_gen_InitializeDataMapInfo ( d2rk1h1tve * const
jhvh3r1toz , kwarn23huf * localDW , void * sysRanPtr , int contextTid ) ;
#endif
