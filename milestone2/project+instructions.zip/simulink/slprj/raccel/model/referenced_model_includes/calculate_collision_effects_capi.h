#include "__cf_calculate_collision_effects.h"
#ifndef RTW_HEADER_calculate_collision_effects_capi_h_
#define RTW_HEADER_calculate_collision_effects_capi_h_
#include "calculate_collision_effects.h"
extern void calculate_collision_effects_InitializeDataMapInfo ( hy0y0nvofh *
const jjwe0heymi , kbuym0zbtf * localDW , void * sysRanPtr , int contextTid )
;
#endif
