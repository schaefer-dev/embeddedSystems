#include "__cf_lights.h"
#ifndef RTW_HEADER_lights_types_h_
#define RTW_HEADER_lights_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct brh0zkskzdo_ brh0zkskzdo ; typedef struct ocfq1uquo5
ieoalh2akm ;
#endif
