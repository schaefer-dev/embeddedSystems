#include "__cf_collision.h"
#ifndef RTW_HEADER_collision_capi_h_
#define RTW_HEADER_collision_capi_h_
#include "collision.h"
extern void collision_InitializeDataMapInfo ( ishptvov2y * const dzwbd2guxb ,
mhv1pvkcyj * localDW , void * sysRanPtr , int contextTid ) ;
#endif
