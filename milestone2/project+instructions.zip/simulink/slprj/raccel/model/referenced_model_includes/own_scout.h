#include "__cf_own_scout.h"
#ifndef RTW_HEADER_own_scout_h_
#define RTW_HEADER_own_scout_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef own_scout_COMMON_INCLUDES_
#define own_scout_COMMON_INCLUDES_
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "own_scout_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "theta_correction.h"
#include "differential_drive.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
typedef struct { real_T dabaw3klmp ; real_T nnf1fsthzq ; real_T dc1ins3rvt ;
real_T mufqsd4rft ; real_T fs3qnkqgef ; real_T dexbhqjivw ; real_T nhpznqlx54
; real_T oxt0nbpdmx ; real_T kgk3jgl4te ; real_T p2jhthsjmh ; real_T
izwrv2ya3q ; real_T cwpxcfr4ob ; real_T mdmkwabmnb ; real_T froq4tohde ;
real_T fiee35veim ; real_T eizckacq3h ; real_T hwqc3xfr5g ; real_T gyd2zgb3d5
; real_T mgsn1rc1hl ; real_T eory0iknxu ; real_T hxfw1kstut ; real_T
d22drkhpni ; real_T iamrparvp2 ; real_T gvuhqjjo1a ; real_T kxlotlmlzy ;
real_T dmlpiyuene ; real_T m030joehpv ; real_T fhc5udsgir ; boolean_T
ef2lgof2hh ; boolean_T eec3yr04cl ; } ekmt14db55 ; typedef struct { real_T
j4oymqam2l ; real_T gqcbjrrsyt ; real_T cana5bcqba ; real_T bddkrg53y3 ;
real_T e0fj1tnpil ; struct { void * AQHandles ; void * SlioLTF ; } m3xireysjb
; struct { void * AQHandles ; void * SlioLTF ; } f443juzwco ; struct { void *
AQHandles ; void * SlioLTF ; } mmb4l4igka ; struct { void * AQHandles ; void
* SlioLTF ; } a5v4zdecfs ; int_T esvddy2arq ; int_T fqsvofpt12 ; int_T
lqebwon3cm ; int_T lbteaqvyhv ; int8_T bs43mjr55f ; int8_T jtatplgu42 ;
int8_T a0zsehw1pk ; boolean_T ibanculnw1 ; boolean_T euz4m3ni42 ; boolean_T
drekyng45b ; boolean_T jd51x5pxam ; boolean_T jgn52bmj3s ; boolean_T
ciofmybhk0 ; boolean_T eyezxjnjvt ; boolean_T i340piln2p ; boolean_T
alnldskyzv ; boolean_T p3ovwdcarp ; boolean_T fqa3lmzhad ; boolean_T
pj025wsjww ; boolean_T iml1uz2ruy ; boolean_T ajto5ov42y ; boolean_T
esbanwaomd ; boolean_T a2yqiexdgq ; boolean_T mlkpygv5xa ; boolean_T
e5zkxsew55 ; boolean_T gvrbdyqoc2 ; boolean_T ldfb5qs2le ; ceyldc12a32
ee5lifcqe4 ; kevw5qu2wxg pjfv5s1j12 ; } ogth33vryx ; typedef struct {
itsu1yon4s nen3ri3wne ; } pguwt3obif ; typedef struct { nes2y3gbqk nen3ri3wne
; } p0jxnzcxrr ; typedef struct { aslryh0fym nen3ri3wne ; } ltkhnhhpgo ;
typedef struct { devq5mhm54 nen3ri3wne ; } ftjpwe0gaz ; typedef struct {
real_T gsboltozjx ; real_T aljo4iuwwa ; dgl2ktxaof bcqwrm234v ; real_T
odhs10rn4y ; real_T igjspb4ral ; real_T fhs1hbug2q ; real_T h3pc424im4 ;
real_T ny05jpdbpa ; real_T oceert4hoz ; real_T jlywyer3v3 ; kiif3lkxev
p32muzfpjv ; real_T gimresg5lm ; real_T o0gd1h5j0e ; real_T o0uzrj40zg ;
real_T atao1pmfsd ; real_T nucpfabypm ; real_T ntlj1xdpxq ; real_T dkore1ysg0
; real_T jkyigh1c0e ; real_T jgrmh201qa ; real_T apwja1cebq ; real_T
p5yu5ncjy0 ; } a5t0oyxt24 ; struct olf4lh4n1md_ { real_T P_0 ; real_T P_1 ;
real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ;
real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T
P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ;
real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T
P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T P_29 ;
real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ; real_T
P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ;
real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T
P_46 ; real_T P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ;
real_T P_52 ; real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 ; real_T
P_57 ; real_T P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ;
real_T P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T
P_68 ; real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ;
real_T P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ;
boolean_T P_79 ; boolean_T P_80 ; } ; struct ktlkho0fjr { struct
SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ; real_T
mr_nonContSig1 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 2 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; rtwCAPI_ModelMappingInfo * childMMI [ 2 ] ; sysRanDType
* systemRan [ 14 ] ; int_T systemTid [ 14 ] ; } DataMapInfo ; struct {
uint8_T rtmDbBufReadBuf2 ; uint8_T rtmDbBufWriteBuf2 ; boolean_T
rtmDbBufLastBufWr2 ; real_T rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3
] ; } Timing ; } ; typedef struct { ekmt14db55 rtb ; ogth33vryx rtdw ;
j25xj2hqqj rtm ; } l22alrksvl0 ; extern void kdqiwkuqlf ( SimStruct *
_mdlRefSfcnS , ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray ,
int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , j25xj2hqqj *
const dwr00qhtvf , ekmt14db55 * localB , ogth33vryx * localDW , pguwt3obif *
localX , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_own_scout_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_own_scout_GetDWork ( const l22alrksvl0 * mdlrefDW ) ; extern void
mr_own_scout_SetDWork ( l22alrksvl0 * mdlrefDW , const mxArray * ssDW ) ;
extern void mr_own_scout_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_own_scout_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * own_scout_GetCAPIStaticMap ( void ) ; extern
void k04aywo4gs ( ekmt14db55 * localB , ogth33vryx * localDW , pguwt3obif *
localX ) ; extern void mtfda24d2j ( ogth33vryx * localDW , pguwt3obif *
localX ) ; extern void f0ebgo1peg ( j25xj2hqqj * const dwr00qhtvf ,
ogth33vryx * localDW ) ; extern void izvdacwtkx ( ogth33vryx * localDW ,
p0jxnzcxrr * localXdot ) ; extern void muv4vd0ayl ( const real_T * jpui2t2o1s
, const real_T * eetvplr0ui , const real_T * bdy5puxjnf , const real_T *
lrghi2nxrj , const real_T * g450qvvm30 , ekmt14db55 * localB , ogth33vryx *
localDW , a5t0oyxt24 * localZCSV ) ; extern void i0ijkps34b ( ogth33vryx *
localDW ) ; extern void k2dohzhyz4 ( j25xj2hqqj * const dwr00qhtvf , real_T *
fva1tycsid , real_T * mfq14lxqpc , ekmt14db55 * localB , ogth33vryx * localDW
) ; extern void k2dohzhyz4TID2 ( void ) ; extern void own_scout ( j25xj2hqqj
* const dwr00qhtvf , const boolean_T * ewomluuolp , const real_T * hj3n33nscd
, const real_T * fwp4mb3rvp , const real_T * k3mfapsrcl , const real_T *
gp4edmbx0c , const real_T * kmlzicqoa1 , const real_T * jpui2t2o1s , const
real_T * eetvplr0ui , const real_T * bdy5puxjnf , const real_T * lrghi2nxrj ,
const real_T * g450qvvm30 , real_T * n1ddte1ajz , real_T * cxl0g2qocp ,
real_T * mus5seedgl , real_T * fva1tycsid , real_T * mfq14lxqpc , real_T *
fymhlk4gtk , real_T * b4vpfm3ekl , ekmt14db55 * localB , ogth33vryx * localDW
, pguwt3obif * localX ) ; extern void own_scoutTID2 ( ekmt14db55 * localB ,
ogth33vryx * localDW ) ; extern void k1tvojfoe3 ( j25xj2hqqj * const
dwr00qhtvf , ogth33vryx * localDW ) ;
#endif
