#include "__cf_bounding_box_calc.h"
#ifndef RTW_HEADER_bounding_box_calc_h_
#define RTW_HEADER_bounding_box_calc_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef bounding_box_calc_COMMON_INCLUDES_
#define bounding_box_calc_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "bounding_box_calc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
struct e2klae1qjai_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; } ; struct
gn2abovwjx { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 1 ] ; } Timing ; } ;
typedef struct { nikjwnz44k rtm ; } nqg40qhj3f4 ; extern void bf1z3ni0yc (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , nikjwnz44k * const fk3v0e2etj
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ;
extern void mr_bounding_box_calc_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_bounding_box_calc_GetDWork ( const nqg40qhj3f4 * mdlrefDW ) ; extern void
mr_bounding_box_calc_SetDWork ( nqg40qhj3f4 * mdlrefDW , const mxArray * ssDW
) ; extern void mr_bounding_box_calc_RegisterSimStateChecksum ( SimStruct * S
) ; extern mxArray * mr_bounding_box_calc_GetSimStateDisallowedBlocks ( ) ;
extern const rtwCAPI_ModelMappingStaticInfo *
bounding_box_calc_GetCAPIStaticMap ( void ) ; extern void bounding_box_calc (
const real_T * jjbxzcy0lp , const real_T * bbfanegn12 , const real_T *
d3de04htl3 , const real_T * maa0g5htwv , const real_T * bnsoia3t3n , real_T
nsr34uzau5 [ 2 ] , real_T fecvxcduov [ 2 ] , real_T dwf1n3odio [ 2 ] , real_T
jq2pu4fofk [ 2 ] ) ; extern void h2gdpdmrk4 ( nikjwnz44k * const fk3v0e2etj )
;
#endif
