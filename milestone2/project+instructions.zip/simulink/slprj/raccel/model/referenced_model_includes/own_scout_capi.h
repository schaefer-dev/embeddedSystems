#include "__cf_own_scout.h"
#ifndef RTW_HEADER_own_scout_capi_h_
#define RTW_HEADER_own_scout_capi_h_
#include "own_scout.h"
extern void own_scout_InitializeDataMapInfo ( j25xj2hqqj * const dwr00qhtvf ,
ogth33vryx * localDW , void * sysRanPtr , int contextTid ) ;
#endif
