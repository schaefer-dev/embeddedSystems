#include "__cf_vector_rotation.h"
#ifndef RTW_HEADER_vector_rotation_capi_h_
#define RTW_HEADER_vector_rotation_capi_h_
#include "vector_rotation.h"
extern void vector_rotation_InitializeDataMapInfo ( f2yyvn3djo * const
exrnoff1k1 , void * sysRanPtr , int contextTid ) ;
#endif
