#include "__cf_bounding_box_calc.h"
#ifndef RTW_HEADER_bounding_box_calc_capi_h_
#define RTW_HEADER_bounding_box_calc_capi_h_
#include "bounding_box_calc.h"
extern void bounding_box_calc_InitializeDataMapInfo ( nikjwnz44k * const
fk3v0e2etj , void * sysRanPtr , int contextTid ) ;
#endif
