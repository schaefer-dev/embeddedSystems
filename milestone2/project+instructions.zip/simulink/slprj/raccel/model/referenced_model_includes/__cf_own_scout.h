#ifndef CF_own_scout_H__
#define CF_own_scout_H__
#endif
