#include "__cf_calculate_intersection.h"
#ifndef RTW_HEADER_calculate_intersection_h_
#define RTW_HEADER_calculate_intersection_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef calculate_intersection_COMMON_INCLUDES_
#define calculate_intersection_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "calculate_intersection_types.h"
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
struct ka2ttq1dcfe_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; real_T P_5 ; } ; struct bvctzapre3 { struct SimStruct_tag *
_mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; sysRanDType *
systemRan [ 2 ] ; int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T
mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef struct { kvlk4iofhp rtm ; }
l20fhy3pjtc ; extern void gvgkyoxgcv ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , kvlk4iofhp * const cagiuqgwmu , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern
void mr_calculate_intersection_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_calculate_intersection_GetDWork ( const l20fhy3pjtc * mdlrefDW ) ; extern
void mr_calculate_intersection_SetDWork ( l20fhy3pjtc * mdlrefDW , const
mxArray * ssDW ) ; extern void
mr_calculate_intersection_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_calculate_intersection_GetSimStateDisallowedBlocks ( ) ; extern
const rtwCAPI_ModelMappingStaticInfo *
calculate_intersection_GetCAPIStaticMap ( void ) ; extern void
calculate_intersection ( const real_T oxhmadjrqw [ 2 ] , const real_T
d3a5jqxhqp [ 2 ] , const real_T evdksc4bkv [ 2 ] , const real_T lpcds1hdsi [
2 ] , real_T * aseknauz5g , boolean_T * jwpzptwbpe ) ; extern void
calculate_intersectionTID1 ( void ) ; extern void copojq4112 ( kvlk4iofhp *
const cagiuqgwmu ) ;
#endif
