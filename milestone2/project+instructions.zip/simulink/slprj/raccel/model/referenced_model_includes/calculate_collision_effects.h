#include "__cf_calculate_collision_effects.h"
#ifndef RTW_HEADER_calculate_collision_effects_h_
#define RTW_HEADER_calculate_collision_effects_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef calculate_collision_effects_COMMON_INCLUDES_
#define calculate_collision_effects_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "calculate_collision_effects_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T p2cp4vwpta ; } cymsckxckb ; typedef struct {
boolean_T e0hjvhmbxz ; } kbuym0zbtf ; typedef struct { real_T f1jloo2g2v ; }
mwunqph4vq ; struct g1j02kmnez5_ { real_T P_2 ; real_T P_3 ; real_T P_4 ;
real_T P_5 ; } ; struct gg1ppi30jj { struct SimStruct_tag * _mdlRefSfcnS ;
struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ;
typedef struct { cymsckxckb rtb ; kbuym0zbtf rtdw ; hy0y0nvofh rtm ; }
hsv52bpfnq0 ; extern real_T rtP_collision_detection_distance ; extern real_T
rtP_push_force ; extern void l0cizwtudm ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , hy0y0nvofh * const jjwe0heymi , cymsckxckb
* localB , kbuym0zbtf * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_calculate_collision_effects_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS ,
char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_calculate_collision_effects_GetDWork ( const hsv52bpfnq0 * mdlrefDW ) ;
extern void mr_calculate_collision_effects_SetDWork ( hsv52bpfnq0 * mdlrefDW
, const mxArray * ssDW ) ; extern void
mr_calculate_collision_effects_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_calculate_collision_effects_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo *
calculate_collision_effects_GetCAPIStaticMap ( void ) ; extern void
bgeo5i3ygf ( cymsckxckb * localB , mwunqph4vq * localZCSV ) ; extern void
calculate_collision_effects ( hy0y0nvofh * const jjwe0heymi , const real_T *
occmobaoq0 , const real_T * heqmcl4fj5 , const real_T * fdivlf50sk , const
real_T * kyulaudqfi , real_T * feiau1mbpe , real_T * p2gaq3opsn , cymsckxckb
* localB , kbuym0zbtf * localDW ) ; extern void
calculate_collision_effectsTID1 ( void ) ; extern void izntqovil1 (
hy0y0nvofh * const jjwe0heymi ) ;
#endif
