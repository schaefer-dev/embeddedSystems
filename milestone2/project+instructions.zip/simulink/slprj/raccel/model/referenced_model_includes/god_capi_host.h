#include "__cf_god.h"
#ifndef RTW_HEADER_god_cap_host_h_
#define RTW_HEADER_god_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "lights_capi_host.h"
#include "differential_drive_capi_host.h"
#include "differential_drive_capi_host.h"
#include "differential_drive_capi_host.h"
#include "differential_drive_capi_host.h"
#include "collision_capi_host.h"
#include "generate_proximity_sensor_re0_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 7 ] ; lights_host_DataMapInfo_T child0 ;
differential_drive_host_DataMapInfo_T child1 ;
differential_drive_host_DataMapInfo_T child2 ;
differential_drive_host_DataMapInfo_T child3 ;
differential_drive_host_DataMapInfo_T child4 ; collision_host_DataMapInfo_T
child5 ; generate_proximity_sensor_re0_host_DataMapInfo_T child6 ; }
god_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void god_host_InitializeDataMapInfo ( god_host_DataMapInfo_T * dataMap ,
const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
