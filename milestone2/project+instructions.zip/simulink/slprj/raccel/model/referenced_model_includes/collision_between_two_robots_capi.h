#include "__cf_collision_between_two_robots.h"
#ifndef RTW_HEADER_collision_between_two_robots_capi_h_
#define RTW_HEADER_collision_between_two_robots_capi_h_
#include "collision_between_two_robots.h"
extern void collision_between_two_robots_InitializeDataMapInfo ( gvmzk0fl4d *
const cle1hx0fby , hmfgq0pduk * localDW , void * sysRanPtr , int contextTid )
;
#endif
