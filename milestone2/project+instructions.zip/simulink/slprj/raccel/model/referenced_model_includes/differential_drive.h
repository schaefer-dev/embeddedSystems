#include "__cf_differential_drive.h"
#ifndef RTW_HEADER_differential_drive_h_
#define RTW_HEADER_differential_drive_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef differential_drive_COMMON_INCLUDES_
#define differential_drive_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "differential_drive_types.h"
#include "multiword_types.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T azrkzx4crj ; real_T os331bzduo ; real_T hvxgoycklj ;
real_T gizsjmodix ; real_T nwadgopbjt ; real_T gge3jipdg0 ; real_T egjk0w3cbn
; } nngfmk01le ; typedef struct { real_T ckrr0jnvvu ; real_T a4tu5mgaff ;
real_T mhruw5rpf2 ; } itsu1yon4s ; typedef struct { real_T ckrr0jnvvu ;
real_T a4tu5mgaff ; real_T mhruw5rpf2 ; } nes2y3gbqk ; typedef struct {
boolean_T ckrr0jnvvu ; boolean_T a4tu5mgaff ; boolean_T mhruw5rpf2 ; }
aslryh0fym ; typedef struct { real_T ckrr0jnvvu ; real_T a4tu5mgaff ; real_T
mhruw5rpf2 ; } devq5mhm54 ; typedef struct { real_T nzo1nwwdie ; real_T
l5tjjo4ube ; real_T d2srs4xkue ; } dgl2ktxaof ; typedef struct { ZCSigState
e50ylcfiu0 ; ZCSigState fyppxoio4p ; ZCSigState k52pxx0anh ; } jm42yhk5t3 ;
struct ebuxoc15ksn_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ;
real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T
P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; } ; struct ps0zay3oej {
struct SimStruct_tag * _mdlRefSfcnS ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
3 ] ; int32_T * vardimsAddress [ 3 ] ; RTWLoggingFcnPtr loggingPtrs [ 3 ] ;
sysRanDType * systemRan [ 4 ] ; int_T systemTid [ 4 ] ; } DataMapInfo ;
struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef struct {
nngfmk01le rtb ; hedh2b3jua rtm ; jm42yhk5t3 rtzce ; } ceyldc12a32 ; extern
void mn0c0dajpf ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , hedh2b3jua * const pg4evny104 , nngfmk01le * localB ,
itsu1yon4s * localX , jm42yhk5t3 * localZCE , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_differential_drive_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray *
mr_differential_drive_GetDWork ( const ceyldc12a32 * mdlrefDW ) ; extern void
mr_differential_drive_SetDWork ( ceyldc12a32 * mdlrefDW , const mxArray *
ssDW ) ; extern void mr_differential_drive_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray *
mr_differential_drive_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * differential_drive_GetCAPIStaticMap ( void )
; extern void k0ljbsbawd ( itsu1yon4s * localX ) ; extern void gcf02wcldj (
itsu1yon4s * localX ) ; extern void mjzcgvjfr5 ( nngfmk01le * localB ,
nes2y3gbqk * localXdot ) ; extern void h5vubb4liy ( const real_T * ogzd4gktpv
, dgl2ktxaof * localZCSV ) ; extern void a0atpmh4a1 ( void ) ; extern void
a0atpmh4a1TID1 ( void ) ; extern void differential_drive ( hedh2b3jua * const
pg4evny104 , const real_T * lpvqnpovh4 , const real_T * pzfzkyvfyq , const
real_T * nfh4bqjny5 , const real_T * jpn0h34cyd , const real_T * jmer1cslj0 ,
const real_T * ogzd4gktpv , real_T * g53rnik0s3 , real_T * pmto4vhzwe ,
real_T * h1kkaqpw03 , nngfmk01le * localB , itsu1yon4s * localX , jm42yhk5t3
* localZCE ) ; extern void differential_driveTID1 ( nngfmk01le * localB ) ;
extern void bfhsp2jlnv ( hedh2b3jua * const pg4evny104 ) ;
#endif
