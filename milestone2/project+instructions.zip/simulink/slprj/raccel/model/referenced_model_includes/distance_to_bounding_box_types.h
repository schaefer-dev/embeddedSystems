#include "__cf_distance_to_bounding_box.h"
#ifndef RTW_HEADER_distance_to_bounding_box_types_h_
#define RTW_HEADER_distance_to_bounding_box_types_h_
typedef struct ezq1aalfj0 av1wmy0pwq ;
#endif
