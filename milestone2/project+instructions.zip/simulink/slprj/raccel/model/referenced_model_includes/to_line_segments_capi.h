#include "__cf_to_line_segments.h"
#ifndef RTW_HEADER_to_line_segments_capi_h_
#define RTW_HEADER_to_line_segments_capi_h_
#include "to_line_segments.h"
extern void to_line_segments_InitializeDataMapInfo ( ouu5lrosbi * const
gpglj2bx1v , oxh54ew2sr * localDW , void * sysRanPtr , int contextTid ) ;
#endif
