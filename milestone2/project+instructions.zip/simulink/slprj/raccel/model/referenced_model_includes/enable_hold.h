#include "__cf_enable_hold.h"
#ifndef RTW_HEADER_enable_hold_h_
#define RTW_HEADER_enable_hold_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef enable_hold_COMMON_INCLUDES_
#define enable_hold_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "enable_hold_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_nonfinite.h"
typedef struct { real_T c1yikhioct ; } izbiho5mjy ; typedef struct { int8_T
o3loph3gyw ; boolean_T c3mmr1u343 ; boolean_T cvt4onnzup ; } isbf0vjqji ;
typedef struct { real_T oez5bkv2ld ; real_T daldcwqhia ; } ayscym2s52 ;
struct ksacfc1uotb_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; } ;
struct a150ea0bnm { struct SimStruct_tag * _mdlRefSfcnS ; const
rtTimingBridge * timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; sysRanDType *
systemRan [ 3 ] ; int_T systemTid [ 3 ] ; } DataMapInfo ; struct { int_T
mdlref_GlobalTID [ 3 ] ; } Timing ; } ; typedef struct { izbiho5mjy rtb ;
isbf0vjqji rtdw ; j40hacjaod rtm ; } n1ljxg42ztp ; extern void k1bgzwznlm (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , j40hacjaod * const m5524orqff , izbiho5mjy * localB ,
isbf0vjqji * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_enable_hold_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_enable_hold_GetDWork ( const
n1ljxg42ztp * mdlrefDW ) ; extern void mr_enable_hold_SetDWork ( n1ljxg42ztp
* mdlrefDW , const mxArray * ssDW ) ; extern void
mr_enable_hold_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_enable_hold_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * enable_hold_GetCAPIStaticMap ( void ) ;
extern void gu4l3yxezw ( real_T * ax3gpbdowu ) ; extern void o0iyk4gijb (
const real_T * bfbsotkw43 , izbiho5mjy * localB , isbf0vjqji * localDW ,
ayscym2s52 * localZCSV ) ; extern void k2z2rnpuwa ( isbf0vjqji * localDW ) ;
extern void enable_hold ( j40hacjaod * const m5524orqff , const real_T *
bfbsotkw43 , const real_T * dsy1i1sfrz , real_T * ax3gpbdowu , izbiho5mjy *
localB , isbf0vjqji * localDW ) ; extern void enable_holdTID2 ( void ) ;
extern void j4sttxvfh0 ( j40hacjaod * const m5524orqff ) ;
#endif
