#include "__cf_distance_to_bounding_box.h"
#ifndef RTW_HEADER_distance_to_bounding_box_cap_host_h_
#define RTW_HEADER_distance_to_bounding_box_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "calculate_intersection_capi_host.h"
#include "calculate_intersection_capi_host.h"
#include "calculate_intersection_capi_host.h"
#include "calculate_intersection_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 4 ] ; calculate_intersection_host_DataMapInfo_T child0 ;
calculate_intersection_host_DataMapInfo_T child1 ;
calculate_intersection_host_DataMapInfo_T child2 ;
calculate_intersection_host_DataMapInfo_T child3 ; }
distance_to_bounding_box_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void distance_to_bounding_box_host_InitializeDataMapInfo (
distance_to_bounding_box_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
