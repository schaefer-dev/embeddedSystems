#include "__cf_model.h"
#ifndef RTW_HEADER_model_h_
#define RTW_HEADER_model_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef model_COMMON_INCLUDES_
#define model_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "sigstream_rtw.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "model_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "scouts.h"
#include "referee.h"
#include "random_communication_loss.h"
#include "own_scout.h"
#include "own_collector.h"
#include "god.h"
#include "collectors.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#define MODEL_NAME model
#define NSAMPLE_TIMES (7) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (228) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (29)   
#elif NCSTATES != 29
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T pbx0mdxumm ; } ihkn4kjb3g ; typedef struct { int8_T
aglykiehjc ; } cxrroskuxu ; typedef struct { real_T dwpkm32nka ; } c4hc1fx0ut
; typedef struct { int8_T htpbyzpanx ; boolean_T cy2gauiafv ; } nmjqxxn2eh ;
typedef struct { real_T g30h5ef02j ; } aainfzcd5b ; typedef struct { real_T
dxyv3wxlza ; } ljmjt33dvj ; typedef struct { int8_T ne2hs2xcup ; boolean_T
a44sofagvr ; } nams24zbw1 ; typedef struct { real_T d2ymbezhd0 ; } acvyqikykn
; typedef struct { real_T niif3usptd ; real_T amawxeyk2i ; real_T fqueftcfuf
; real_T nodxfcp40m ; real_T ngl5ursdp5 ; real_T kpxkxchg4l ; real_T
bmkqgyuy02 ; real_T ob04arcrak ; real_T ceigekm0he ; real_T ivfx3vycfj ;
real_T j2obp2vdbm ; real_T jg24yuqrlf ; real_T n1sni4qgda ; real_T axkn0tj3kk
; real_T clbwajughp ; real_T imc11ixkro ; real_T lcu5p032hu ; real_T
flfcvs24j3 ; real_T imqx44z1y2 ; real_T pmsvvrsozf ; real_T p53fcq012l ;
real_T pxdpmfdlbp ; real_T ksfajmgxst ; real_T mx1amll0zz ; real_T jcjxswchz2
; real_T b4csihzanf ; real_T gt3kseiesc ; real_T ejfmbnlbtp ; real_T
mnfd3vgtyn ; real_T avftxcinmd ; real_T hefv5fowan ; real_T klpnkc3lij ;
real_T l3ycykxga3 ; real_T eqx2aoxtn5 ; real_T oi3u13hlpw ; real_T hqbuqvvxe5
; real_T aly0nl4jy5 ; real_T lz4q5mssw3 ; real_T foioshrzjd ; real_T
kdwduyqgbt ; real_T p3xvqs243l ; real_T pn5amc2d2d ; real_T cbwv340ptd ;
real_T bqttxzaoip ; real_T bmxsgsmrv3 ; real_T ff4mphjk34 ; real_T d4vij2rcmk
; real_T c42vzrsoa4 ; real_T fawcbqofbl ; real_T ofzi3mvxlc ; real_T
klsq3whhyq ; real_T o2gwyfz2ag ; real_T icl5evgdd3 ; real_T ewn1qhxrdv ;
real_T lgufrbtkr2 ; real_T fncdv5wdjq ; real_T f5n1njx0jw ; real_T kukqniznpc
; real_T hd2bjuef5v ; real_T bkptnrsq23 ; real_T lcgby2b3g2 ; real_T
lt55ikl1yb ; real_T h44lhptqp3 ; real_T oigyvmvs1s ; real_T h1vs0aa35r ;
real_T alshwojygz ; real_T okkjvum3js ; real_T pfqp1ddl2k ; real_T cthg5rqel1
; real_T kgw0amexsf ; real_T lnkxgp0qhe ; real_T jnnqtz1wy1 ; real_T
aot3rslnli ; real_T irhivy0rii ; real_T bc5e4hvxwh ; real_T jtscbp5h3y ;
real_T jikjkxqm5d ; real_T p5rd2lyc3a ; real_T dna0tmvu4j ; real_T jxwwsn1eza
; real_T mko2h50i0e ; real_T lpn35yy1gc ; real_T fnx0uk5nyl ; real_T
gwyqdebgln ; real_T kvzqlrq12h ; real_T je1a5dspy2 ; real_T eoaow3o32z ;
real_T m3zmrf0rvl ; real_T eg4x542g0m ; real_T nejcie2kgo ; real_T bkbjb1as1y
; real_T pibu2pfiet ; real_T hanpj1yii4 ; real_T j1u05n2him ; real_T
obqqvm1rdw ; real_T ilcxsu533x ; real_T lgdbztnwrq ; real_T mktiqey2b5 ;
real_T oyxqk3lhvc ; real_T d1pzbumep2 ; real_T fn5ekxq1f1 ; real_T fbyn4xsxtz
; real_T pf0s5ndbob ; real_T oxyms50csp ; real_T n0hp4zagjv ; real_T
jhryf4edf5 ; real_T akqigye0d2 ; real_T jvbwg00o4c ; real_T gbl1hdv1ob ;
real_T h1vbkdhkzd ; real_T mzg13b5ygf ; real_T oi0cnu5mro ; real_T mszbqrncxw
; real_T bksh4hybza ; real_T cf3wgy2zqk ; real_T kxkwmyn4te ; real_T
hafzobe53s ; real_T fpynlmxbjm ; real_T ajou24crmh ; real_T izg5xjzxp0 ;
real_T ptfiptqj5a ; real_T g4ltns0hif ; real_T mozax3lynk ; real_T c1dfijug4k
; real_T mwfc1bfdzw ; real_T hko3vhqkfm ; real_T apexlhdnec ; real_T
aohqmjjcro ; real_T bh1kll0gtc ; real_T eqs3l5srls ; real_T n0p4nmln4q ;
real_T ob4gj301px ; real_T h04isb3fq2 ; real_T etml3z0rpj ; real_T gbu5gikuvw
; real_T mlbdwmzp3m ; real_T e1andkbfid ; real_T g4d2idhg40 ; real_T
gtt1osg1f1 ; real_T emo55yzw2r ; real_T ez4ky3mfnm ; real_T ienss5zvmv ;
real_T lx5swuzcbh ; real_T peeeqojqac ; real_T jp3fqgejke ; real_T jqlmorfuba
; real_T myryoqjss3 ; real_T evwcvo5bkm ; real_T hcmy1jabtw ; real_T
o3oupxvkog ; real_T iun5ct5baq ; real_T mfnpex3gsr ; real_T agsamxjw3z ;
real_T pu32vkhlie ; real_T ihvwlbvzka ; real_T kzfplnwos4 ; real_T cjfxu2cgxt
; real_T fmuhs2dz41 ; real_T lensyzirgi ; real_T i24yw4mbom ; real_T
nkpjbarrr0 ; real_T aciak3h2dg ; real_T ov1li0kvq5 ; real_T cjzme0drrn ;
real_T fgzsligzri ; real_T i5zahmuwcw ; real_T braz0mphnk ; real_T eklrysk5eo
; real_T kcrpted3qh ; real_T l0m5sgndod ; real_T mnlyiwbsiy ; real_T
nizbijxigg ; real_T mm30op0rpl ; real_T ebjz1pdibk ; real_T lx1v2ap3mi ;
real_T lf4hktw4eg ; real_T ayjn11ju0w ; real_T e3kmye2ups ; real_T iwvwrqn5jk
; real_T kfle00trtg ; real_T lz3qbaqq5i ; real_T afhy1i1qj1 ; real_T
boesjlevad ; real_T kr5qwmuyi1 ; real_T j5l4sqyobi ; real_T apovva0uhx ;
real_T ha2gy1cf2e ; real_T huaria4chy ; real_T ep35d2ihe4 ; real_T bb0kqphudk
; real_T ewmrkcguh4 ; real_T kjgiaop3tk ; real_T fgumimiiqn ; real_T
fpd0lgtezn ; real_T g0ollzpsdy ; real_T gwcyios52e ; real_T f4fh0ct45e ;
real_T ocddn3l0tx ; real_T k3q51v2rm5 ; real_T ifglumd1vr ; real_T pmhf3wvapt
; boolean_T dxs5uxsq1f ; boolean_T f4veiiqqom ; boolean_T ae1szi3am4 ;
boolean_T m1azb0d0ot ; boolean_T k3l3s1o3wj ; ljmjt33dvj iclkdei2xh ;
ljmjt33dvj p4qjdvlwyg ; c4hc1fx0ut nzg4g3a3cq ; ljmjt33dvj kmz50yvsje ;
c4hc1fx0ut ma24ilhkjx ; ljmjt33dvj lvs4tuvo5q ; ljmjt33dvj ficyystmwp ;
c4hc1fx0ut lsd4zxxavz ; ljmjt33dvj pkngnbryvt ; c4hc1fx0ut kinerpas1h ;
ljmjt33dvj kra4na34gj ; ljmjt33dvj cecxmc0h1i ; c4hc1fx0ut g4s4twk2b2 ;
ljmjt33dvj avpfi51xqj ; c4hc1fx0ut an5txqujzc ; ljmjt33dvj hguo0kwh4p ;
ljmjt33dvj oxitfjhj0e ; c4hc1fx0ut kxn0m3zbec ; ljmjt33dvj hybb0kqc4xm ;
c4hc1fx0ut btispofq2nb ; ihkn4kjb3g kbzrijfb2o ; ihkn4kjb3g l4nwcjxgbmr ; }
lemdyvfalh ; typedef struct { real_T e2oy5ioqnc ; real_T kyzn4txre0 ; real_T
hfs1xp5lvr ; real_T bjyhsdab1f ; real_T gqn54rsyya ; real_T mv0hu4lay5 ;
real_T da3zdpiekx ; real_T or4z10x42w ; real_T k3u5qq1zgy ; real_T jc5i3xd3ww
; real_T dznfmozmm1 ; real_T acpqqpszmg ; real_T ktoj31pspb ; real_T
lpfwplzxht ; real_T befkob0nm0 ; real_T ibqg0ihc2r ; real_T kpfibyvpwr ;
real_T n3zb0h1u0l ; real_T mwxwvboycb ; real_T btysz113kg ; real_T kckc33tgvz
; real_T l2yzz1po42 ; real_T csfld12lsn ; real_T mp4vtnpatt ; real_T
ffklragg5z ; real_T ocpmugoslr ; real_T gwzlzi3fcr ; real_T pqke1qtp5t ;
real_T cb5dyyie53 ; real_T a2eui2uq4d ; real_T hcx5mfpdj5 ; real_T adzhjlx1d3
; real_T ejrr0opujh ; real_T fbdoco3pso ; real_T pmzemkzfot ; real_T
d4miin10zi ; struct { void * LoggedData ; } d3mnr10sky ; struct { void *
LoggedData ; } mkr54arb4j ; struct { void * LoggedData ; } hk23ydukzk ;
struct { void * LoggedData ; } oua30wjv04 ; struct { void * LoggedData ; }
c1byvylifi ; struct { void * LoggedData ; } nwje3aiwa1 ; struct { void *
LoggedData ; } fkbhho503f ; struct { void * LoggedData ; } ksrobbhom2 ;
struct { void * LoggedData ; } akcybxgxsq ; struct { void * LoggedData ; }
nz0oohz2u4 ; struct { void * LoggedData ; } drxpazwmlt ; struct { void *
LoggedData ; } ig0vckuqns ; struct { void * LoggedData ; } nbqifup5jw ;
struct { void * LoggedData ; } eyavcmgjhw ; struct { void * LoggedData ; }
dqblop4kaf ; struct { void * LoggedData ; } pth3l4syjf ; struct { void *
LoggedData ; } plmlo4ypnz ; struct { void * LoggedData ; } bhsqnunmsp ;
struct { void * LoggedData ; } aob0ldracd ; struct { void * LoggedData ; }
o2zqskp0ft ; struct { void * LoggedData ; } bn14jpeetz ; struct { void *
LoggedData ; } bimco1vbz2 ; struct { void * LoggedData ; } eyg4yw4ho2 ;
struct { void * LoggedData ; } fvvolt5ofh ; struct { void * LoggedData ; }
f4mrwvbfjs ; struct { void * LoggedData ; } nsg0woburo ; struct { void *
LoggedData ; } midgwga0ec ; struct { void * LoggedData ; } pk0mphd2xd ;
uint32_T f4rwqf4frz ; uint32_T au4xntftvs ; uint32_T ie1py2ucxo ; uint32_T
pqwtpqfmer ; uint32_T ceon4llkl0 ; uint32_T m3ijpx4vb2 ; uint32_T mbbcjwmfvo
; uint32_T mwkaw4a031 ; uint32_T d1uevuez15 ; uint32_T az0pjth0yl ; uint32_T
eopul15exg ; uint32_T kty32tplte ; uint32_T jdbx1wfv5p ; uint32_T kqwms3hfnx
; int_T nshrin44md ; int_T dq2eqqmpnm ; int_T ecxgojhghs ; int_T ljezothvrs ;
int_T h12cni13rl ; int_T n3xnek2f5o ; int_T exjf4rxdot ; int_T i2hx5tdvwv ;
int_T oiolgcu0wl ; int_T pgn454kvlc ; int_T htb4ehyw0n ; int_T l0oup0hhnz ;
boolean_T eq15hbxjqn ; boolean_T jfqt5h4wfl ; boolean_T hindzrac3d ;
boolean_T kkjthjqqu3 ; boolean_T poy4xxneo2 ; boolean_T e0ec4cmqdf ;
boolean_T bl2ajyzhej ; boolean_T fvu51ucdxu ; boolean_T jg213mjvq3 ;
boolean_T mmzzrglrkc ; boolean_T mmlxdosi3k ; boolean_T kf5eqo00rt ;
boolean_T aiitkk4m3o ; boolean_T oudpg520pw ; boolean_T br1nsrn1ta ;
boolean_T ezyniw4cbw ; boolean_T bywbz31gy0 ; boolean_T gotonlqiyi ;
boolean_T b2y22mzkey ; boolean_T gdrcnlhhpt ; boolean_T ixlw1fqg4v ;
boolean_T nd0mpkfxki ; boolean_T eqjaa3udld ; boolean_T fxi1r5i5fw ;
boolean_T kxbmwhhmrz ; boolean_T euxca53afw ; boolean_T e3mhqogr2m ;
boolean_T hlsn0v1li5 ; boolean_T desw3kfxwr ; boolean_T buafozr5i3 ;
boolean_T aodfwsooi1 ; boolean_T g2iw43qxgp ; boolean_T h3srasu25l ;
nfown5ry3ad f4ieeyvu2d ; oak5mylmriv ffuc4mh4bg ; l22alrksvl0 h314wg0my5 ;
jj23ys45opf boyipppd3j ; jj23ys45opf lxmfq3fjys ; jj23ys45opf o1gitq4ln2 ;
jj23ys45opf j2a2rpgfvf ; lfq44zo2ofx clco1wljff ; n2raavie0r3 pju0s2xsd3 ;
mawva2btrby d1sci41lkp ; nams24zbw1 iclkdei2xh ; nams24zbw1 p4qjdvlwyg ;
nmjqxxn2eh nzg4g3a3cq ; nams24zbw1 kmz50yvsje ; nmjqxxn2eh ma24ilhkjx ;
nams24zbw1 lvs4tuvo5q ; nams24zbw1 ficyystmwp ; nmjqxxn2eh lsd4zxxavz ;
nams24zbw1 pkngnbryvt ; nmjqxxn2eh kinerpas1h ; nams24zbw1 kra4na34gj ;
nams24zbw1 cecxmc0h1i ; nmjqxxn2eh g4s4twk2b2 ; nams24zbw1 avpfi51xqj ;
nmjqxxn2eh an5txqujzc ; nams24zbw1 hguo0kwh4p ; nams24zbw1 oxitfjhj0e ;
nmjqxxn2eh kxn0m3zbec ; nams24zbw1 hybb0kqc4xm ; nmjqxxn2eh btispofq2nb ;
cxrroskuxu kbzrijfb2o ; cxrroskuxu l4nwcjxgbmr ; } hyjfvnofcj ; typedef
struct { hxbik2dpvc drvapa0zob ; ht5eljqmzr filfct1tgr ; pguwt3obif
kv2ymoupnq ; kffjcg2trg oayeluc0cz ; b42hzqgmbd constdhp4z ; aacr0kzepk
j2renhr2u5 ; } drm05o4a31 ; typedef struct { e1bl4ewqak drvapa0zob ;
enfmk51rhf filfct1tgr ; p0jxnzcxrr kv2ymoupnq ; k0l4gtazue oayeluc0cz ;
ncpvkuj3c4 constdhp4z ; efjetl2o44 j2renhr2u5 ; } cjfxanv4c1 ; typedef struct
{ bzj52dkamz drvapa0zob ; ewqsq3nueu filfct1tgr ; ltkhnhhpgo kv2ymoupnq ;
fchgvwri0g oayeluc0cz ; b55xret0yr constdhp4z ; ipk2smqibi j2renhr2u5 ; }
eorwn5jz54 ; typedef struct { fhtpdw1g0r drvapa0zob ; fl5hh3aqjo filfct1tgr ;
ftjpwe0gaz kv2ymoupnq ; hh1vgedtlr oayeluc0cz ; hxzibpq3xb constdhp4z ;
esxs3zlw1c j2renhr2u5 ; } bznpx5nius ; typedef struct { mkb4sv52uy p0vqaartg2
; cy0dgds3yt g42x2egyhg ; real_T nj4khrrbce ; real_T cr12duzbur ; real_T
pffitnfnqe ; real_T i323zpvduj ; real_T fzhufaq5cl ; real_T gzqeuf05wd ;
real_T msc4eo3tpl ; real_T h3peij1s5f ; real_T hfmslajsaq ; real_T brvh5issds
; real_T aoien1ei2f ; a5t0oyxt24 dvigt2314i ; real_T k4qhntzszd ; real_T
m55lanshhi ; real_T l5tzq45gm0 ; real_T ktzu2wz1bq ; real_T b3w4eanubz ;
real_T d30sgmwjo4 ; real_T abk24ckxzh ; real_T fxn5bvb3ka ; real_T j1spzbipur
; real_T pdspixj5lc ; real_T pjk3dcjfo3 ; real_T ikyuazazqo ; gffsp5zqsa
jrdg2hs2g4 ; real_T ckcq5gohqr ; real_T cro2o4zkpy ; real_T g3ofg53vht ;
real_T gyi5kkrxy4 ; real_T jeelupvggj ; real_T cdkcir2qph ; real_T h2ipbhhyno
; real_T brj0qr5fjv ; real_T kzak4fes4v ; real_T ablqr2dpkr ; real_T
l3y4ca43mi ; gqs0ayjk3c imkd53piow ; real_T bfvarlului ; real_T lzwlmasd4w ;
real_T pmpmyhrfdo ; real_T hhznpq0vpv ; real_T fruch5xnvu ; real_T nlhzbqbe4i
; real_T eyipeknaej ; real_T fyzpsmj3aq ; real_T c1ihdfzx43 ; real_T
kul4wh3zxi ; real_T ne33guwd4a ; h1iwueqcbz e3nfagplz5 ; acvyqikykn
iclkdei2xh ; acvyqikykn p4qjdvlwyg ; aainfzcd5b nzg4g3a3cq ; acvyqikykn
kmz50yvsje ; aainfzcd5b ma24ilhkjx ; acvyqikykn lvs4tuvo5q ; acvyqikykn
ficyystmwp ; aainfzcd5b lsd4zxxavz ; acvyqikykn pkngnbryvt ; aainfzcd5b
kinerpas1h ; acvyqikykn kra4na34gj ; acvyqikykn cecxmc0h1i ; aainfzcd5b
g4s4twk2b2 ; acvyqikykn avpfi51xqj ; aainfzcd5b an5txqujzc ; acvyqikykn
hguo0kwh4p ; acvyqikykn oxitfjhj0e ; aainfzcd5b kxn0m3zbec ; acvyqikykn
hybb0kqc4xm ; aainfzcd5b btispofq2nb ; } jb0sctis1o ; typedef struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo * childMMI [ 10 ] ; }
DataMapInfo ; struct hs4pzgkdu5_ { real_T Output_Y0 ; } ; struct dbiap1aeek_
{ real_T Output_Y0 ; } ; struct esdli4e4ad_ { real_T Output_Y0 ; } ; struct
el3s11bva3g_ { real_T Constant_Value ; real_T Constant8_Value ; real_T
Constant9_Value ; real_T Constant10_Value ; real_T Constant11_Value ; real_T
Constant12_Value ; real_T Constant13_Value ; real_T random_Value ; real_T
pattern_Value ; real_T Constant5_Value ; real_T Constant7_Value ; real_T
random_x_destination_Minimum ; real_T random_x_destination_Maximum ; real_T
random_x_destination_Seed ; real_T random_y_destination_Minimum ; real_T
random_y_destination_Maximum ; real_T random_y_destination_Seed ; real_T
Constant13_Value_elqoepz2mi ; real_T UniformRandomNumber_Minimum ; real_T
UniformRandomNumber_Maximum ; real_T UniformRandomNumber_Seed ; real_T
Switch_Threshold ; real_T Constant9_Value_mmv01kox2d ; real_T Constant1_Value
; real_T Switch1_Threshold ; real_T Constant13_Value_eqp0jos5ki ; real_T
UniformRandomNumber_Minimum_e22xufda1w ; real_T
UniformRandomNumber_Maximum_duuqdny15m ; real_T
UniformRandomNumber_Seed_djtjrnsnnx ; real_T Switch_Threshold_cdlb2dxcel ;
real_T Constant9_Value_mkm1qdjnjo ; real_T Constant1_Value_kc3fd44lvc ;
real_T Switch1_Threshold_jaddws4amb ; real_T Constant5_Value_ilynirohi2 ;
real_T Constant13_Value_eeh12bmm2g ; real_T
UniformRandomNumber_Minimum_k02uumxuku ; real_T
UniformRandomNumber_Maximum_nkwogljtyv ; real_T
UniformRandomNumber_Seed_acwzdxvlvk ; real_T Switch_Threshold_pixetlauxb ;
real_T Constant8_Value_jf2fosnw3b ; real_T Constant9_Value_pjdmuf5qiy ;
real_T Constant_Value_mtxti12az5 ; real_T Switch1_Threshold_mfp2kd03vv ;
real_T Constant4_Value ; real_T Constant9_Value_jedsy1niga ; real_T
Switch1_Threshold_ggx3yt4m15 ; real_T Constant6_Value ; real_T
Switch2_Threshold ; real_T Constant9_Value_hjx2d0ehlo ; real_T
Constant_Value_aar2t1o0pc ; real_T Switch1_Threshold_bkdrcbb4na ; real_T
Constant9_Value_gs2rlkywki ; real_T Constant_Value_ijxldit3zf ; real_T
Switch1_Threshold_leklxdka0k ; real_T Switch3_Threshold ; real_T
Constant_Value_fvslqcrdl2 ; real_T Memory_InitialCondition ; real_T
Memory1_InitialCondition ; real_T Memory2_InitialCondition ; real_T
Constant7_Value_lo1deheetm ; real_T random_x_destination_Minimum_fxtuk00qww ;
real_T random_x_destination_Maximum_jv24dihhtt ; real_T
random_x_destination_Seed_a4xosc2llf ; real_T
random_y_destination_Minimum_dergtqofok ; real_T
random_y_destination_Maximum_cttnoi3pwu ; real_T
random_y_destination_Seed_blcncfcags ; real_T Constant13_Value_np2scmdq2n ;
real_T UniformRandomNumber_Minimum_hi1nli0cfn ; real_T
UniformRandomNumber_Maximum_iqv4e5c3zy ; real_T
UniformRandomNumber_Seed_ndvlssmenu ; real_T Switch_Threshold_jfs2k2a5tu ;
real_T IC_Value ; real_T Constant9_Value_eswfotb04n ; real_T
Constant1_Value_mribuf3piz ; real_T Switch1_Threshold_io1apnmx2q ; real_T
Constant13_Value_lfi4t4n5ry ; real_T UniformRandomNumber_Minimum_j2apvjkwzu ;
real_T UniformRandomNumber_Maximum_m3cg2u240z ; real_T
UniformRandomNumber_Seed_mgaiufdtyi ; real_T Switch_Threshold_a1jo4yhdpi ;
real_T IC1_Value ; real_T Constant9_Value_cto3nurbbk ; real_T
Constant1_Value_hot2ytiafz ; real_T Switch1_Threshold_mjy4itckve ; real_T
Constant5_Value_czaaoinsnr ; real_T Constant13_Value_dlaeksitf2 ; real_T
UniformRandomNumber_Minimum_os52rgwsjp ; real_T
UniformRandomNumber_Maximum_g5mazrmshc ; real_T
UniformRandomNumber_Seed_csjtlmoxke ; real_T Switch_Threshold_axnrqpilx0 ;
real_T IC2_Value ; real_T Constant8_Value_hs2smrn0nu ; real_T
Constant9_Value_pxe2jyk15f ; real_T Constant_Value_cgsw52jc2f ; real_T
Switch1_Threshold_dpybs3ruok ; real_T Constant4_Value_hwsd0aq5tk ; real_T
Constant9_Value_dbxnqlknqm ; real_T Switch1_Threshold_byxnfpd4v3 ; real_T
Constant6_Value_kvbns2yqhv ; real_T Switch2_Threshold_eflsudq1e1 ; real_T
Constant9_Value_f3b050jkcc ; real_T Constant_Value_eajaadlfel ; real_T
Switch1_Threshold_ixuscjd3ov ; real_T Constant9_Value_duq42b30jy ; real_T
Constant_Value_fnzeo0uh0y ; real_T Switch1_Threshold_lfgrm43eqj ; real_T
Switch3_Threshold_cmbttkg5bu ; real_T Constant_Value_bveil10atp ; real_T
Memory_InitialCondition_dstumr4sfk ; real_T
Memory1_InitialCondition_ot0ig5ijng ; real_T
Memory2_InitialCondition_i5zi52wwtm ; real_T Constant7_Value_jrza4df2dq ;
real_T Constant_Value_ba2qae5xn0 ; real_T Memory_InitialCondition_hu5tzlerqo
; real_T Constant9_Value_ayk0x4s3me ; real_T Constant_Value_lzyuti2pmz ;
real_T Switch1_Threshold_arl11mzrqd ; real_T Constant9_Value_b2cgcai5jd ;
real_T Constant_Value_j2wanecgzn ; real_T Switch1_Threshold_gfymtird2p ;
real_T random_x_destination_Minimum_oaup3ii1l5 ; real_T
random_x_destination_Maximum_p1st3nyrun ; real_T
random_x_destination_Seed_byzwkqj0yd ; real_T
random_y_destination_Minimum_aarhjqxx0j ; real_T
random_y_destination_Maximum_bmfxifldi0 ; real_T
random_y_destination_Seed_oo4c5wzgp2 ; real_T IC2_Value_dtciakshru ; real_T
Constant9_Value_n54nuen2rj ; real_T Constant1_Value_lztbhcwkig ; real_T
Switch1_Threshold_n0njrd3uxy ; real_T IC_Value_j0goa0uerk ; real_T
Constant9_Value_jo0s0sfoe1 ; real_T Constant1_Value_np5p343ljn ; real_T
Switch1_Threshold_pmhczo2bql ; real_T Constant5_Value_eyzlfy4z1i ; real_T
IC1_Value_ny1yfk1mio ; real_T Constant8_Value_o40j3s04wm ; real_T
Constant9_Value_hi3q3xgenf ; real_T Constant_Value_m5gwddclk4 ; real_T
Switch1_Threshold_eskalvmcl5 ; real_T Constant4_Value_dke4qkvy2m ; real_T
Constant9_Value_ikig2ugeov ; real_T Switch1_Threshold_megsj2kdn4 ; real_T
Constant6_Value_natwbdlt5l ; real_T Switch2_Threshold_abc2i3utpw ; real_T
Constant9_Value_prk4lzbupc ; real_T Constant_Value_f2ccrnzbo3 ; real_T
Switch1_Threshold_gv03eoziqu ; real_T Constant9_Value_gv1ubadb1z ; real_T
Constant_Value_os30wzhpv5 ; real_T Switch1_Threshold_othhfgja33 ; real_T
Switch3_Threshold_k51oykqbvl ; real_T Constant_Value_n4u35q4q5x ; real_T
Memory_InitialCondition_f1jkovjs1i ; real_T
Memory1_InitialCondition_h3nsks1jbo ; real_T
Memory2_InitialCondition_mvexewp4sm ; real_T Constant7_Value_jejusotfky ;
real_T Constant3_Value ; real_T IC_Value_po55tmgpac ; real_T
IC1_Value_olzkq2isfl ; real_T IC2_Value_b44twnluu2 ; real_T
random_x_destination_Minimum_ky4anpr4m4 ; real_T
random_x_destination_Maximum_gvztpymhe0 ; real_T
random_x_destination_Seed_k2uyi2eyqw ; real_T
random_y_destination_Minimum_bmsqkwvh1b ; real_T
random_y_destination_Maximum_jr3ltzmqnh ; real_T
random_y_destination_Seed_nyfms4qhrl ; real_T Constant9_Value_gtmy0p2kfs ;
real_T Constant1_Value_ouzfzmlb2y ; real_T Switch1_Threshold_kelisza0pg ;
real_T Constant9_Value_jgpf1cvdvz ; real_T Constant1_Value_p13umlhyxq ;
real_T Switch1_Threshold_n022ebo4n0 ; real_T Constant5_Value_prylx2nfvt ;
real_T Constant8_Value_knyppzji1e ; real_T Constant9_Value_oywmk54fo2 ;
real_T Constant_Value_fm5gnbjkca ; real_T Switch1_Threshold_agqmymtkki ;
real_T Constant4_Value_kt1d1r1rvu ; real_T Constant9_Value_anz3ryaeir ;
real_T Switch1_Threshold_bk2kua4y4r ; real_T Constant6_Value_iwauxqmbam ;
real_T Switch2_Threshold_nkd344stci ; real_T Constant9_Value_eqe2lhczxv ;
real_T Constant_Value_dwypnnrzgc ; real_T Switch1_Threshold_jiiozq2xmu ;
real_T Constant9_Value_fajil5otqc ; real_T Constant_Value_lbmdjikwhf ; real_T
Switch1_Threshold_cg40gsvgfi ; real_T Switch3_Threshold_pvimerup5n ; real_T
Constant_Value_nryfzuvceq ; real_T Memory_InitialCondition_et31lrw0fp ;
real_T Memory1_InitialCondition_pmpt1ejnb2 ; real_T
Memory2_InitialCondition_dnlujtrzsv ; real_T Constant7_Value_fhb5yuyaap ;
uint8_T light_pattern_switch_CurrentSetting ; esdli4e4ad iclkdei2xh ;
esdli4e4ad p4qjdvlwyg ; dbiap1aeek nzg4g3a3cq ; esdli4e4ad kmz50yvsje ;
dbiap1aeek ma24ilhkjx ; esdli4e4ad lvs4tuvo5q ; esdli4e4ad ficyystmwp ;
dbiap1aeek lsd4zxxavz ; esdli4e4ad pkngnbryvt ; dbiap1aeek kinerpas1h ;
esdli4e4ad kra4na34gj ; esdli4e4ad cecxmc0h1i ; dbiap1aeek g4s4twk2b2 ;
esdli4e4ad avpfi51xqj ; dbiap1aeek an5txqujzc ; esdli4e4ad hguo0kwh4p ;
esdli4e4ad oxitfjhj0e ; dbiap1aeek kxn0m3zbec ; esdli4e4ad hybb0kqc4xm ;
dbiap1aeek btispofq2nb ; hs4pzgkdu5 kbzrijfb2o ; hs4pzgkdu5 l4nwcjxgbmr ; } ;
extern const real_T model_RGND ; extern const char *
RT_MEMORY_ALLOCATION_ERROR ; extern lemdyvfalh lemdyvfalhs ; extern
drm05o4a31 drm05o4a314 ; extern hyjfvnofcj hyjfvnofcjf ; extern el3s11bva3g
el3s11bva3 ; extern real_T rtP_collision_detection_distance ; extern real_T
rtP_push_force ; extern const rtwCAPI_ModelMappingStaticInfo *
model_GetCAPIStaticMap ( void ) ; extern SimStruct * const rtS ; extern const
int_T gblNumToFiles ; extern const int_T gblNumFrFiles ; extern const int_T
gblNumFrWksBlocks ; extern rtInportTUtable * gblInportTUtables ; extern const
char * gblInportFileName ; extern const int_T gblNumRootInportBlks ; extern
const int_T gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ;
extern const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [
] ; extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model ( void
) ;
#endif
