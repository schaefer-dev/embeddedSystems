#include "__cf_model.h"
#ifndef RTW_HEADER_model_private_h_
#define RTW_HEADER_model_private_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "model.h"
#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)   if(!(ptr)) {\
  ssSetErrorStatus(rtS, RT_MEMORY_ALLOCATION_ERROR);\
  }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((ptr));\
  (ptr) = (NULL);\
  }
#else
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((void *)(ptr));\
  (ptr) = (NULL);\
  }
#endif
#endif
extern void b2aoyqlj0u ( ihkn4kjb3g * localB , hs4pzgkdu5 * localP ) ; extern
void l4nwcjxgbm ( SimStruct * rtS_e , real_T ledyn2wfph , real_T om40w1my5d ,
ihkn4kjb3g * localB , cxrroskuxu * localDW ) ; extern void msusqe2h5f (
c4hc1fx0ut * localB , dbiap1aeek * localP ) ; extern void niks31lasr (
SimStruct * rtS_i , nmjqxxn2eh * localDW ) ; extern void gfbmlyqfm4 ( real_T
emajlayf2s , nmjqxxn2eh * localDW , aainfzcd5b * localZCSV ) ; extern void
jojddoumvh ( nmjqxxn2eh * localDW ) ; extern void btispofq2n ( SimStruct *
rtS_i , real_T emajlayf2s , real_T p0c03evahm , c4hc1fx0ut * localB ,
nmjqxxn2eh * localDW ) ; extern void nitbgijebs ( ljmjt33dvj * localB ,
esdli4e4ad * localP ) ; extern void fzc2vzhuha ( SimStruct * rtS_p ,
nams24zbw1 * localDW ) ; extern void bvd5cp35li ( real_T hgj1q35zpt ,
nams24zbw1 * localDW , acvyqikykn * localZCSV ) ; extern void pnoy04jvbo (
nams24zbw1 * localDW ) ; extern void hybb0kqc4x ( SimStruct * rtS_f , real_T
hgj1q35zpt , real_T kfqqqjoab4 , ljmjt33dvj * localB , nams24zbw1 * localDW )
;
#if defined(MULTITASKING)
#error Models using the variable step solvers cannot define MULTITASKING
#endif
#endif
