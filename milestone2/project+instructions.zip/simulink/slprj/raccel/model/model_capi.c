#include "__cf_model.h"
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "model_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "model.h"
#include "model_capi.h"
#include "model_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"model/Clock" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 1 , 0 ,
TARGET_STRING ( "model/Model6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 }
, { 2 , 0 , TARGET_STRING ( "model/Model7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 3 , 0 , TARGET_STRING ( "model/Model8" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 4 , 0 , TARGET_STRING ( "model/Model9" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 5 , 0 , TARGET_STRING (
"model/god" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 2 } , { 6 , 0 ,
TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 2 } ,
{ 7 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 ,
0 , 0 } , { 8 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 3
, 0 , 0 , 0 , 0 } , { 9 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING (
"" ) , 4 , 0 , 0 , 0 , 0 } , { 10 , 0 , TARGET_STRING ( "model/god" ) ,
TARGET_STRING ( "" ) , 5 , 0 , 0 , 0 , 0 } , { 11 , 0 , TARGET_STRING (
"model/god" ) , TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0 } , { 12 , 0 ,
TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 7 , 0 , 0 , 0 , 0 } ,
{ 13 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 8 , 0 , 0 ,
0 , 0 } , { 14 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 9
, 0 , 0 , 0 , 0 } , { 15 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING
( "" ) , 10 , 0 , 0 , 0 , 0 } , { 16 , 0 , TARGET_STRING ( "model/god" ) ,
TARGET_STRING ( "" ) , 11 , 0 , 0 , 0 , 0 } , { 17 , 0 , TARGET_STRING (
"model/god" ) , TARGET_STRING ( "" ) , 12 , 0 , 0 , 0 , 0 } , { 18 , 0 ,
TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 13 , 0 , 0 , 0 , 0 } ,
{ 19 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 14 , 0 , 0
, 0 , 0 } , { 20 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) ,
15 , 0 , 0 , 0 , 0 } , { 21 , 0 , TARGET_STRING ( "model/god" ) ,
TARGET_STRING ( "" ) , 16 , 0 , 0 , 0 , 0 } , { 22 , 0 , TARGET_STRING (
"model/god" ) , TARGET_STRING ( "" ) , 17 , 0 , 0 , 0 , 0 } , { 23 , 0 ,
TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 18 , 0 , 0 , 0 , 0 } ,
{ 24 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) , 19 , 0 , 0
, 0 , 0 } , { 25 , 0 , TARGET_STRING ( "model/god" ) , TARGET_STRING ( "" ) ,
20 , 0 , 0 , 0 , 0 } , { 26 , 0 , TARGET_STRING ( "model/referee" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 27 , 0 , TARGET_STRING (
"model/referee" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 28 , 0 ,
TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 , 0 , 0
} , { 29 , 0 , TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 3 ,
0 , 0 , 0 , 0 } , { 30 , 0 , TARGET_STRING ( "model/referee" ) ,
TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , { 31 , 0 , TARGET_STRING (
"model/referee" ) , TARGET_STRING ( "" ) , 5 , 0 , 0 , 0 , 0 } , { 32 , 0 ,
TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0
} , { 33 , 0 , TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 7 ,
0 , 0 , 0 , 0 } , { 34 , 0 , TARGET_STRING ( "model/referee" ) ,
TARGET_STRING ( "" ) , 8 , 1 , 0 , 0 , 2 } , { 35 , 0 , TARGET_STRING (
"model/referee" ) , TARGET_STRING ( "" ) , 9 , 1 , 0 , 0 , 2 } , { 36 , 0 ,
TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 10 , 0 , 0 , 0 , 0
} , { 37 , 0 , TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 11
, 0 , 0 , 0 , 0 } , { 38 , 0 , TARGET_STRING ( "model/referee" ) ,
TARGET_STRING ( "" ) , 12 , 0 , 0 , 0 , 0 } , { 39 , 0 , TARGET_STRING (
"model/referee" ) , TARGET_STRING ( "" ) , 13 , 0 , 0 , 0 , 0 } , { 40 , 0 ,
TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 14 , 0 , 0 , 0 , 0
} , { 41 , 0 , TARGET_STRING ( "model/referee" ) , TARGET_STRING ( "" ) , 15
, 0 , 0 , 0 , 0 } , { 42 , 0 , TARGET_STRING ( "model/referee" ) ,
TARGET_STRING ( "" ) , 16 , 1 , 0 , 0 , 2 } , { 43 , 0 , TARGET_STRING (
"model/referee" ) , TARGET_STRING ( "" ) , 17 , 1 , 0 , 0 , 2 } , { 44 , 0 ,
TARGET_STRING ( "model/light_pattern_switch" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 2 } , { 45 , 0 , TARGET_STRING ( "model/Collector A/Model" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 46 , 0 , TARGET_STRING (
"model/Collector A/Model" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , {
47 , 0 , TARGET_STRING ( "model/Collector A/Model" ) , TARGET_STRING ( "" ) ,
2 , 0 , 0 , 0 , 0 } , { 48 , 0 , TARGET_STRING ( "model/Collector A/Model" )
, TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 49 , 0 , TARGET_STRING (
"model/Collector A/Model" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , {
50 , 0 , TARGET_STRING ( "model/Collector A/Model" ) , TARGET_STRING ( "" ) ,
5 , 0 , 0 , 0 , 0 } , { 51 , 0 , TARGET_STRING ( "model/Collector A/Model" )
, TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0 } , { 52 , 0 , TARGET_STRING (
"model/Collector A/random_x_destination" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 3 } , { 53 , 0 , TARGET_STRING (
"model/Collector A/random_y_destination" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 3 } , { 54 , 0 , TARGET_STRING ( "model/Collector B/Collector B" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 55 , 0 , TARGET_STRING (
"model/Collector B/Collector B" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0
} , { 56 , 0 , TARGET_STRING ( "model/Collector B/Collector B" ) ,
TARGET_STRING ( "" ) , 2 , 0 , 0 , 0 , 0 } , { 57 , 0 , TARGET_STRING (
"model/Collector B/Collector B" ) , TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0
} , { 58 , 0 , TARGET_STRING ( "model/Collector B/Collector B" ) ,
TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , { 59 , 0 , TARGET_STRING (
"model/Collector B/Collector B" ) , TARGET_STRING ( "" ) , 5 , 0 , 0 , 0 , 0
} , { 60 , 0 , TARGET_STRING ( "model/Collector B/Collector B" ) ,
TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0 } , { 61 , 0 , TARGET_STRING (
"model/Collector B/Multiply" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } ,
{ 62 , 0 , TARGET_STRING ( "model/Collector B/Multiply1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 3 } , { 63 , 18 , TARGET_STRING (
"model/Scout A/send_scout_pos_every_1s " ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 64 , 18 , TARGET_STRING (
"model/Scout A/send_scout_pos_every_1s " ) , TARGET_STRING ( "" ) , 1 , 0 , 0
, 0 , 0 } , { 65 , 0 , TARGET_STRING ( "model/Scout A/Model1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 66 , 0 , TARGET_STRING (
"model/Scout A/Model1" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 67
, 0 , TARGET_STRING ( "model/Scout A/Model1" ) , TARGET_STRING ( "" ) , 2 , 0
, 0 , 0 , 0 } , { 68 , 0 , TARGET_STRING ( "model/Scout A/Model1" ) ,
TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 69 , 0 , TARGET_STRING (
"model/Scout A/Model1" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , { 70
, 0 , TARGET_STRING ( "model/Scout A/Model1" ) , TARGET_STRING ( "" ) , 5 , 0
, 0 , 0 , 0 } , { 71 , 0 , TARGET_STRING ( "model/Scout A/Model1" ) ,
TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0 } , { 72 , 0 , TARGET_STRING (
"model/Scout A/Multiply" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } , {
73 , 0 , TARGET_STRING ( "model/Scout A/Multiply1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 3 } , { 74 , 0 , TARGET_STRING ( "model/Scout B/Model" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 75 , 0 , TARGET_STRING (
"model/Scout B/Model" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 76 ,
0 , TARGET_STRING ( "model/Scout B/Model" ) , TARGET_STRING ( "" ) , 2 , 0 ,
0 , 0 , 0 } , { 77 , 0 , TARGET_STRING ( "model/Scout B/Model" ) ,
TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 78 , 0 , TARGET_STRING (
"model/Scout B/Model" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , { 79 ,
0 , TARGET_STRING ( "model/Scout B/Model" ) , TARGET_STRING ( "" ) , 5 , 0 ,
0 , 0 , 0 } , { 80 , 0 , TARGET_STRING ( "model/Scout B/Model" ) ,
TARGET_STRING ( "" ) , 6 , 0 , 0 , 0 , 0 } , { 81 , 0 , TARGET_STRING (
"model/Scout B/Multiply" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } , {
82 , 0 , TARGET_STRING ( "model/Scout B/Multiply1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 3 } , { 83 , 0 , TARGET_STRING (
"model/random_referee_loss/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 84 , 0 , TARGET_STRING (
"model/random_referee_loss/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 85 , 0 , TARGET_STRING (
"model/random_referee_loss1/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 86 , 0 , TARGET_STRING (
"model/random_referee_loss1/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 87 , 0 , TARGET_STRING (
"model/random_referee_loss2/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 88 , 0 , TARGET_STRING (
"model/random_referee_loss2/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 89 , 0 , TARGET_STRING (
"model/random_referee_loss3/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 90 , 0 , TARGET_STRING (
"model/random_referee_loss3/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 91 , 0 , TARGET_STRING (
"model/random_referee_loss4/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 92 , 0 , TARGET_STRING (
"model/random_referee_loss4/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 93 , 0 , TARGET_STRING (
"model/random_referee_loss5/Switch" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 94 , 0 , TARGET_STRING (
"model/random_referee_loss5/Uniform Random Number" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 1 } , { 95 , 0 , TARGET_STRING (
"model/Collector A/Send Estimated Positions/Rate Transition" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 4 } , { 96 , 0 , TARGET_STRING (
"model/Collector A/Send Estimated Positions/Rate Transition1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 4 } , { 97 , 0 , TARGET_STRING (
"model/Collector A/Send Estimated Positions/Rate Transition2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 4 } , { 98 , 0 , TARGET_STRING (
"model/Collector A/Send Harvest Positions/Rate Transition3" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 5 } , { 99 , 0 , TARGET_STRING (
"model/Collector A/Send Harvest Positions/Rate Transition4" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 5 } , { 100 , 1 , TARGET_STRING (
"model/Collector A/hold_value/Subsystem" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 101 , 0 , TARGET_STRING (
"model/Collector A/hold_value/Switch1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 102 , 2 , TARGET_STRING (
"model/Collector A/hold_value1/Subsystem" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 103 , 0 , TARGET_STRING (
"model/Collector A/hold_value1/Switch1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 104 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Abs" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 105 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Abs1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 106 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Abs2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 107 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 108 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 109 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 110 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Multiply" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 111 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Multiply1" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 112 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Multiply2" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 113 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Multiply3" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 114 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Multiply4" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 115 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Add" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 116 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Add1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 117 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Add2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 118 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Sum1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 119 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 120 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 121 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 122 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch3" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 123 , 0 , TARGET_STRING (
"model/Collector B/Send Harvest Positions/Rate Transition3" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 5 } , { 124 , 0 , TARGET_STRING (
"model/Collector B/Send Harvest Positions/Rate Transition4" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 5 } , { 125 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Abs" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 126 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Abs1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 127 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Abs2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 128 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 129 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 130 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 2 } , { 131 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Multiply" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 132 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Multiply1" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 133 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Multiply2" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 134 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Multiply3" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 135 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Multiply4" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 136 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Add" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 137 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Add1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 138 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Add2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 139 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Sum1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 140 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 141 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 142 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 143 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch3" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 144 , 0 , TARGET_STRING (
"model/Scout A/Send Estimated Positions/Rate Transition5" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 4 } , { 145 , 0 , TARGET_STRING (
"model/Scout A/Send Estimated Positions/Rate Transition6" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 4 } , { 146 , 0 , TARGET_STRING (
"model/Scout A/Send Estimated Positions/Rate Transition7" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 4 } , { 147 , 0 , TARGET_STRING (
"model/Scout A/communication_timer/Memory" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 148 , 0 , TARGET_STRING (
"model/Scout A/communication_timer/Relational Operator" ) , TARGET_STRING (
"" ) , 0 , 1 , 0 , 0 , 2 } , { 149 , 0 , TARGET_STRING (
"model/Scout A/communication_timer/Floor" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 150 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 151 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Abs1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 152 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Abs2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 153 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 154 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 155 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 156 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Multiply" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 157 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Multiply1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 158 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Multiply2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 159 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Multiply3" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 160 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Multiply4" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 161 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Add" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 162 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Add1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 163 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Add2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 164 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Sum1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 165 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 166 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 167 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 168 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch3" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 169 , 18 , TARGET_STRING (
"model/Scout A/send_scout_pos_every_1s /Switch" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 170 , 18 , TARGET_STRING (
"model/Scout A/send_scout_pos_every_1s /Switch1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 171 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 172 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Abs1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 173 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Abs2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 174 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 175 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 176 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 177 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Multiply" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 178 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Multiply1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 179 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Multiply2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 180 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Multiply3" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 181 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Multiply4" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 182 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Add" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 183 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Add1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 184 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Add2" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 185 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Sum1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 186 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 187 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 188 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 189 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch3" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 190 , 1 , TARGET_STRING (
"model/Collector A/hold_value/Subsystem/Input" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 1 } , { 191 , 2 , TARGET_STRING (
"model/Collector A/hold_value1/Subsystem/Input" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 1 } , { 192 , 3 , TARGET_STRING (
 "model/Collector A/referee_update_handler/1 if positive, 2 if negative/Subsystem"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 193 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/1 if positive, 2 if negative/Switch1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 194 , 4 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 195 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 196 , 5 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 197 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 198 , 6 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 199 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 200 , 7 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 201 , 0 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 202 , 8 , TARGET_STRING (
 "model/Collector B/referee_update_handler/1 if positive, 2 if negative/Subsystem"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 203 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/1 if positive, 2 if negative/Switch1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 204 , 9 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 205 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 206 , 10 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 207 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 208 , 11 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 209 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 210 , 12 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Subsystem" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 211 , 0 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 212 , 13 , TARGET_STRING (
"model/Scout A/referee_update_handler/1 if positive, 2 if negative/Subsystem"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 213 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/1 if positive, 2 if negative/Switch1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 214 , 14 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 215 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 216 , 15 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 217 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 218 , 16 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 219 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 220 , 17 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 221 , 0 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 222 , 19 , TARGET_STRING (
"model/Scout B/referee_update_handler/1 if positive, 2 if negative/Subsystem"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 223 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/1 if positive, 2 if negative/Switch1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 224 , 20 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 225 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 226 , 21 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 227 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 228 , 22 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 229 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 230 , 23 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Subsystem" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 231 , 0 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 232 , 3 , TARGET_STRING (
 "model/Collector A/referee_update_handler/1 if positive, 2 if negative/Subsystem/Input"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 233 , 4 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 234 , 5 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 235 , 6 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 236 , 7 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 237 , 8 , TARGET_STRING (
 "model/Collector B/referee_update_handler/1 if positive, 2 if negative/Subsystem/Input"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 238 , 9 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 239 , 10 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 240 , 11 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 241 , 12 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 242 , 13 , TARGET_STRING (
 "model/Scout A/referee_update_handler/1 if positive, 2 if negative/Subsystem/Input"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 243 , 14 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 244 , 15 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 245 , 16 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 246 , 17 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 247 , 19 , TARGET_STRING (
 "model/Scout B/referee_update_handler/1 if positive, 2 if negative/Subsystem/Input"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 248 , 20 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 249 , 21 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 250 , 22 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 251 , 23 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Subsystem/Input" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 252 , TARGET_STRING ( "model/Constant10" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 253 , TARGET_STRING (
"model/Constant11" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 254 ,
TARGET_STRING ( "model/Constant12" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0
} , { 255 , TARGET_STRING ( "model/Constant13" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 256 , TARGET_STRING ( "model/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 257 , TARGET_STRING ( "model/Constant5" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 258 , TARGET_STRING (
"model/Constant7" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 259 ,
TARGET_STRING ( "model/Constant8" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 }
, { 260 , TARGET_STRING ( "model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 261 , TARGET_STRING ( "model/pattern" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 262 , TARGET_STRING ( "model/random" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 263 , TARGET_STRING (
"model/light_pattern_switch" ) , TARGET_STRING ( "CurrentSetting" ) , 2 , 0 ,
0 } , { 264 , TARGET_STRING ( "model/Collector A/IC" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 265 , TARGET_STRING ( "model/Collector A/IC1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 266 , TARGET_STRING (
"model/Collector A/IC2" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 267 ,
TARGET_STRING ( "model/Collector A/random_x_destination" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 268 , TARGET_STRING (
"model/Collector A/random_x_destination" ) , TARGET_STRING ( "Maximum" ) , 0
, 0 , 0 } , { 269 , TARGET_STRING ( "model/Collector A/random_x_destination"
) , TARGET_STRING ( "Seed" ) , 0 , 0 , 0 } , { 270 , TARGET_STRING (
"model/Collector A/random_y_destination" ) , TARGET_STRING ( "Minimum" ) , 0
, 0 , 0 } , { 271 , TARGET_STRING ( "model/Collector A/random_y_destination"
) , TARGET_STRING ( "Maximum" ) , 0 , 0 , 0 } , { 272 , TARGET_STRING (
"model/Collector A/random_y_destination" ) , TARGET_STRING ( "Seed" ) , 0 , 0
, 0 } , { 273 , TARGET_STRING ( "model/Collector B/IC" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 274 , TARGET_STRING ( "model/Collector B/IC1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 275 , TARGET_STRING (
"model/Collector B/IC2" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 276 ,
TARGET_STRING ( "model/Collector B/random_x_destination" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 277 , TARGET_STRING (
"model/Collector B/random_x_destination" ) , TARGET_STRING ( "Maximum" ) , 0
, 0 , 0 } , { 278 , TARGET_STRING ( "model/Collector B/random_x_destination"
) , TARGET_STRING ( "Seed" ) , 0 , 0 , 0 } , { 279 , TARGET_STRING (
"model/Collector B/random_y_destination" ) , TARGET_STRING ( "Minimum" ) , 0
, 0 , 0 } , { 280 , TARGET_STRING ( "model/Collector B/random_y_destination"
) , TARGET_STRING ( "Maximum" ) , 0 , 0 , 0 } , { 281 , TARGET_STRING (
"model/Collector B/random_y_destination" ) , TARGET_STRING ( "Seed" ) , 0 , 0
, 0 } , { 282 , TARGET_STRING ( "model/Scout A/Constant" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 283 , TARGET_STRING (
"model/Scout A/random_x_destination" ) , TARGET_STRING ( "Minimum" ) , 0 , 0
, 0 } , { 284 , TARGET_STRING ( "model/Scout A/random_x_destination" ) ,
TARGET_STRING ( "Maximum" ) , 0 , 0 , 0 } , { 285 , TARGET_STRING (
"model/Scout A/random_x_destination" ) , TARGET_STRING ( "Seed" ) , 0 , 0 , 0
} , { 286 , TARGET_STRING ( "model/Scout A/random_y_destination" ) ,
TARGET_STRING ( "Minimum" ) , 0 , 0 , 0 } , { 287 , TARGET_STRING (
"model/Scout A/random_y_destination" ) , TARGET_STRING ( "Maximum" ) , 0 , 0
, 0 } , { 288 , TARGET_STRING ( "model/Scout A/random_y_destination" ) ,
TARGET_STRING ( "Seed" ) , 0 , 0 , 0 } , { 289 , TARGET_STRING (
"model/Scout B/IC" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 290 ,
TARGET_STRING ( "model/Scout B/IC1" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0
} , { 291 , TARGET_STRING ( "model/Scout B/IC2" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 292 , TARGET_STRING ( "model/Scout B/random_x_destination"
) , TARGET_STRING ( "Minimum" ) , 0 , 0 , 0 } , { 293 , TARGET_STRING (
"model/Scout B/random_x_destination" ) , TARGET_STRING ( "Maximum" ) , 0 , 0
, 0 } , { 294 , TARGET_STRING ( "model/Scout B/random_x_destination" ) ,
TARGET_STRING ( "Seed" ) , 0 , 0 , 0 } , { 295 , TARGET_STRING (
"model/Scout B/random_y_destination" ) , TARGET_STRING ( "Minimum" ) , 0 , 0
, 0 } , { 296 , TARGET_STRING ( "model/Scout B/random_y_destination" ) ,
TARGET_STRING ( "Maximum" ) , 0 , 0 , 0 } , { 297 , TARGET_STRING (
"model/Scout B/random_y_destination" ) , TARGET_STRING ( "Seed" ) , 0 , 0 , 0
} , { 298 , TARGET_STRING ( "model/random_referee_loss/Constant13" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 299 , TARGET_STRING (
"model/random_referee_loss/Switch" ) , TARGET_STRING ( "Threshold" ) , 0 , 0
, 0 } , { 300 , TARGET_STRING (
"model/random_referee_loss/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 301 , TARGET_STRING (
"model/random_referee_loss/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 302 , TARGET_STRING (
"model/random_referee_loss/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 303 , TARGET_STRING (
"model/random_referee_loss1/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 304 , TARGET_STRING ( "model/random_referee_loss1/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 305 , TARGET_STRING (
"model/random_referee_loss1/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 306 , TARGET_STRING (
"model/random_referee_loss1/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 307 , TARGET_STRING (
"model/random_referee_loss1/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 308 , TARGET_STRING (
"model/random_referee_loss2/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 309 , TARGET_STRING ( "model/random_referee_loss2/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 310 , TARGET_STRING (
"model/random_referee_loss2/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 311 , TARGET_STRING (
"model/random_referee_loss2/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 312 , TARGET_STRING (
"model/random_referee_loss2/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 313 , TARGET_STRING (
"model/random_referee_loss3/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 314 , TARGET_STRING ( "model/random_referee_loss3/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 315 , TARGET_STRING (
"model/random_referee_loss3/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 316 , TARGET_STRING (
"model/random_referee_loss3/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 317 , TARGET_STRING (
"model/random_referee_loss3/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 318 , TARGET_STRING (
"model/random_referee_loss4/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 319 , TARGET_STRING ( "model/random_referee_loss4/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 320 , TARGET_STRING (
"model/random_referee_loss4/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 321 , TARGET_STRING (
"model/random_referee_loss4/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 322 , TARGET_STRING (
"model/random_referee_loss4/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 323 , TARGET_STRING (
"model/random_referee_loss5/Constant13" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 324 , TARGET_STRING ( "model/random_referee_loss5/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 325 , TARGET_STRING (
"model/random_referee_loss5/Uniform Random Number" ) , TARGET_STRING (
"Minimum" ) , 0 , 0 , 0 } , { 326 , TARGET_STRING (
"model/random_referee_loss5/Uniform Random Number" ) , TARGET_STRING (
"Maximum" ) , 0 , 0 , 0 } , { 327 , TARGET_STRING (
"model/random_referee_loss5/Uniform Random Number" ) , TARGET_STRING ( "Seed"
) , 0 , 0 , 0 } , { 328 , TARGET_STRING (
"model/Collector A/hold_value/Constant" ) , TARGET_STRING ( "Value" ) , 0 , 0
, 0 } , { 329 , TARGET_STRING ( "model/Collector A/hold_value/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 330 , TARGET_STRING (
"model/Collector A/hold_value/Switch1" ) , TARGET_STRING ( "Threshold" ) , 0
, 0 , 0 } , { 331 , TARGET_STRING ( "model/Collector A/hold_value1/Constant"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 332 , TARGET_STRING (
"model/Collector A/hold_value1/Constant9" ) , TARGET_STRING ( "Value" ) , 0 ,
0 , 0 } , { 333 , TARGET_STRING ( "model/Collector A/hold_value1/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 334 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 335 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 336 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant5" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 337 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant6" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 338 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant7" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 339 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant8" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 340 , TARGET_STRING (
"model/Collector A/referee_update_handler/Constant9" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 341 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 342 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 343 , TARGET_STRING (
"model/Collector A/referee_update_handler/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 344 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 345 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch2" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 346 , TARGET_STRING (
"model/Collector A/referee_update_handler/Switch3" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 347 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 348 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 349 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant5" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 350 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant6" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 351 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant7" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 352 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant8" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 353 , TARGET_STRING (
"model/Collector B/referee_update_handler/Constant9" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 354 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 355 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 356 , TARGET_STRING (
"model/Collector B/referee_update_handler/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 357 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 358 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch2" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 359 , TARGET_STRING (
"model/Collector B/referee_update_handler/Switch3" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 360 , TARGET_STRING (
"model/Scout A/communication_timer/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 361 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 362 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant4" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 363 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant5" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 364 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant6" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 365 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant7" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 366 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant8" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 367 , TARGET_STRING (
"model/Scout A/referee_update_handler/Constant9" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 368 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 369 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 370 , TARGET_STRING (
"model/Scout A/referee_update_handler/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 371 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 372 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch2" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 373 , TARGET_STRING (
"model/Scout A/referee_update_handler/Switch3" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 374 , TARGET_STRING (
"model/Scout A/send_scout_pos_every_1s /Constant" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 375 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant" ) , TARGET_STRING ( "Value" )
, 0 , 0 , 0 } , { 376 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant4" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 377 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant5" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 378 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant6" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 379 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant7" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 380 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant8" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 381 , TARGET_STRING (
"model/Scout B/referee_update_handler/Constant9" ) , TARGET_STRING ( "Value"
) , 0 , 0 , 0 } , { 382 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 383 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 384 , TARGET_STRING (
"model/Scout B/referee_update_handler/Memory2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 385 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 386 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch2" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 387 , TARGET_STRING (
"model/Scout B/referee_update_handler/Switch3" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 388 , TARGET_STRING (
"model/Collector A/hold_value/Subsystem/Output" ) , TARGET_STRING (
"InitialOutput" ) , 0 , 0 , 0 } , { 389 , TARGET_STRING (
"model/Collector A/hold_value1/Subsystem/Output" ) , TARGET_STRING (
"InitialOutput" ) , 0 , 0 , 0 } , { 390 , TARGET_STRING (
"model/Collector A/referee_update_handler/1 if positive, 2 if negative/Constant"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 391 , TARGET_STRING (
 "model/Collector A/referee_update_handler/1 if positive, 2 if negative/Constant9"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 392 , TARGET_STRING (
"model/Collector A/referee_update_handler/1 if positive, 2 if negative/Switch1"
) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 393 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 394 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 395 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 396 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 397 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 398 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 399 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 400 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 401 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 402 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 403 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 404 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 405 , TARGET_STRING (
"model/Collector B/referee_update_handler/1 if positive, 2 if negative/Constant"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 406 , TARGET_STRING (
 "model/Collector B/referee_update_handler/1 if positive, 2 if negative/Constant9"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 407 , TARGET_STRING (
"model/Collector B/referee_update_handler/1 if positive, 2 if negative/Switch1"
) , TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 408 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 409 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 410 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 411 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 412 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 413 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 414 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 415 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 416 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 417 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 418 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Constant9" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 419 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 420 , TARGET_STRING (
"model/Scout A/referee_update_handler/1 if positive, 2 if negative/Constant"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 421 , TARGET_STRING (
"model/Scout A/referee_update_handler/1 if positive, 2 if negative/Constant9"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 422 , TARGET_STRING (
"model/Scout A/referee_update_handler/1 if positive, 2 if negative/Switch1" )
, TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 423 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 424 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 425 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 426 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 427 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 428 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 429 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Constant1" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 430 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 431 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 432 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Constant1" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 433 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 434 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 435 , TARGET_STRING (
"model/Scout B/referee_update_handler/1 if positive, 2 if negative/Constant"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 436 , TARGET_STRING (
"model/Scout B/referee_update_handler/1 if positive, 2 if negative/Constant9"
) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 437 , TARGET_STRING (
"model/Scout B/referee_update_handler/1 if positive, 2 if negative/Switch1" )
, TARGET_STRING ( "Threshold" ) , 0 , 0 , 0 } , { 438 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 439 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 440 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 441 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 442 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 443 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 444 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Constant1" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 445 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 446 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 447 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Constant1" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 448 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Constant9" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 449 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Switch1" ) , TARGET_STRING (
"Threshold" ) , 0 , 0 , 0 } , { 450 , TARGET_STRING (
 "model/Collector A/referee_update_handler/1 if positive, 2 if negative/Subsystem/Output"
) , TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 451 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem1/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 452 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem2/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 453 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem3/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 454 , TARGET_STRING (
"model/Collector A/referee_update_handler/Subsystem4/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 455 , TARGET_STRING (
 "model/Collector B/referee_update_handler/1 if positive, 2 if negative/Subsystem/Output"
) , TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 456 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem1/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 457 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem2/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 458 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem3/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 459 , TARGET_STRING (
"model/Collector B/referee_update_handler/Subsystem4/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 460 , TARGET_STRING (
 "model/Scout A/referee_update_handler/1 if positive, 2 if negative/Subsystem/Output"
) , TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 461 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem1/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 462 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem2/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 463 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem3/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 464 , TARGET_STRING (
"model/Scout A/referee_update_handler/Subsystem4/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 465 , TARGET_STRING (
 "model/Scout B/referee_update_handler/1 if positive, 2 if negative/Subsystem/Output"
) , TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 466 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem1/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 467 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem2/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 468 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem3/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 469 , TARGET_STRING (
"model/Scout B/referee_update_handler/Subsystem4/Subsystem/Output" ) ,
TARGET_STRING ( "InitialOutput" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 } } ; static const rtwCAPI_ModelParameters rtModelParameters [ ] =
{ { 470 , TARGET_STRING ( "collision_detection_distance" ) , 0 , 0 , 0 } , {
471 , TARGET_STRING ( "push_force" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , 0 , 0 ,
0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & lemdyvfalhs . niif3usptd , &
lemdyvfalhs . cf3wgy2zqk , & lemdyvfalhs . mszbqrncxw , & lemdyvfalhs .
p5rd2lyc3a , & lemdyvfalhs . jikjkxqm5d , & lemdyvfalhs . fqueftcfuf , &
lemdyvfalhs . nodxfcp40m , & lemdyvfalhs . ngl5ursdp5 , & lemdyvfalhs .
kpxkxchg4l , & lemdyvfalhs . bmkqgyuy02 , & lemdyvfalhs . ob04arcrak , &
lemdyvfalhs . ceigekm0he , & lemdyvfalhs . ivfx3vycfj , & lemdyvfalhs .
j2obp2vdbm , & lemdyvfalhs . jg24yuqrlf , & lemdyvfalhs . n1sni4qgda , &
lemdyvfalhs . axkn0tj3kk , & lemdyvfalhs . clbwajughp , & lemdyvfalhs .
imc11ixkro , & lemdyvfalhs . lcu5p032hu , & lemdyvfalhs . flfcvs24j3 , &
lemdyvfalhs . imqx44z1y2 , & lemdyvfalhs . pmsvvrsozf , & lemdyvfalhs .
p53fcq012l , & lemdyvfalhs . pxdpmfdlbp , & lemdyvfalhs . ksfajmgxst , &
lemdyvfalhs . mx1amll0zz , & lemdyvfalhs . jcjxswchz2 , & lemdyvfalhs .
b4csihzanf , & lemdyvfalhs . gt3kseiesc , & lemdyvfalhs . ejfmbnlbtp , &
lemdyvfalhs . mnfd3vgtyn , & lemdyvfalhs . avftxcinmd , & lemdyvfalhs .
hefv5fowan , & lemdyvfalhs . dxs5uxsq1f , & lemdyvfalhs . f4veiiqqom , &
lemdyvfalhs . klpnkc3lij , & lemdyvfalhs . l3ycykxga3 , & lemdyvfalhs .
eqx2aoxtn5 , & lemdyvfalhs . oi3u13hlpw , & lemdyvfalhs . hqbuqvvxe5 , &
lemdyvfalhs . aly0nl4jy5 , & lemdyvfalhs . ae1szi3am4 , & lemdyvfalhs .
m1azb0d0ot , & lemdyvfalhs . amawxeyk2i , & lemdyvfalhs . hafzobe53s , &
lemdyvfalhs . fpynlmxbjm , & lemdyvfalhs . ajou24crmh , & lemdyvfalhs .
izg5xjzxp0 , & lemdyvfalhs . ptfiptqj5a , & lemdyvfalhs . g4ltns0hif , &
lemdyvfalhs . mozax3lynk , & lemdyvfalhs . dna0tmvu4j , & lemdyvfalhs .
jxwwsn1eza , & lemdyvfalhs . ihvwlbvzka , & lemdyvfalhs . kzfplnwos4 , &
lemdyvfalhs . cjfxu2cgxt , & lemdyvfalhs . fmuhs2dz41 , & lemdyvfalhs .
lensyzirgi , & lemdyvfalhs . i24yw4mbom , & lemdyvfalhs . nkpjbarrr0 , &
lemdyvfalhs . bh1kll0gtc , & lemdyvfalhs . eqs3l5srls , & lemdyvfalhs .
ifglumd1vr , & lemdyvfalhs . pmhf3wvapt , & lemdyvfalhs . kgw0amexsf , &
lemdyvfalhs . lnkxgp0qhe , & lemdyvfalhs . jnnqtz1wy1 , & lemdyvfalhs .
aot3rslnli , & lemdyvfalhs . irhivy0rii , & lemdyvfalhs . bc5e4hvxwh , &
lemdyvfalhs . jtscbp5h3y , & lemdyvfalhs . lz4q5mssw3 , & lemdyvfalhs .
foioshrzjd , & lemdyvfalhs . fgumimiiqn , & lemdyvfalhs . fpd0lgtezn , &
lemdyvfalhs . g0ollzpsdy , & lemdyvfalhs . gwcyios52e , & lemdyvfalhs .
f4fh0ct45e , & lemdyvfalhs . ocddn3l0tx , & lemdyvfalhs . k3q51v2rm5 , &
lemdyvfalhs . braz0mphnk , & lemdyvfalhs . eklrysk5eo , & lemdyvfalhs .
p3xvqs243l , & lemdyvfalhs . kdwduyqgbt , & lemdyvfalhs . bmxsgsmrv3 , &
lemdyvfalhs . bqttxzaoip , & lemdyvfalhs . fawcbqofbl , & lemdyvfalhs .
c42vzrsoa4 , & lemdyvfalhs . lpn35yy1gc , & lemdyvfalhs . mko2h50i0e , &
lemdyvfalhs . je1a5dspy2 , & lemdyvfalhs . kvzqlrq12h , & lemdyvfalhs .
nejcie2kgo , & lemdyvfalhs . eg4x542g0m , & lemdyvfalhs . c1dfijug4k , &
lemdyvfalhs . mwfc1bfdzw , & lemdyvfalhs . hko3vhqkfm , & lemdyvfalhs .
apexlhdnec , & lemdyvfalhs . aohqmjjcro , & lemdyvfalhs . l4nwcjxgbmr .
pbx0mdxumm , & lemdyvfalhs . bksh4hybza , & lemdyvfalhs . kbzrijfb2o .
pbx0mdxumm , & lemdyvfalhs . kxkwmyn4te , & lemdyvfalhs . pf0s5ndbob , &
lemdyvfalhs . jhryf4edf5 , & lemdyvfalhs . gbl1hdv1ob , & lemdyvfalhs .
fn5ekxq1f1 , & lemdyvfalhs . oxyms50csp , & lemdyvfalhs . akqigye0d2 , &
lemdyvfalhs . pibu2pfiet , & lemdyvfalhs . fnx0uk5nyl , & lemdyvfalhs .
eoaow3o32z , & lemdyvfalhs . hanpj1yii4 , & lemdyvfalhs . obqqvm1rdw , &
lemdyvfalhs . fbyn4xsxtz , & lemdyvfalhs . n0hp4zagjv , & lemdyvfalhs .
jvbwg00o4c , & lemdyvfalhs . bkbjb1as1y , & lemdyvfalhs . h1vbkdhkzd , &
lemdyvfalhs . ilcxsu533x , & lemdyvfalhs . lgdbztnwrq , & lemdyvfalhs .
d1pzbumep2 , & lemdyvfalhs . aciak3h2dg , & lemdyvfalhs . ov1li0kvq5 , &
lemdyvfalhs . myryoqjss3 , & lemdyvfalhs . o3oupxvkog , & lemdyvfalhs .
agsamxjw3z , & lemdyvfalhs . jp3fqgejke , & lemdyvfalhs . evwcvo5bkm , &
lemdyvfalhs . iun5ct5baq , & lemdyvfalhs . mlbdwmzp3m , & lemdyvfalhs .
n0p4nmln4q , & lemdyvfalhs . h04isb3fq2 , & lemdyvfalhs . e1andkbfid , &
lemdyvfalhs . gtt1osg1f1 , & lemdyvfalhs . jqlmorfuba , & lemdyvfalhs .
hcmy1jabtw , & lemdyvfalhs . mfnpex3gsr , & lemdyvfalhs . gbu5gikuvw , &
lemdyvfalhs . pu32vkhlie , & lemdyvfalhs . emo55yzw2r , & lemdyvfalhs .
ez4ky3mfnm , & lemdyvfalhs . peeeqojqac , & lemdyvfalhs . cjzme0drrn , &
lemdyvfalhs . fgzsligzri , & lemdyvfalhs . i5zahmuwcw , & lemdyvfalhs .
oi0cnu5mro , & lemdyvfalhs . k3l3s1o3wj , & lemdyvfalhs . mzg13b5ygf , &
lemdyvfalhs . lt55ikl1yb , & lemdyvfalhs . h1vs0aa35r , & lemdyvfalhs .
pfqp1ddl2k , & lemdyvfalhs . bkptnrsq23 , & lemdyvfalhs . h44lhptqp3 , &
lemdyvfalhs . alshwojygz , & lemdyvfalhs . klsq3whhyq , & lemdyvfalhs .
pn5amc2d2d , & lemdyvfalhs . ff4mphjk34 , & lemdyvfalhs . o2gwyfz2ag , &
lemdyvfalhs . ewn1qhxrdv , & lemdyvfalhs . lcgby2b3g2 , & lemdyvfalhs .
oigyvmvs1s , & lemdyvfalhs . okkjvum3js , & lemdyvfalhs . ofzi3mvxlc , &
lemdyvfalhs . cthg5rqel1 , & lemdyvfalhs . lgufrbtkr2 , & lemdyvfalhs .
fncdv5wdjq , & lemdyvfalhs . hd2bjuef5v , & lemdyvfalhs . ifglumd1vr , &
lemdyvfalhs . pmhf3wvapt , & lemdyvfalhs . j5l4sqyobi , & lemdyvfalhs .
huaria4chy , & lemdyvfalhs . ewmrkcguh4 , & lemdyvfalhs . boesjlevad , &
lemdyvfalhs . apovva0uhx , & lemdyvfalhs . ep35d2ihe4 , & lemdyvfalhs .
ebjz1pdibk , & lemdyvfalhs . kcrpted3qh , & lemdyvfalhs . mnlyiwbsiy , &
lemdyvfalhs . lx1v2ap3mi , & lemdyvfalhs . ayjn11ju0w , & lemdyvfalhs .
kr5qwmuyi1 , & lemdyvfalhs . ha2gy1cf2e , & lemdyvfalhs . bb0kqphudk , &
lemdyvfalhs . mm30op0rpl , & lemdyvfalhs . kjgiaop3tk , & lemdyvfalhs .
e3kmye2ups , & lemdyvfalhs . iwvwrqn5jk , & lemdyvfalhs . afhy1i1qj1 , &
lemdyvfalhs . l4nwcjxgbmr . pbx0mdxumm , & lemdyvfalhs . kbzrijfb2o .
pbx0mdxumm , & lemdyvfalhs . btispofq2nb . dwpkm32nka , & lemdyvfalhs .
mktiqey2b5 , & lemdyvfalhs . hybb0kqc4xm . dxyv3wxlza , & lemdyvfalhs .
oyxqk3lhvc , & lemdyvfalhs . kxn0m3zbec . dwpkm32nka , & lemdyvfalhs .
j1u05n2him , & lemdyvfalhs . oxitfjhj0e . dxyv3wxlza , & lemdyvfalhs .
gwyqdebgln , & lemdyvfalhs . hguo0kwh4p . dxyv3wxlza , & lemdyvfalhs .
m3zmrf0rvl , & lemdyvfalhs . an5txqujzc . dwpkm32nka , & lemdyvfalhs .
ienss5zvmv , & lemdyvfalhs . avpfi51xqj . dxyv3wxlza , & lemdyvfalhs .
lx5swuzcbh , & lemdyvfalhs . g4s4twk2b2 . dwpkm32nka , & lemdyvfalhs .
g4d2idhg40 , & lemdyvfalhs . cecxmc0h1i . dxyv3wxlza , & lemdyvfalhs .
ob4gj301px , & lemdyvfalhs . kra4na34gj . dxyv3wxlza , & lemdyvfalhs .
etml3z0rpj , & lemdyvfalhs . kinerpas1h . dwpkm32nka , & lemdyvfalhs .
f5n1njx0jw , & lemdyvfalhs . pkngnbryvt . dxyv3wxlza , & lemdyvfalhs .
kukqniznpc , & lemdyvfalhs . lsd4zxxavz . dwpkm32nka , & lemdyvfalhs .
icl5evgdd3 , & lemdyvfalhs . ficyystmwp . dxyv3wxlza , & lemdyvfalhs .
cbwv340ptd , & lemdyvfalhs . lvs4tuvo5q . dxyv3wxlza , & lemdyvfalhs .
d4vij2rcmk , & lemdyvfalhs . ma24ilhkjx . dwpkm32nka , & lemdyvfalhs .
kfle00trtg , & lemdyvfalhs . kmz50yvsje . dxyv3wxlza , & lemdyvfalhs .
lz3qbaqq5i , & lemdyvfalhs . nzg4g3a3cq . dwpkm32nka , & lemdyvfalhs .
lf4hktw4eg , & lemdyvfalhs . p4qjdvlwyg . dxyv3wxlza , & lemdyvfalhs .
l0m5sgndod , & lemdyvfalhs . iclkdei2xh . dxyv3wxlza , & lemdyvfalhs .
nizbijxigg , & lemdyvfalhs . btispofq2nb . dwpkm32nka , & lemdyvfalhs .
hybb0kqc4xm . dxyv3wxlza , & lemdyvfalhs . kxn0m3zbec . dwpkm32nka , &
lemdyvfalhs . oxitfjhj0e . dxyv3wxlza , & lemdyvfalhs . hguo0kwh4p .
dxyv3wxlza , & lemdyvfalhs . an5txqujzc . dwpkm32nka , & lemdyvfalhs .
avpfi51xqj . dxyv3wxlza , & lemdyvfalhs . g4s4twk2b2 . dwpkm32nka , &
lemdyvfalhs . cecxmc0h1i . dxyv3wxlza , & lemdyvfalhs . kra4na34gj .
dxyv3wxlza , & lemdyvfalhs . kinerpas1h . dwpkm32nka , & lemdyvfalhs .
pkngnbryvt . dxyv3wxlza , & lemdyvfalhs . lsd4zxxavz . dwpkm32nka , &
lemdyvfalhs . ficyystmwp . dxyv3wxlza , & lemdyvfalhs . lvs4tuvo5q .
dxyv3wxlza , & lemdyvfalhs . ma24ilhkjx . dwpkm32nka , & lemdyvfalhs .
kmz50yvsje . dxyv3wxlza , & lemdyvfalhs . nzg4g3a3cq . dwpkm32nka , &
lemdyvfalhs . p4qjdvlwyg . dxyv3wxlza , & lemdyvfalhs . iclkdei2xh .
dxyv3wxlza , & el3s11bva3 . Constant10_Value , & el3s11bva3 .
Constant11_Value , & el3s11bva3 . Constant12_Value , & el3s11bva3 .
Constant13_Value , & el3s11bva3 . Constant3_Value , & el3s11bva3 .
Constant5_Value , & el3s11bva3 . Constant7_Value , & el3s11bva3 .
Constant8_Value , & el3s11bva3 . Constant9_Value , & el3s11bva3 .
pattern_Value , & el3s11bva3 . random_Value , & el3s11bva3 .
light_pattern_switch_CurrentSetting , & el3s11bva3 . IC_Value , & el3s11bva3
. IC1_Value , & el3s11bva3 . IC2_Value , & el3s11bva3 .
random_x_destination_Minimum_fxtuk00qww , & el3s11bva3 .
random_x_destination_Maximum_jv24dihhtt , & el3s11bva3 .
random_x_destination_Seed_a4xosc2llf , & el3s11bva3 .
random_y_destination_Minimum_dergtqofok , & el3s11bva3 .
random_y_destination_Maximum_cttnoi3pwu , & el3s11bva3 .
random_y_destination_Seed_blcncfcags , & el3s11bva3 . IC_Value_j0goa0uerk , &
el3s11bva3 . IC1_Value_ny1yfk1mio , & el3s11bva3 . IC2_Value_dtciakshru , &
el3s11bva3 . random_x_destination_Minimum_oaup3ii1l5 , & el3s11bva3 .
random_x_destination_Maximum_p1st3nyrun , & el3s11bva3 .
random_x_destination_Seed_byzwkqj0yd , & el3s11bva3 .
random_y_destination_Minimum_aarhjqxx0j , & el3s11bva3 .
random_y_destination_Maximum_bmfxifldi0 , & el3s11bva3 .
random_y_destination_Seed_oo4c5wzgp2 , & el3s11bva3 .
Constant_Value_ba2qae5xn0 , & el3s11bva3 . random_x_destination_Minimum , &
el3s11bva3 . random_x_destination_Maximum , & el3s11bva3 .
random_x_destination_Seed , & el3s11bva3 . random_y_destination_Minimum , &
el3s11bva3 . random_y_destination_Maximum , & el3s11bva3 .
random_y_destination_Seed , & el3s11bva3 . IC_Value_po55tmgpac , & el3s11bva3
. IC1_Value_olzkq2isfl , & el3s11bva3 . IC2_Value_b44twnluu2 , & el3s11bva3 .
random_x_destination_Minimum_ky4anpr4m4 , & el3s11bva3 .
random_x_destination_Maximum_gvztpymhe0 , & el3s11bva3 .
random_x_destination_Seed_k2uyi2eyqw , & el3s11bva3 .
random_y_destination_Minimum_bmsqkwvh1b , & el3s11bva3 .
random_y_destination_Maximum_jr3ltzmqnh , & el3s11bva3 .
random_y_destination_Seed_nyfms4qhrl , & el3s11bva3 .
Constant13_Value_elqoepz2mi , & el3s11bva3 . Switch_Threshold , & el3s11bva3
. UniformRandomNumber_Minimum , & el3s11bva3 . UniformRandomNumber_Maximum ,
& el3s11bva3 . UniformRandomNumber_Seed , & el3s11bva3 .
Constant13_Value_eqp0jos5ki , & el3s11bva3 . Switch_Threshold_cdlb2dxcel , &
el3s11bva3 . UniformRandomNumber_Minimum_e22xufda1w , & el3s11bva3 .
UniformRandomNumber_Maximum_duuqdny15m , & el3s11bva3 .
UniformRandomNumber_Seed_djtjrnsnnx , & el3s11bva3 .
Constant13_Value_eeh12bmm2g , & el3s11bva3 . Switch_Threshold_pixetlauxb , &
el3s11bva3 . UniformRandomNumber_Minimum_k02uumxuku , & el3s11bva3 .
UniformRandomNumber_Maximum_nkwogljtyv , & el3s11bva3 .
UniformRandomNumber_Seed_acwzdxvlvk , & el3s11bva3 .
Constant13_Value_np2scmdq2n , & el3s11bva3 . Switch_Threshold_jfs2k2a5tu , &
el3s11bva3 . UniformRandomNumber_Minimum_hi1nli0cfn , & el3s11bva3 .
UniformRandomNumber_Maximum_iqv4e5c3zy , & el3s11bva3 .
UniformRandomNumber_Seed_ndvlssmenu , & el3s11bva3 .
Constant13_Value_lfi4t4n5ry , & el3s11bva3 . Switch_Threshold_a1jo4yhdpi , &
el3s11bva3 . UniformRandomNumber_Minimum_j2apvjkwzu , & el3s11bva3 .
UniformRandomNumber_Maximum_m3cg2u240z , & el3s11bva3 .
UniformRandomNumber_Seed_mgaiufdtyi , & el3s11bva3 .
Constant13_Value_dlaeksitf2 , & el3s11bva3 . Switch_Threshold_axnrqpilx0 , &
el3s11bva3 . UniformRandomNumber_Minimum_os52rgwsjp , & el3s11bva3 .
UniformRandomNumber_Maximum_g5mazrmshc , & el3s11bva3 .
UniformRandomNumber_Seed_csjtlmoxke , & el3s11bva3 .
Constant_Value_lzyuti2pmz , & el3s11bva3 . Constant9_Value_ayk0x4s3me , &
el3s11bva3 . Switch1_Threshold_arl11mzrqd , & el3s11bva3 .
Constant_Value_j2wanecgzn , & el3s11bva3 . Constant9_Value_b2cgcai5jd , &
el3s11bva3 . Switch1_Threshold_gfymtird2p , & el3s11bva3 .
Constant_Value_bveil10atp , & el3s11bva3 . Constant4_Value_hwsd0aq5tk , &
el3s11bva3 . Constant5_Value_czaaoinsnr , & el3s11bva3 .
Constant6_Value_kvbns2yqhv , & el3s11bva3 . Constant7_Value_jrza4df2dq , &
el3s11bva3 . Constant8_Value_hs2smrn0nu , & el3s11bva3 .
Constant9_Value_dbxnqlknqm , & el3s11bva3 .
Memory_InitialCondition_dstumr4sfk , & el3s11bva3 .
Memory1_InitialCondition_ot0ig5ijng , & el3s11bva3 .
Memory2_InitialCondition_i5zi52wwtm , & el3s11bva3 .
Switch1_Threshold_byxnfpd4v3 , & el3s11bva3 . Switch2_Threshold_eflsudq1e1 ,
& el3s11bva3 . Switch3_Threshold_cmbttkg5bu , & el3s11bva3 .
Constant_Value_n4u35q4q5x , & el3s11bva3 . Constant4_Value_dke4qkvy2m , &
el3s11bva3 . Constant5_Value_eyzlfy4z1i , & el3s11bva3 .
Constant6_Value_natwbdlt5l , & el3s11bva3 . Constant7_Value_jejusotfky , &
el3s11bva3 . Constant8_Value_o40j3s04wm , & el3s11bva3 .
Constant9_Value_ikig2ugeov , & el3s11bva3 .
Memory_InitialCondition_f1jkovjs1i , & el3s11bva3 .
Memory1_InitialCondition_h3nsks1jbo , & el3s11bva3 .
Memory2_InitialCondition_mvexewp4sm , & el3s11bva3 .
Switch1_Threshold_megsj2kdn4 , & el3s11bva3 . Switch2_Threshold_abc2i3utpw ,
& el3s11bva3 . Switch3_Threshold_k51oykqbvl , & el3s11bva3 .
Memory_InitialCondition_hu5tzlerqo , & el3s11bva3 . Constant_Value_fvslqcrdl2
, & el3s11bva3 . Constant4_Value , & el3s11bva3 . Constant5_Value_ilynirohi2
, & el3s11bva3 . Constant6_Value , & el3s11bva3 . Constant7_Value_lo1deheetm
, & el3s11bva3 . Constant8_Value_jf2fosnw3b , & el3s11bva3 .
Constant9_Value_jedsy1niga , & el3s11bva3 . Memory_InitialCondition , &
el3s11bva3 . Memory1_InitialCondition , & el3s11bva3 .
Memory2_InitialCondition , & el3s11bva3 . Switch1_Threshold_ggx3yt4m15 , &
el3s11bva3 . Switch2_Threshold , & el3s11bva3 . Switch3_Threshold , &
el3s11bva3 . Constant_Value , & el3s11bva3 . Constant_Value_nryfzuvceq , &
el3s11bva3 . Constant4_Value_kt1d1r1rvu , & el3s11bva3 .
Constant5_Value_prylx2nfvt , & el3s11bva3 . Constant6_Value_iwauxqmbam , &
el3s11bva3 . Constant7_Value_fhb5yuyaap , & el3s11bva3 .
Constant8_Value_knyppzji1e , & el3s11bva3 . Constant9_Value_anz3ryaeir , &
el3s11bva3 . Memory_InitialCondition_et31lrw0fp , & el3s11bva3 .
Memory1_InitialCondition_pmpt1ejnb2 , & el3s11bva3 .
Memory2_InitialCondition_dnlujtrzsv , & el3s11bva3 .
Switch1_Threshold_bk2kua4y4r , & el3s11bva3 . Switch2_Threshold_nkd344stci ,
& el3s11bva3 . Switch3_Threshold_pvimerup5n , & el3s11bva3 . l4nwcjxgbmr .
Output_Y0 , & el3s11bva3 . kbzrijfb2o . Output_Y0 , & el3s11bva3 .
Constant_Value_eajaadlfel , & el3s11bva3 . Constant9_Value_f3b050jkcc , &
el3s11bva3 . Switch1_Threshold_ixuscjd3ov , & el3s11bva3 .
Constant_Value_fnzeo0uh0y , & el3s11bva3 . Constant9_Value_duq42b30jy , &
el3s11bva3 . Switch1_Threshold_lfgrm43eqj , & el3s11bva3 .
Constant_Value_cgsw52jc2f , & el3s11bva3 . Constant9_Value_pxe2jyk15f , &
el3s11bva3 . Switch1_Threshold_dpybs3ruok , & el3s11bva3 .
Constant1_Value_mribuf3piz , & el3s11bva3 . Constant9_Value_eswfotb04n , &
el3s11bva3 . Switch1_Threshold_io1apnmx2q , & el3s11bva3 .
Constant1_Value_hot2ytiafz , & el3s11bva3 . Constant9_Value_cto3nurbbk , &
el3s11bva3 . Switch1_Threshold_mjy4itckve , & el3s11bva3 .
Constant_Value_f2ccrnzbo3 , & el3s11bva3 . Constant9_Value_prk4lzbupc , &
el3s11bva3 . Switch1_Threshold_gv03eoziqu , & el3s11bva3 .
Constant_Value_os30wzhpv5 , & el3s11bva3 . Constant9_Value_gv1ubadb1z , &
el3s11bva3 . Switch1_Threshold_othhfgja33 , & el3s11bva3 .
Constant_Value_m5gwddclk4 , & el3s11bva3 . Constant9_Value_hi3q3xgenf , &
el3s11bva3 . Switch1_Threshold_eskalvmcl5 , & el3s11bva3 .
Constant1_Value_lztbhcwkig , & el3s11bva3 . Constant9_Value_n54nuen2rj , &
el3s11bva3 . Switch1_Threshold_n0njrd3uxy , & el3s11bva3 .
Constant1_Value_np5p343ljn , & el3s11bva3 . Constant9_Value_jo0s0sfoe1 , &
el3s11bva3 . Switch1_Threshold_pmhczo2bql , & el3s11bva3 .
Constant_Value_aar2t1o0pc , & el3s11bva3 . Constant9_Value_hjx2d0ehlo , &
el3s11bva3 . Switch1_Threshold_bkdrcbb4na , & el3s11bva3 .
Constant_Value_ijxldit3zf , & el3s11bva3 . Constant9_Value_gs2rlkywki , &
el3s11bva3 . Switch1_Threshold_leklxdka0k , & el3s11bva3 .
Constant_Value_mtxti12az5 , & el3s11bva3 . Constant9_Value_pjdmuf5qiy , &
el3s11bva3 . Switch1_Threshold_mfp2kd03vv , & el3s11bva3 . Constant1_Value ,
& el3s11bva3 . Constant9_Value_mmv01kox2d , & el3s11bva3 . Switch1_Threshold
, & el3s11bva3 . Constant1_Value_kc3fd44lvc , & el3s11bva3 .
Constant9_Value_mkm1qdjnjo , & el3s11bva3 . Switch1_Threshold_jaddws4amb , &
el3s11bva3 . Constant_Value_dwypnnrzgc , & el3s11bva3 .
Constant9_Value_eqe2lhczxv , & el3s11bva3 . Switch1_Threshold_jiiozq2xmu , &
el3s11bva3 . Constant_Value_lbmdjikwhf , & el3s11bva3 .
Constant9_Value_fajil5otqc , & el3s11bva3 . Switch1_Threshold_cg40gsvgfi , &
el3s11bva3 . Constant_Value_fm5gnbjkca , & el3s11bva3 .
Constant9_Value_oywmk54fo2 , & el3s11bva3 . Switch1_Threshold_agqmymtkki , &
el3s11bva3 . Constant1_Value_ouzfzmlb2y , & el3s11bva3 .
Constant9_Value_gtmy0p2kfs , & el3s11bva3 . Switch1_Threshold_kelisza0pg , &
el3s11bva3 . Constant1_Value_p13umlhyxq , & el3s11bva3 .
Constant9_Value_jgpf1cvdvz , & el3s11bva3 . Switch1_Threshold_n022ebo4n0 , &
el3s11bva3 . btispofq2nb . Output_Y0 , & el3s11bva3 . hybb0kqc4xm . Output_Y0
, & el3s11bva3 . kxn0m3zbec . Output_Y0 , & el3s11bva3 . oxitfjhj0e .
Output_Y0 , & el3s11bva3 . hguo0kwh4p . Output_Y0 , & el3s11bva3 . an5txqujzc
. Output_Y0 , & el3s11bva3 . avpfi51xqj . Output_Y0 , & el3s11bva3 .
g4s4twk2b2 . Output_Y0 , & el3s11bva3 . cecxmc0h1i . Output_Y0 , & el3s11bva3
. kra4na34gj . Output_Y0 , & el3s11bva3 . kinerpas1h . Output_Y0 , &
el3s11bva3 . pkngnbryvt . Output_Y0 , & el3s11bva3 . lsd4zxxavz . Output_Y0 ,
& el3s11bva3 . ficyystmwp . Output_Y0 , & el3s11bva3 . lvs4tuvo5q . Output_Y0
, & el3s11bva3 . ma24ilhkjx . Output_Y0 , & el3s11bva3 . kmz50yvsje .
Output_Y0 , & el3s11bva3 . nzg4g3a3cq . Output_Y0 , & el3s11bva3 . p4qjdvlwyg
. Output_Y0 , & el3s11bva3 . iclkdei2xh . Output_Y0 , &
rtP_collision_detection_distance , & rtP_push_force , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 } , { "unsigned char" , "uint8_T" , 0 , 0 , sizeof ( uint8_T ) , SS_UINT8
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] = {
1 , 1 } ; static const real_T rtcapiStoredFloats [ ] = { 0.0 , 0.1 , 1.0 ,
0.05 , 0.5 } ; static const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) ,
( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 0 ,
0 } , { ( const void * ) & rtcapiStoredFloats [ 1 ] , ( const void * ) &
rtcapiStoredFloats [ 0 ] , 3 , 0 } , { ( const void * ) & rtcapiStoredFloats
[ 0 ] , ( const void * ) & rtcapiStoredFloats [ 2 ] , 1 , 0 } , { ( const
void * ) & rtcapiStoredFloats [ 2 ] , ( const void * ) & rtcapiStoredFloats [
0 ] , 5 , 0 } , { ( const void * ) & rtcapiStoredFloats [ 3 ] , ( const void
* ) & rtcapiStoredFloats [ 0 ] , 2 , 0 } , { ( const void * ) &
rtcapiStoredFloats [ 4 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 4 ,
0 } } ; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals
, 252 , ( NULL ) , 0 , ( NULL ) , 0 } , { rtBlockParameters , 218 ,
rtModelParameters , 2 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 2652841513U , 1490001689U , 1507477213U , 2792831185U } , ( NULL ) , 0 ,
0 } ; const rtwCAPI_ModelMappingStaticInfo * model_GetCAPIStaticMap ( void )
{ return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void model_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( ( *
rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( *
rt_dataMapInfoPtr ) . childMMI ) ; rtwCAPI_SetChildMMIArrayLen ( ( *
rt_dataMapInfoPtr ) . mmi , 10 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void model_host_InitializeDataMapInfo ( model_host_DataMapInfo_T * dataMap ,
const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
own_collector_host_InitializeDataMapInfo ( & ( dataMap -> child0 ) ,
"model/Collector A/Model" ) ; dataMap -> childMMI [ 1 ] = & ( dataMap ->
child1 . mmi ) ; collectors_host_InitializeDataMapInfo ( & ( dataMap ->
child1 ) , "model/Collector B/Collector B" ) ; dataMap -> childMMI [ 2 ] = &
( dataMap -> child2 . mmi ) ;
random_communication_loss_host_InitializeDataMapInfo ( & ( dataMap -> child2
) , "model/Model6" ) ; dataMap -> childMMI [ 3 ] = & ( dataMap -> child3 .
mmi ) ; random_communication_loss_host_InitializeDataMapInfo ( & ( dataMap ->
child3 ) , "model/Model7" ) ; dataMap -> childMMI [ 4 ] = & ( dataMap ->
child4 . mmi ) ; random_communication_loss_host_InitializeDataMapInfo ( & (
dataMap -> child4 ) , "model/Model8" ) ; dataMap -> childMMI [ 5 ] = & (
dataMap -> child5 . mmi ) ;
random_communication_loss_host_InitializeDataMapInfo ( & ( dataMap -> child5
) , "model/Model9" ) ; dataMap -> childMMI [ 6 ] = & ( dataMap -> child6 .
mmi ) ; own_scout_host_InitializeDataMapInfo ( & ( dataMap -> child6 ) ,
"model/Scout A/Model1" ) ; dataMap -> childMMI [ 7 ] = & ( dataMap -> child7
. mmi ) ; scouts_host_InitializeDataMapInfo ( & ( dataMap -> child7 ) ,
"model/Scout B/Model" ) ; dataMap -> childMMI [ 8 ] = & ( dataMap -> child8 .
mmi ) ; god_host_InitializeDataMapInfo ( & ( dataMap -> child8 ) ,
"model/god" ) ; dataMap -> childMMI [ 9 ] = & ( dataMap -> child9 . mmi ) ;
referee_host_InitializeDataMapInfo ( & ( dataMap -> child9 ) ,
"model/referee" ) ; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , dataMap ->
childMMI ) ; rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 10 ) ; }
#ifdef __cplusplus
}
#endif
#endif
