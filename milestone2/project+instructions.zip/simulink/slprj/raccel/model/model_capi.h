#include "__cf_model.h"
#ifndef RTW_HEADER_model_capi_h
#define RTW_HEADER_model_capi_h
#include "model.h"
extern void model_InitializeDataMapInfo ( void ) ;
#endif
