  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 26;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (el3s11bva3)
    ;%
      section.nData     = 195;
      section.data(195)  = dumData; %prealloc
      
	  ;% el3s11bva3.Constant_Value
	  section.data(1).logicalSrcIdx = 2;
	  section.data(1).dtTransOffset = 0;
	
	  ;% el3s11bva3.Constant8_Value
	  section.data(2).logicalSrcIdx = 3;
	  section.data(2).dtTransOffset = 1;
	
	  ;% el3s11bva3.Constant9_Value
	  section.data(3).logicalSrcIdx = 4;
	  section.data(3).dtTransOffset = 2;
	
	  ;% el3s11bva3.Constant10_Value
	  section.data(4).logicalSrcIdx = 5;
	  section.data(4).dtTransOffset = 3;
	
	  ;% el3s11bva3.Constant11_Value
	  section.data(5).logicalSrcIdx = 6;
	  section.data(5).dtTransOffset = 4;
	
	  ;% el3s11bva3.Constant12_Value
	  section.data(6).logicalSrcIdx = 7;
	  section.data(6).dtTransOffset = 5;
	
	  ;% el3s11bva3.Constant13_Value
	  section.data(7).logicalSrcIdx = 8;
	  section.data(7).dtTransOffset = 6;
	
	  ;% el3s11bva3.random_Value
	  section.data(8).logicalSrcIdx = 9;
	  section.data(8).dtTransOffset = 7;
	
	  ;% el3s11bva3.pattern_Value
	  section.data(9).logicalSrcIdx = 10;
	  section.data(9).dtTransOffset = 8;
	
	  ;% el3s11bva3.Constant5_Value
	  section.data(10).logicalSrcIdx = 11;
	  section.data(10).dtTransOffset = 9;
	
	  ;% el3s11bva3.Constant7_Value
	  section.data(11).logicalSrcIdx = 12;
	  section.data(11).dtTransOffset = 10;
	
	  ;% el3s11bva3.random_x_destination_Minimum
	  section.data(12).logicalSrcIdx = 13;
	  section.data(12).dtTransOffset = 11;
	
	  ;% el3s11bva3.random_x_destination_Maximum
	  section.data(13).logicalSrcIdx = 14;
	  section.data(13).dtTransOffset = 12;
	
	  ;% el3s11bva3.random_x_destination_Seed
	  section.data(14).logicalSrcIdx = 15;
	  section.data(14).dtTransOffset = 13;
	
	  ;% el3s11bva3.random_y_destination_Minimum
	  section.data(15).logicalSrcIdx = 16;
	  section.data(15).dtTransOffset = 14;
	
	  ;% el3s11bva3.random_y_destination_Maximum
	  section.data(16).logicalSrcIdx = 17;
	  section.data(16).dtTransOffset = 15;
	
	  ;% el3s11bva3.random_y_destination_Seed
	  section.data(17).logicalSrcIdx = 18;
	  section.data(17).dtTransOffset = 16;
	
	  ;% el3s11bva3.Constant13_Value_elqoepz2mi
	  section.data(18).logicalSrcIdx = 19;
	  section.data(18).dtTransOffset = 17;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum
	  section.data(19).logicalSrcIdx = 20;
	  section.data(19).dtTransOffset = 18;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum
	  section.data(20).logicalSrcIdx = 21;
	  section.data(20).dtTransOffset = 19;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed
	  section.data(21).logicalSrcIdx = 22;
	  section.data(21).dtTransOffset = 20;
	
	  ;% el3s11bva3.Switch_Threshold
	  section.data(22).logicalSrcIdx = 23;
	  section.data(22).dtTransOffset = 21;
	
	  ;% el3s11bva3.Constant9_Value_mmv01kox2d
	  section.data(23).logicalSrcIdx = 24;
	  section.data(23).dtTransOffset = 22;
	
	  ;% el3s11bva3.Constant1_Value
	  section.data(24).logicalSrcIdx = 25;
	  section.data(24).dtTransOffset = 23;
	
	  ;% el3s11bva3.Switch1_Threshold
	  section.data(25).logicalSrcIdx = 26;
	  section.data(25).dtTransOffset = 24;
	
	  ;% el3s11bva3.Constant13_Value_eqp0jos5ki
	  section.data(26).logicalSrcIdx = 27;
	  section.data(26).dtTransOffset = 25;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum_e22xufda1w
	  section.data(27).logicalSrcIdx = 28;
	  section.data(27).dtTransOffset = 26;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum_duuqdny15m
	  section.data(28).logicalSrcIdx = 29;
	  section.data(28).dtTransOffset = 27;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed_djtjrnsnnx
	  section.data(29).logicalSrcIdx = 30;
	  section.data(29).dtTransOffset = 28;
	
	  ;% el3s11bva3.Switch_Threshold_cdlb2dxcel
	  section.data(30).logicalSrcIdx = 31;
	  section.data(30).dtTransOffset = 29;
	
	  ;% el3s11bva3.Constant9_Value_mkm1qdjnjo
	  section.data(31).logicalSrcIdx = 32;
	  section.data(31).dtTransOffset = 30;
	
	  ;% el3s11bva3.Constant1_Value_kc3fd44lvc
	  section.data(32).logicalSrcIdx = 33;
	  section.data(32).dtTransOffset = 31;
	
	  ;% el3s11bva3.Switch1_Threshold_jaddws4amb
	  section.data(33).logicalSrcIdx = 34;
	  section.data(33).dtTransOffset = 32;
	
	  ;% el3s11bva3.Constant5_Value_ilynirohi2
	  section.data(34).logicalSrcIdx = 35;
	  section.data(34).dtTransOffset = 33;
	
	  ;% el3s11bva3.Constant13_Value_eeh12bmm2g
	  section.data(35).logicalSrcIdx = 36;
	  section.data(35).dtTransOffset = 34;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum_k02uumxuku
	  section.data(36).logicalSrcIdx = 37;
	  section.data(36).dtTransOffset = 35;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum_nkwogljtyv
	  section.data(37).logicalSrcIdx = 38;
	  section.data(37).dtTransOffset = 36;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed_acwzdxvlvk
	  section.data(38).logicalSrcIdx = 39;
	  section.data(38).dtTransOffset = 37;
	
	  ;% el3s11bva3.Switch_Threshold_pixetlauxb
	  section.data(39).logicalSrcIdx = 40;
	  section.data(39).dtTransOffset = 38;
	
	  ;% el3s11bva3.Constant8_Value_jf2fosnw3b
	  section.data(40).logicalSrcIdx = 41;
	  section.data(40).dtTransOffset = 39;
	
	  ;% el3s11bva3.Constant9_Value_pjdmuf5qiy
	  section.data(41).logicalSrcIdx = 42;
	  section.data(41).dtTransOffset = 40;
	
	  ;% el3s11bva3.Constant_Value_mtxti12az5
	  section.data(42).logicalSrcIdx = 43;
	  section.data(42).dtTransOffset = 41;
	
	  ;% el3s11bva3.Switch1_Threshold_mfp2kd03vv
	  section.data(43).logicalSrcIdx = 44;
	  section.data(43).dtTransOffset = 42;
	
	  ;% el3s11bva3.Constant4_Value
	  section.data(44).logicalSrcIdx = 45;
	  section.data(44).dtTransOffset = 43;
	
	  ;% el3s11bva3.Constant9_Value_jedsy1niga
	  section.data(45).logicalSrcIdx = 46;
	  section.data(45).dtTransOffset = 44;
	
	  ;% el3s11bva3.Switch1_Threshold_ggx3yt4m15
	  section.data(46).logicalSrcIdx = 47;
	  section.data(46).dtTransOffset = 45;
	
	  ;% el3s11bva3.Constant6_Value
	  section.data(47).logicalSrcIdx = 48;
	  section.data(47).dtTransOffset = 46;
	
	  ;% el3s11bva3.Switch2_Threshold
	  section.data(48).logicalSrcIdx = 49;
	  section.data(48).dtTransOffset = 47;
	
	  ;% el3s11bva3.Constant9_Value_hjx2d0ehlo
	  section.data(49).logicalSrcIdx = 50;
	  section.data(49).dtTransOffset = 48;
	
	  ;% el3s11bva3.Constant_Value_aar2t1o0pc
	  section.data(50).logicalSrcIdx = 51;
	  section.data(50).dtTransOffset = 49;
	
	  ;% el3s11bva3.Switch1_Threshold_bkdrcbb4na
	  section.data(51).logicalSrcIdx = 52;
	  section.data(51).dtTransOffset = 50;
	
	  ;% el3s11bva3.Constant9_Value_gs2rlkywki
	  section.data(52).logicalSrcIdx = 53;
	  section.data(52).dtTransOffset = 51;
	
	  ;% el3s11bva3.Constant_Value_ijxldit3zf
	  section.data(53).logicalSrcIdx = 54;
	  section.data(53).dtTransOffset = 52;
	
	  ;% el3s11bva3.Switch1_Threshold_leklxdka0k
	  section.data(54).logicalSrcIdx = 55;
	  section.data(54).dtTransOffset = 53;
	
	  ;% el3s11bva3.Switch3_Threshold
	  section.data(55).logicalSrcIdx = 56;
	  section.data(55).dtTransOffset = 54;
	
	  ;% el3s11bva3.Constant_Value_fvslqcrdl2
	  section.data(56).logicalSrcIdx = 57;
	  section.data(56).dtTransOffset = 55;
	
	  ;% el3s11bva3.Memory_InitialCondition
	  section.data(57).logicalSrcIdx = 58;
	  section.data(57).dtTransOffset = 56;
	
	  ;% el3s11bva3.Memory1_InitialCondition
	  section.data(58).logicalSrcIdx = 59;
	  section.data(58).dtTransOffset = 57;
	
	  ;% el3s11bva3.Memory2_InitialCondition
	  section.data(59).logicalSrcIdx = 60;
	  section.data(59).dtTransOffset = 58;
	
	  ;% el3s11bva3.Constant7_Value_lo1deheetm
	  section.data(60).logicalSrcIdx = 61;
	  section.data(60).dtTransOffset = 59;
	
	  ;% el3s11bva3.random_x_destination_Minimum_fxtuk00qww
	  section.data(61).logicalSrcIdx = 62;
	  section.data(61).dtTransOffset = 60;
	
	  ;% el3s11bva3.random_x_destination_Maximum_jv24dihhtt
	  section.data(62).logicalSrcIdx = 63;
	  section.data(62).dtTransOffset = 61;
	
	  ;% el3s11bva3.random_x_destination_Seed_a4xosc2llf
	  section.data(63).logicalSrcIdx = 64;
	  section.data(63).dtTransOffset = 62;
	
	  ;% el3s11bva3.random_y_destination_Minimum_dergtqofok
	  section.data(64).logicalSrcIdx = 65;
	  section.data(64).dtTransOffset = 63;
	
	  ;% el3s11bva3.random_y_destination_Maximum_cttnoi3pwu
	  section.data(65).logicalSrcIdx = 66;
	  section.data(65).dtTransOffset = 64;
	
	  ;% el3s11bva3.random_y_destination_Seed_blcncfcags
	  section.data(66).logicalSrcIdx = 67;
	  section.data(66).dtTransOffset = 65;
	
	  ;% el3s11bva3.Constant13_Value_np2scmdq2n
	  section.data(67).logicalSrcIdx = 68;
	  section.data(67).dtTransOffset = 66;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum_hi1nli0cfn
	  section.data(68).logicalSrcIdx = 69;
	  section.data(68).dtTransOffset = 67;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum_iqv4e5c3zy
	  section.data(69).logicalSrcIdx = 70;
	  section.data(69).dtTransOffset = 68;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed_ndvlssmenu
	  section.data(70).logicalSrcIdx = 71;
	  section.data(70).dtTransOffset = 69;
	
	  ;% el3s11bva3.Switch_Threshold_jfs2k2a5tu
	  section.data(71).logicalSrcIdx = 72;
	  section.data(71).dtTransOffset = 70;
	
	  ;% el3s11bva3.IC_Value
	  section.data(72).logicalSrcIdx = 73;
	  section.data(72).dtTransOffset = 71;
	
	  ;% el3s11bva3.Constant9_Value_eswfotb04n
	  section.data(73).logicalSrcIdx = 74;
	  section.data(73).dtTransOffset = 72;
	
	  ;% el3s11bva3.Constant1_Value_mribuf3piz
	  section.data(74).logicalSrcIdx = 75;
	  section.data(74).dtTransOffset = 73;
	
	  ;% el3s11bva3.Switch1_Threshold_io1apnmx2q
	  section.data(75).logicalSrcIdx = 76;
	  section.data(75).dtTransOffset = 74;
	
	  ;% el3s11bva3.Constant13_Value_lfi4t4n5ry
	  section.data(76).logicalSrcIdx = 77;
	  section.data(76).dtTransOffset = 75;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum_j2apvjkwzu
	  section.data(77).logicalSrcIdx = 78;
	  section.data(77).dtTransOffset = 76;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum_m3cg2u240z
	  section.data(78).logicalSrcIdx = 79;
	  section.data(78).dtTransOffset = 77;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed_mgaiufdtyi
	  section.data(79).logicalSrcIdx = 80;
	  section.data(79).dtTransOffset = 78;
	
	  ;% el3s11bva3.Switch_Threshold_a1jo4yhdpi
	  section.data(80).logicalSrcIdx = 81;
	  section.data(80).dtTransOffset = 79;
	
	  ;% el3s11bva3.IC1_Value
	  section.data(81).logicalSrcIdx = 82;
	  section.data(81).dtTransOffset = 80;
	
	  ;% el3s11bva3.Constant9_Value_cto3nurbbk
	  section.data(82).logicalSrcIdx = 83;
	  section.data(82).dtTransOffset = 81;
	
	  ;% el3s11bva3.Constant1_Value_hot2ytiafz
	  section.data(83).logicalSrcIdx = 84;
	  section.data(83).dtTransOffset = 82;
	
	  ;% el3s11bva3.Switch1_Threshold_mjy4itckve
	  section.data(84).logicalSrcIdx = 85;
	  section.data(84).dtTransOffset = 83;
	
	  ;% el3s11bva3.Constant5_Value_czaaoinsnr
	  section.data(85).logicalSrcIdx = 86;
	  section.data(85).dtTransOffset = 84;
	
	  ;% el3s11bva3.Constant13_Value_dlaeksitf2
	  section.data(86).logicalSrcIdx = 87;
	  section.data(86).dtTransOffset = 85;
	
	  ;% el3s11bva3.UniformRandomNumber_Minimum_os52rgwsjp
	  section.data(87).logicalSrcIdx = 88;
	  section.data(87).dtTransOffset = 86;
	
	  ;% el3s11bva3.UniformRandomNumber_Maximum_g5mazrmshc
	  section.data(88).logicalSrcIdx = 89;
	  section.data(88).dtTransOffset = 87;
	
	  ;% el3s11bva3.UniformRandomNumber_Seed_csjtlmoxke
	  section.data(89).logicalSrcIdx = 90;
	  section.data(89).dtTransOffset = 88;
	
	  ;% el3s11bva3.Switch_Threshold_axnrqpilx0
	  section.data(90).logicalSrcIdx = 91;
	  section.data(90).dtTransOffset = 89;
	
	  ;% el3s11bva3.IC2_Value
	  section.data(91).logicalSrcIdx = 92;
	  section.data(91).dtTransOffset = 90;
	
	  ;% el3s11bva3.Constant8_Value_hs2smrn0nu
	  section.data(92).logicalSrcIdx = 93;
	  section.data(92).dtTransOffset = 91;
	
	  ;% el3s11bva3.Constant9_Value_pxe2jyk15f
	  section.data(93).logicalSrcIdx = 94;
	  section.data(93).dtTransOffset = 92;
	
	  ;% el3s11bva3.Constant_Value_cgsw52jc2f
	  section.data(94).logicalSrcIdx = 95;
	  section.data(94).dtTransOffset = 93;
	
	  ;% el3s11bva3.Switch1_Threshold_dpybs3ruok
	  section.data(95).logicalSrcIdx = 96;
	  section.data(95).dtTransOffset = 94;
	
	  ;% el3s11bva3.Constant4_Value_hwsd0aq5tk
	  section.data(96).logicalSrcIdx = 97;
	  section.data(96).dtTransOffset = 95;
	
	  ;% el3s11bva3.Constant9_Value_dbxnqlknqm
	  section.data(97).logicalSrcIdx = 98;
	  section.data(97).dtTransOffset = 96;
	
	  ;% el3s11bva3.Switch1_Threshold_byxnfpd4v3
	  section.data(98).logicalSrcIdx = 99;
	  section.data(98).dtTransOffset = 97;
	
	  ;% el3s11bva3.Constant6_Value_kvbns2yqhv
	  section.data(99).logicalSrcIdx = 100;
	  section.data(99).dtTransOffset = 98;
	
	  ;% el3s11bva3.Switch2_Threshold_eflsudq1e1
	  section.data(100).logicalSrcIdx = 101;
	  section.data(100).dtTransOffset = 99;
	
	  ;% el3s11bva3.Constant9_Value_f3b050jkcc
	  section.data(101).logicalSrcIdx = 102;
	  section.data(101).dtTransOffset = 100;
	
	  ;% el3s11bva3.Constant_Value_eajaadlfel
	  section.data(102).logicalSrcIdx = 103;
	  section.data(102).dtTransOffset = 101;
	
	  ;% el3s11bva3.Switch1_Threshold_ixuscjd3ov
	  section.data(103).logicalSrcIdx = 104;
	  section.data(103).dtTransOffset = 102;
	
	  ;% el3s11bva3.Constant9_Value_duq42b30jy
	  section.data(104).logicalSrcIdx = 105;
	  section.data(104).dtTransOffset = 103;
	
	  ;% el3s11bva3.Constant_Value_fnzeo0uh0y
	  section.data(105).logicalSrcIdx = 106;
	  section.data(105).dtTransOffset = 104;
	
	  ;% el3s11bva3.Switch1_Threshold_lfgrm43eqj
	  section.data(106).logicalSrcIdx = 107;
	  section.data(106).dtTransOffset = 105;
	
	  ;% el3s11bva3.Switch3_Threshold_cmbttkg5bu
	  section.data(107).logicalSrcIdx = 108;
	  section.data(107).dtTransOffset = 106;
	
	  ;% el3s11bva3.Constant_Value_bveil10atp
	  section.data(108).logicalSrcIdx = 109;
	  section.data(108).dtTransOffset = 107;
	
	  ;% el3s11bva3.Memory_InitialCondition_dstumr4sfk
	  section.data(109).logicalSrcIdx = 110;
	  section.data(109).dtTransOffset = 108;
	
	  ;% el3s11bva3.Memory1_InitialCondition_ot0ig5ijng
	  section.data(110).logicalSrcIdx = 111;
	  section.data(110).dtTransOffset = 109;
	
	  ;% el3s11bva3.Memory2_InitialCondition_i5zi52wwtm
	  section.data(111).logicalSrcIdx = 112;
	  section.data(111).dtTransOffset = 110;
	
	  ;% el3s11bva3.Constant7_Value_jrza4df2dq
	  section.data(112).logicalSrcIdx = 113;
	  section.data(112).dtTransOffset = 111;
	
	  ;% el3s11bva3.Constant_Value_ba2qae5xn0
	  section.data(113).logicalSrcIdx = 114;
	  section.data(113).dtTransOffset = 112;
	
	  ;% el3s11bva3.Memory_InitialCondition_hu5tzlerqo
	  section.data(114).logicalSrcIdx = 115;
	  section.data(114).dtTransOffset = 113;
	
	  ;% el3s11bva3.Constant9_Value_ayk0x4s3me
	  section.data(115).logicalSrcIdx = 116;
	  section.data(115).dtTransOffset = 114;
	
	  ;% el3s11bva3.Constant_Value_lzyuti2pmz
	  section.data(116).logicalSrcIdx = 117;
	  section.data(116).dtTransOffset = 115;
	
	  ;% el3s11bva3.Switch1_Threshold_arl11mzrqd
	  section.data(117).logicalSrcIdx = 118;
	  section.data(117).dtTransOffset = 116;
	
	  ;% el3s11bva3.Constant9_Value_b2cgcai5jd
	  section.data(118).logicalSrcIdx = 119;
	  section.data(118).dtTransOffset = 117;
	
	  ;% el3s11bva3.Constant_Value_j2wanecgzn
	  section.data(119).logicalSrcIdx = 120;
	  section.data(119).dtTransOffset = 118;
	
	  ;% el3s11bva3.Switch1_Threshold_gfymtird2p
	  section.data(120).logicalSrcIdx = 121;
	  section.data(120).dtTransOffset = 119;
	
	  ;% el3s11bva3.random_x_destination_Minimum_oaup3ii1l5
	  section.data(121).logicalSrcIdx = 122;
	  section.data(121).dtTransOffset = 120;
	
	  ;% el3s11bva3.random_x_destination_Maximum_p1st3nyrun
	  section.data(122).logicalSrcIdx = 123;
	  section.data(122).dtTransOffset = 121;
	
	  ;% el3s11bva3.random_x_destination_Seed_byzwkqj0yd
	  section.data(123).logicalSrcIdx = 124;
	  section.data(123).dtTransOffset = 122;
	
	  ;% el3s11bva3.random_y_destination_Minimum_aarhjqxx0j
	  section.data(124).logicalSrcIdx = 125;
	  section.data(124).dtTransOffset = 123;
	
	  ;% el3s11bva3.random_y_destination_Maximum_bmfxifldi0
	  section.data(125).logicalSrcIdx = 126;
	  section.data(125).dtTransOffset = 124;
	
	  ;% el3s11bva3.random_y_destination_Seed_oo4c5wzgp2
	  section.data(126).logicalSrcIdx = 127;
	  section.data(126).dtTransOffset = 125;
	
	  ;% el3s11bva3.IC2_Value_dtciakshru
	  section.data(127).logicalSrcIdx = 128;
	  section.data(127).dtTransOffset = 126;
	
	  ;% el3s11bva3.Constant9_Value_n54nuen2rj
	  section.data(128).logicalSrcIdx = 129;
	  section.data(128).dtTransOffset = 127;
	
	  ;% el3s11bva3.Constant1_Value_lztbhcwkig
	  section.data(129).logicalSrcIdx = 130;
	  section.data(129).dtTransOffset = 128;
	
	  ;% el3s11bva3.Switch1_Threshold_n0njrd3uxy
	  section.data(130).logicalSrcIdx = 131;
	  section.data(130).dtTransOffset = 129;
	
	  ;% el3s11bva3.IC_Value_j0goa0uerk
	  section.data(131).logicalSrcIdx = 132;
	  section.data(131).dtTransOffset = 130;
	
	  ;% el3s11bva3.Constant9_Value_jo0s0sfoe1
	  section.data(132).logicalSrcIdx = 133;
	  section.data(132).dtTransOffset = 131;
	
	  ;% el3s11bva3.Constant1_Value_np5p343ljn
	  section.data(133).logicalSrcIdx = 134;
	  section.data(133).dtTransOffset = 132;
	
	  ;% el3s11bva3.Switch1_Threshold_pmhczo2bql
	  section.data(134).logicalSrcIdx = 135;
	  section.data(134).dtTransOffset = 133;
	
	  ;% el3s11bva3.Constant5_Value_eyzlfy4z1i
	  section.data(135).logicalSrcIdx = 136;
	  section.data(135).dtTransOffset = 134;
	
	  ;% el3s11bva3.IC1_Value_ny1yfk1mio
	  section.data(136).logicalSrcIdx = 137;
	  section.data(136).dtTransOffset = 135;
	
	  ;% el3s11bva3.Constant8_Value_o40j3s04wm
	  section.data(137).logicalSrcIdx = 138;
	  section.data(137).dtTransOffset = 136;
	
	  ;% el3s11bva3.Constant9_Value_hi3q3xgenf
	  section.data(138).logicalSrcIdx = 139;
	  section.data(138).dtTransOffset = 137;
	
	  ;% el3s11bva3.Constant_Value_m5gwddclk4
	  section.data(139).logicalSrcIdx = 140;
	  section.data(139).dtTransOffset = 138;
	
	  ;% el3s11bva3.Switch1_Threshold_eskalvmcl5
	  section.data(140).logicalSrcIdx = 141;
	  section.data(140).dtTransOffset = 139;
	
	  ;% el3s11bva3.Constant4_Value_dke4qkvy2m
	  section.data(141).logicalSrcIdx = 142;
	  section.data(141).dtTransOffset = 140;
	
	  ;% el3s11bva3.Constant9_Value_ikig2ugeov
	  section.data(142).logicalSrcIdx = 143;
	  section.data(142).dtTransOffset = 141;
	
	  ;% el3s11bva3.Switch1_Threshold_megsj2kdn4
	  section.data(143).logicalSrcIdx = 144;
	  section.data(143).dtTransOffset = 142;
	
	  ;% el3s11bva3.Constant6_Value_natwbdlt5l
	  section.data(144).logicalSrcIdx = 145;
	  section.data(144).dtTransOffset = 143;
	
	  ;% el3s11bva3.Switch2_Threshold_abc2i3utpw
	  section.data(145).logicalSrcIdx = 146;
	  section.data(145).dtTransOffset = 144;
	
	  ;% el3s11bva3.Constant9_Value_prk4lzbupc
	  section.data(146).logicalSrcIdx = 147;
	  section.data(146).dtTransOffset = 145;
	
	  ;% el3s11bva3.Constant_Value_f2ccrnzbo3
	  section.data(147).logicalSrcIdx = 148;
	  section.data(147).dtTransOffset = 146;
	
	  ;% el3s11bva3.Switch1_Threshold_gv03eoziqu
	  section.data(148).logicalSrcIdx = 149;
	  section.data(148).dtTransOffset = 147;
	
	  ;% el3s11bva3.Constant9_Value_gv1ubadb1z
	  section.data(149).logicalSrcIdx = 150;
	  section.data(149).dtTransOffset = 148;
	
	  ;% el3s11bva3.Constant_Value_os30wzhpv5
	  section.data(150).logicalSrcIdx = 151;
	  section.data(150).dtTransOffset = 149;
	
	  ;% el3s11bva3.Switch1_Threshold_othhfgja33
	  section.data(151).logicalSrcIdx = 152;
	  section.data(151).dtTransOffset = 150;
	
	  ;% el3s11bva3.Switch3_Threshold_k51oykqbvl
	  section.data(152).logicalSrcIdx = 153;
	  section.data(152).dtTransOffset = 151;
	
	  ;% el3s11bva3.Constant_Value_n4u35q4q5x
	  section.data(153).logicalSrcIdx = 154;
	  section.data(153).dtTransOffset = 152;
	
	  ;% el3s11bva3.Memory_InitialCondition_f1jkovjs1i
	  section.data(154).logicalSrcIdx = 155;
	  section.data(154).dtTransOffset = 153;
	
	  ;% el3s11bva3.Memory1_InitialCondition_h3nsks1jbo
	  section.data(155).logicalSrcIdx = 156;
	  section.data(155).dtTransOffset = 154;
	
	  ;% el3s11bva3.Memory2_InitialCondition_mvexewp4sm
	  section.data(156).logicalSrcIdx = 157;
	  section.data(156).dtTransOffset = 155;
	
	  ;% el3s11bva3.Constant7_Value_jejusotfky
	  section.data(157).logicalSrcIdx = 158;
	  section.data(157).dtTransOffset = 156;
	
	  ;% el3s11bva3.Constant3_Value
	  section.data(158).logicalSrcIdx = 159;
	  section.data(158).dtTransOffset = 157;
	
	  ;% el3s11bva3.IC_Value_po55tmgpac
	  section.data(159).logicalSrcIdx = 160;
	  section.data(159).dtTransOffset = 158;
	
	  ;% el3s11bva3.IC1_Value_olzkq2isfl
	  section.data(160).logicalSrcIdx = 161;
	  section.data(160).dtTransOffset = 159;
	
	  ;% el3s11bva3.IC2_Value_b44twnluu2
	  section.data(161).logicalSrcIdx = 162;
	  section.data(161).dtTransOffset = 160;
	
	  ;% el3s11bva3.random_x_destination_Minimum_ky4anpr4m4
	  section.data(162).logicalSrcIdx = 163;
	  section.data(162).dtTransOffset = 161;
	
	  ;% el3s11bva3.random_x_destination_Maximum_gvztpymhe0
	  section.data(163).logicalSrcIdx = 164;
	  section.data(163).dtTransOffset = 162;
	
	  ;% el3s11bva3.random_x_destination_Seed_k2uyi2eyqw
	  section.data(164).logicalSrcIdx = 165;
	  section.data(164).dtTransOffset = 163;
	
	  ;% el3s11bva3.random_y_destination_Minimum_bmsqkwvh1b
	  section.data(165).logicalSrcIdx = 166;
	  section.data(165).dtTransOffset = 164;
	
	  ;% el3s11bva3.random_y_destination_Maximum_jr3ltzmqnh
	  section.data(166).logicalSrcIdx = 167;
	  section.data(166).dtTransOffset = 165;
	
	  ;% el3s11bva3.random_y_destination_Seed_nyfms4qhrl
	  section.data(167).logicalSrcIdx = 168;
	  section.data(167).dtTransOffset = 166;
	
	  ;% el3s11bva3.Constant9_Value_gtmy0p2kfs
	  section.data(168).logicalSrcIdx = 169;
	  section.data(168).dtTransOffset = 167;
	
	  ;% el3s11bva3.Constant1_Value_ouzfzmlb2y
	  section.data(169).logicalSrcIdx = 170;
	  section.data(169).dtTransOffset = 168;
	
	  ;% el3s11bva3.Switch1_Threshold_kelisza0pg
	  section.data(170).logicalSrcIdx = 171;
	  section.data(170).dtTransOffset = 169;
	
	  ;% el3s11bva3.Constant9_Value_jgpf1cvdvz
	  section.data(171).logicalSrcIdx = 172;
	  section.data(171).dtTransOffset = 170;
	
	  ;% el3s11bva3.Constant1_Value_p13umlhyxq
	  section.data(172).logicalSrcIdx = 173;
	  section.data(172).dtTransOffset = 171;
	
	  ;% el3s11bva3.Switch1_Threshold_n022ebo4n0
	  section.data(173).logicalSrcIdx = 174;
	  section.data(173).dtTransOffset = 172;
	
	  ;% el3s11bva3.Constant5_Value_prylx2nfvt
	  section.data(174).logicalSrcIdx = 175;
	  section.data(174).dtTransOffset = 173;
	
	  ;% el3s11bva3.Constant8_Value_knyppzji1e
	  section.data(175).logicalSrcIdx = 176;
	  section.data(175).dtTransOffset = 174;
	
	  ;% el3s11bva3.Constant9_Value_oywmk54fo2
	  section.data(176).logicalSrcIdx = 177;
	  section.data(176).dtTransOffset = 175;
	
	  ;% el3s11bva3.Constant_Value_fm5gnbjkca
	  section.data(177).logicalSrcIdx = 178;
	  section.data(177).dtTransOffset = 176;
	
	  ;% el3s11bva3.Switch1_Threshold_agqmymtkki
	  section.data(178).logicalSrcIdx = 179;
	  section.data(178).dtTransOffset = 177;
	
	  ;% el3s11bva3.Constant4_Value_kt1d1r1rvu
	  section.data(179).logicalSrcIdx = 180;
	  section.data(179).dtTransOffset = 178;
	
	  ;% el3s11bva3.Constant9_Value_anz3ryaeir
	  section.data(180).logicalSrcIdx = 181;
	  section.data(180).dtTransOffset = 179;
	
	  ;% el3s11bva3.Switch1_Threshold_bk2kua4y4r
	  section.data(181).logicalSrcIdx = 182;
	  section.data(181).dtTransOffset = 180;
	
	  ;% el3s11bva3.Constant6_Value_iwauxqmbam
	  section.data(182).logicalSrcIdx = 183;
	  section.data(182).dtTransOffset = 181;
	
	  ;% el3s11bva3.Switch2_Threshold_nkd344stci
	  section.data(183).logicalSrcIdx = 184;
	  section.data(183).dtTransOffset = 182;
	
	  ;% el3s11bva3.Constant9_Value_eqe2lhczxv
	  section.data(184).logicalSrcIdx = 185;
	  section.data(184).dtTransOffset = 183;
	
	  ;% el3s11bva3.Constant_Value_dwypnnrzgc
	  section.data(185).logicalSrcIdx = 186;
	  section.data(185).dtTransOffset = 184;
	
	  ;% el3s11bva3.Switch1_Threshold_jiiozq2xmu
	  section.data(186).logicalSrcIdx = 187;
	  section.data(186).dtTransOffset = 185;
	
	  ;% el3s11bva3.Constant9_Value_fajil5otqc
	  section.data(187).logicalSrcIdx = 188;
	  section.data(187).dtTransOffset = 186;
	
	  ;% el3s11bva3.Constant_Value_lbmdjikwhf
	  section.data(188).logicalSrcIdx = 189;
	  section.data(188).dtTransOffset = 187;
	
	  ;% el3s11bva3.Switch1_Threshold_cg40gsvgfi
	  section.data(189).logicalSrcIdx = 190;
	  section.data(189).dtTransOffset = 188;
	
	  ;% el3s11bva3.Switch3_Threshold_pvimerup5n
	  section.data(190).logicalSrcIdx = 191;
	  section.data(190).dtTransOffset = 189;
	
	  ;% el3s11bva3.Constant_Value_nryfzuvceq
	  section.data(191).logicalSrcIdx = 192;
	  section.data(191).dtTransOffset = 190;
	
	  ;% el3s11bva3.Memory_InitialCondition_et31lrw0fp
	  section.data(192).logicalSrcIdx = 193;
	  section.data(192).dtTransOffset = 191;
	
	  ;% el3s11bva3.Memory1_InitialCondition_pmpt1ejnb2
	  section.data(193).logicalSrcIdx = 194;
	  section.data(193).dtTransOffset = 192;
	
	  ;% el3s11bva3.Memory2_InitialCondition_dnlujtrzsv
	  section.data(194).logicalSrcIdx = 195;
	  section.data(194).dtTransOffset = 193;
	
	  ;% el3s11bva3.Constant7_Value_fhb5yuyaap
	  section.data(195).logicalSrcIdx = 196;
	  section.data(195).dtTransOffset = 194;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.light_pattern_switch_CurrentSetting
	  section.data(1).logicalSrcIdx = 197;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.iclkdei2xh.Output_Y0
	  section.data(1).logicalSrcIdx = 198;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.p4qjdvlwyg.Output_Y0
	  section.data(1).logicalSrcIdx = 199;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.nzg4g3a3cq.Output_Y0
	  section.data(1).logicalSrcIdx = 200;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.kmz50yvsje.Output_Y0
	  section.data(1).logicalSrcIdx = 201;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.ma24ilhkjx.Output_Y0
	  section.data(1).logicalSrcIdx = 202;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.lvs4tuvo5q.Output_Y0
	  section.data(1).logicalSrcIdx = 203;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.ficyystmwp.Output_Y0
	  section.data(1).logicalSrcIdx = 204;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(9) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.lsd4zxxavz.Output_Y0
	  section.data(1).logicalSrcIdx = 205;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.pkngnbryvt.Output_Y0
	  section.data(1).logicalSrcIdx = 206;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.kinerpas1h.Output_Y0
	  section.data(1).logicalSrcIdx = 207;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(12) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.kra4na34gj.Output_Y0
	  section.data(1).logicalSrcIdx = 208;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(13) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.cecxmc0h1i.Output_Y0
	  section.data(1).logicalSrcIdx = 209;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(14) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.g4s4twk2b2.Output_Y0
	  section.data(1).logicalSrcIdx = 210;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(15) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.avpfi51xqj.Output_Y0
	  section.data(1).logicalSrcIdx = 211;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(16) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.an5txqujzc.Output_Y0
	  section.data(1).logicalSrcIdx = 212;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(17) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.hguo0kwh4p.Output_Y0
	  section.data(1).logicalSrcIdx = 213;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(18) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.oxitfjhj0e.Output_Y0
	  section.data(1).logicalSrcIdx = 214;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(19) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.kxn0m3zbec.Output_Y0
	  section.data(1).logicalSrcIdx = 215;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(20) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.hybb0kqc4xm.Output_Y0
	  section.data(1).logicalSrcIdx = 216;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(21) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.btispofq2nb.Output_Y0
	  section.data(1).logicalSrcIdx = 217;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(22) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.kbzrijfb2o.Output_Y0
	  section.data(1).logicalSrcIdx = 218;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(23) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% el3s11bva3.l4nwcjxgbmr.Output_Y0
	  section.data(1).logicalSrcIdx = 219;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(24) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
	      
	    ;% collision_detection_distance
	    section.nData = 1;
	    section.data(1).logicalSrcIdx = 0;
	    section.data(1).dtTransOffset = 0;
	  
	    nTotData = nTotData + section.nData;
	    paramMap.sections(25) = section;
	    clear section
	  
	      
	    ;% push_force
	    section.nData = 1;
	    section.data(1).logicalSrcIdx = 1;
	    section.data(1).dtTransOffset = 0;
	  
	    nTotData = nTotData + section.nData;
	    paramMap.sections(26) = section;
	    clear section
	  
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 24;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (lemdyvfalhs)
    ;%
      section.nData     = 201;
      section.data(201)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.niif3usptd
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% lemdyvfalhs.amawxeyk2i
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% lemdyvfalhs.fqueftcfuf
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% lemdyvfalhs.nodxfcp40m
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% lemdyvfalhs.ngl5ursdp5
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% lemdyvfalhs.kpxkxchg4l
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% lemdyvfalhs.bmkqgyuy02
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% lemdyvfalhs.ob04arcrak
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% lemdyvfalhs.ceigekm0he
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% lemdyvfalhs.ivfx3vycfj
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% lemdyvfalhs.j2obp2vdbm
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% lemdyvfalhs.jg24yuqrlf
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% lemdyvfalhs.n1sni4qgda
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% lemdyvfalhs.axkn0tj3kk
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% lemdyvfalhs.clbwajughp
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% lemdyvfalhs.imc11ixkro
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% lemdyvfalhs.lcu5p032hu
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% lemdyvfalhs.flfcvs24j3
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% lemdyvfalhs.imqx44z1y2
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% lemdyvfalhs.pmsvvrsozf
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% lemdyvfalhs.p53fcq012l
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% lemdyvfalhs.pxdpmfdlbp
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% lemdyvfalhs.ksfajmgxst
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% lemdyvfalhs.mx1amll0zz
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% lemdyvfalhs.jcjxswchz2
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% lemdyvfalhs.b4csihzanf
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% lemdyvfalhs.gt3kseiesc
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% lemdyvfalhs.ejfmbnlbtp
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% lemdyvfalhs.mnfd3vgtyn
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% lemdyvfalhs.avftxcinmd
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% lemdyvfalhs.hefv5fowan
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% lemdyvfalhs.klpnkc3lij
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% lemdyvfalhs.l3ycykxga3
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% lemdyvfalhs.eqx2aoxtn5
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% lemdyvfalhs.oi3u13hlpw
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% lemdyvfalhs.hqbuqvvxe5
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% lemdyvfalhs.aly0nl4jy5
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% lemdyvfalhs.lz4q5mssw3
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% lemdyvfalhs.foioshrzjd
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% lemdyvfalhs.kdwduyqgbt
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% lemdyvfalhs.p3xvqs243l
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% lemdyvfalhs.pn5amc2d2d
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% lemdyvfalhs.cbwv340ptd
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% lemdyvfalhs.bqttxzaoip
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% lemdyvfalhs.bmxsgsmrv3
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% lemdyvfalhs.ff4mphjk34
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% lemdyvfalhs.d4vij2rcmk
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% lemdyvfalhs.c42vzrsoa4
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% lemdyvfalhs.fawcbqofbl
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% lemdyvfalhs.ofzi3mvxlc
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% lemdyvfalhs.klsq3whhyq
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% lemdyvfalhs.o2gwyfz2ag
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% lemdyvfalhs.icl5evgdd3
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% lemdyvfalhs.ewn1qhxrdv
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% lemdyvfalhs.lgufrbtkr2
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% lemdyvfalhs.fncdv5wdjq
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% lemdyvfalhs.f5n1njx0jw
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% lemdyvfalhs.kukqniznpc
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% lemdyvfalhs.hd2bjuef5v
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 58;
	
	  ;% lemdyvfalhs.bkptnrsq23
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 59;
	
	  ;% lemdyvfalhs.lcgby2b3g2
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 60;
	
	  ;% lemdyvfalhs.lt55ikl1yb
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 61;
	
	  ;% lemdyvfalhs.h44lhptqp3
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 62;
	
	  ;% lemdyvfalhs.oigyvmvs1s
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 63;
	
	  ;% lemdyvfalhs.h1vs0aa35r
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 64;
	
	  ;% lemdyvfalhs.alshwojygz
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 65;
	
	  ;% lemdyvfalhs.okkjvum3js
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 66;
	
	  ;% lemdyvfalhs.pfqp1ddl2k
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 67;
	
	  ;% lemdyvfalhs.cthg5rqel1
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 68;
	
	  ;% lemdyvfalhs.kgw0amexsf
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 69;
	
	  ;% lemdyvfalhs.lnkxgp0qhe
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 70;
	
	  ;% lemdyvfalhs.jnnqtz1wy1
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 71;
	
	  ;% lemdyvfalhs.aot3rslnli
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 72;
	
	  ;% lemdyvfalhs.irhivy0rii
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 73;
	
	  ;% lemdyvfalhs.bc5e4hvxwh
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 74;
	
	  ;% lemdyvfalhs.jtscbp5h3y
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 75;
	
	  ;% lemdyvfalhs.jikjkxqm5d
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 76;
	
	  ;% lemdyvfalhs.p5rd2lyc3a
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 77;
	
	  ;% lemdyvfalhs.dna0tmvu4j
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 78;
	
	  ;% lemdyvfalhs.jxwwsn1eza
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 79;
	
	  ;% lemdyvfalhs.mko2h50i0e
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 80;
	
	  ;% lemdyvfalhs.lpn35yy1gc
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 81;
	
	  ;% lemdyvfalhs.fnx0uk5nyl
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 82;
	
	  ;% lemdyvfalhs.gwyqdebgln
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 83;
	
	  ;% lemdyvfalhs.kvzqlrq12h
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 84;
	
	  ;% lemdyvfalhs.je1a5dspy2
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 85;
	
	  ;% lemdyvfalhs.eoaow3o32z
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 86;
	
	  ;% lemdyvfalhs.m3zmrf0rvl
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 87;
	
	  ;% lemdyvfalhs.eg4x542g0m
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 88;
	
	  ;% lemdyvfalhs.nejcie2kgo
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 89;
	
	  ;% lemdyvfalhs.bkbjb1as1y
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 90;
	
	  ;% lemdyvfalhs.pibu2pfiet
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 91;
	
	  ;% lemdyvfalhs.hanpj1yii4
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 92;
	
	  ;% lemdyvfalhs.j1u05n2him
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 93;
	
	  ;% lemdyvfalhs.obqqvm1rdw
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 94;
	
	  ;% lemdyvfalhs.ilcxsu533x
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 95;
	
	  ;% lemdyvfalhs.lgdbztnwrq
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 96;
	
	  ;% lemdyvfalhs.mktiqey2b5
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 97;
	
	  ;% lemdyvfalhs.oyxqk3lhvc
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 98;
	
	  ;% lemdyvfalhs.d1pzbumep2
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 99;
	
	  ;% lemdyvfalhs.fn5ekxq1f1
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 100;
	
	  ;% lemdyvfalhs.fbyn4xsxtz
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 101;
	
	  ;% lemdyvfalhs.pf0s5ndbob
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 102;
	
	  ;% lemdyvfalhs.oxyms50csp
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 103;
	
	  ;% lemdyvfalhs.n0hp4zagjv
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 104;
	
	  ;% lemdyvfalhs.jhryf4edf5
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 105;
	
	  ;% lemdyvfalhs.akqigye0d2
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 106;
	
	  ;% lemdyvfalhs.jvbwg00o4c
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 107;
	
	  ;% lemdyvfalhs.gbl1hdv1ob
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 108;
	
	  ;% lemdyvfalhs.h1vbkdhkzd
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 109;
	
	  ;% lemdyvfalhs.mzg13b5ygf
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 110;
	
	  ;% lemdyvfalhs.oi0cnu5mro
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 111;
	
	  ;% lemdyvfalhs.mszbqrncxw
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 112;
	
	  ;% lemdyvfalhs.bksh4hybza
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 113;
	
	  ;% lemdyvfalhs.cf3wgy2zqk
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 114;
	
	  ;% lemdyvfalhs.kxkwmyn4te
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 115;
	
	  ;% lemdyvfalhs.hafzobe53s
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 116;
	
	  ;% lemdyvfalhs.fpynlmxbjm
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 117;
	
	  ;% lemdyvfalhs.ajou24crmh
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 118;
	
	  ;% lemdyvfalhs.izg5xjzxp0
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 119;
	
	  ;% lemdyvfalhs.ptfiptqj5a
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 120;
	
	  ;% lemdyvfalhs.g4ltns0hif
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 121;
	
	  ;% lemdyvfalhs.mozax3lynk
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 122;
	
	  ;% lemdyvfalhs.c1dfijug4k
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 123;
	
	  ;% lemdyvfalhs.mwfc1bfdzw
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 124;
	
	  ;% lemdyvfalhs.hko3vhqkfm
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 125;
	
	  ;% lemdyvfalhs.apexlhdnec
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 126;
	
	  ;% lemdyvfalhs.aohqmjjcro
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 127;
	
	  ;% lemdyvfalhs.bh1kll0gtc
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 128;
	
	  ;% lemdyvfalhs.eqs3l5srls
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 129;
	
	  ;% lemdyvfalhs.n0p4nmln4q
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 130;
	
	  ;% lemdyvfalhs.ob4gj301px
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 131;
	
	  ;% lemdyvfalhs.h04isb3fq2
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 132;
	
	  ;% lemdyvfalhs.etml3z0rpj
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 133;
	
	  ;% lemdyvfalhs.gbu5gikuvw
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 134;
	
	  ;% lemdyvfalhs.mlbdwmzp3m
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 135;
	
	  ;% lemdyvfalhs.e1andkbfid
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 136;
	
	  ;% lemdyvfalhs.g4d2idhg40
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 137;
	
	  ;% lemdyvfalhs.gtt1osg1f1
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 138;
	
	  ;% lemdyvfalhs.emo55yzw2r
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 139;
	
	  ;% lemdyvfalhs.ez4ky3mfnm
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 140;
	
	  ;% lemdyvfalhs.ienss5zvmv
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 141;
	
	  ;% lemdyvfalhs.lx5swuzcbh
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 142;
	
	  ;% lemdyvfalhs.peeeqojqac
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 143;
	
	  ;% lemdyvfalhs.jp3fqgejke
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 144;
	
	  ;% lemdyvfalhs.jqlmorfuba
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 145;
	
	  ;% lemdyvfalhs.myryoqjss3
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 146;
	
	  ;% lemdyvfalhs.evwcvo5bkm
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 147;
	
	  ;% lemdyvfalhs.hcmy1jabtw
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 148;
	
	  ;% lemdyvfalhs.o3oupxvkog
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 149;
	
	  ;% lemdyvfalhs.iun5ct5baq
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 150;
	
	  ;% lemdyvfalhs.mfnpex3gsr
	  section.data(152).logicalSrcIdx = 151;
	  section.data(152).dtTransOffset = 151;
	
	  ;% lemdyvfalhs.agsamxjw3z
	  section.data(153).logicalSrcIdx = 152;
	  section.data(153).dtTransOffset = 152;
	
	  ;% lemdyvfalhs.pu32vkhlie
	  section.data(154).logicalSrcIdx = 153;
	  section.data(154).dtTransOffset = 153;
	
	  ;% lemdyvfalhs.ihvwlbvzka
	  section.data(155).logicalSrcIdx = 154;
	  section.data(155).dtTransOffset = 154;
	
	  ;% lemdyvfalhs.kzfplnwos4
	  section.data(156).logicalSrcIdx = 155;
	  section.data(156).dtTransOffset = 155;
	
	  ;% lemdyvfalhs.cjfxu2cgxt
	  section.data(157).logicalSrcIdx = 156;
	  section.data(157).dtTransOffset = 156;
	
	  ;% lemdyvfalhs.fmuhs2dz41
	  section.data(158).logicalSrcIdx = 157;
	  section.data(158).dtTransOffset = 157;
	
	  ;% lemdyvfalhs.lensyzirgi
	  section.data(159).logicalSrcIdx = 158;
	  section.data(159).dtTransOffset = 158;
	
	  ;% lemdyvfalhs.i24yw4mbom
	  section.data(160).logicalSrcIdx = 159;
	  section.data(160).dtTransOffset = 159;
	
	  ;% lemdyvfalhs.nkpjbarrr0
	  section.data(161).logicalSrcIdx = 160;
	  section.data(161).dtTransOffset = 160;
	
	  ;% lemdyvfalhs.aciak3h2dg
	  section.data(162).logicalSrcIdx = 161;
	  section.data(162).dtTransOffset = 161;
	
	  ;% lemdyvfalhs.ov1li0kvq5
	  section.data(163).logicalSrcIdx = 162;
	  section.data(163).dtTransOffset = 162;
	
	  ;% lemdyvfalhs.cjzme0drrn
	  section.data(164).logicalSrcIdx = 163;
	  section.data(164).dtTransOffset = 163;
	
	  ;% lemdyvfalhs.fgzsligzri
	  section.data(165).logicalSrcIdx = 164;
	  section.data(165).dtTransOffset = 164;
	
	  ;% lemdyvfalhs.i5zahmuwcw
	  section.data(166).logicalSrcIdx = 165;
	  section.data(166).dtTransOffset = 165;
	
	  ;% lemdyvfalhs.braz0mphnk
	  section.data(167).logicalSrcIdx = 166;
	  section.data(167).dtTransOffset = 166;
	
	  ;% lemdyvfalhs.eklrysk5eo
	  section.data(168).logicalSrcIdx = 167;
	  section.data(168).dtTransOffset = 167;
	
	  ;% lemdyvfalhs.kcrpted3qh
	  section.data(169).logicalSrcIdx = 168;
	  section.data(169).dtTransOffset = 168;
	
	  ;% lemdyvfalhs.l0m5sgndod
	  section.data(170).logicalSrcIdx = 169;
	  section.data(170).dtTransOffset = 169;
	
	  ;% lemdyvfalhs.mnlyiwbsiy
	  section.data(171).logicalSrcIdx = 170;
	  section.data(171).dtTransOffset = 170;
	
	  ;% lemdyvfalhs.nizbijxigg
	  section.data(172).logicalSrcIdx = 171;
	  section.data(172).dtTransOffset = 171;
	
	  ;% lemdyvfalhs.mm30op0rpl
	  section.data(173).logicalSrcIdx = 172;
	  section.data(173).dtTransOffset = 172;
	
	  ;% lemdyvfalhs.ebjz1pdibk
	  section.data(174).logicalSrcIdx = 173;
	  section.data(174).dtTransOffset = 173;
	
	  ;% lemdyvfalhs.lx1v2ap3mi
	  section.data(175).logicalSrcIdx = 174;
	  section.data(175).dtTransOffset = 174;
	
	  ;% lemdyvfalhs.lf4hktw4eg
	  section.data(176).logicalSrcIdx = 175;
	  section.data(176).dtTransOffset = 175;
	
	  ;% lemdyvfalhs.ayjn11ju0w
	  section.data(177).logicalSrcIdx = 176;
	  section.data(177).dtTransOffset = 176;
	
	  ;% lemdyvfalhs.e3kmye2ups
	  section.data(178).logicalSrcIdx = 177;
	  section.data(178).dtTransOffset = 177;
	
	  ;% lemdyvfalhs.iwvwrqn5jk
	  section.data(179).logicalSrcIdx = 178;
	  section.data(179).dtTransOffset = 178;
	
	  ;% lemdyvfalhs.kfle00trtg
	  section.data(180).logicalSrcIdx = 179;
	  section.data(180).dtTransOffset = 179;
	
	  ;% lemdyvfalhs.lz3qbaqq5i
	  section.data(181).logicalSrcIdx = 180;
	  section.data(181).dtTransOffset = 180;
	
	  ;% lemdyvfalhs.afhy1i1qj1
	  section.data(182).logicalSrcIdx = 181;
	  section.data(182).dtTransOffset = 181;
	
	  ;% lemdyvfalhs.boesjlevad
	  section.data(183).logicalSrcIdx = 182;
	  section.data(183).dtTransOffset = 182;
	
	  ;% lemdyvfalhs.kr5qwmuyi1
	  section.data(184).logicalSrcIdx = 183;
	  section.data(184).dtTransOffset = 183;
	
	  ;% lemdyvfalhs.j5l4sqyobi
	  section.data(185).logicalSrcIdx = 184;
	  section.data(185).dtTransOffset = 184;
	
	  ;% lemdyvfalhs.apovva0uhx
	  section.data(186).logicalSrcIdx = 185;
	  section.data(186).dtTransOffset = 185;
	
	  ;% lemdyvfalhs.ha2gy1cf2e
	  section.data(187).logicalSrcIdx = 186;
	  section.data(187).dtTransOffset = 186;
	
	  ;% lemdyvfalhs.huaria4chy
	  section.data(188).logicalSrcIdx = 187;
	  section.data(188).dtTransOffset = 187;
	
	  ;% lemdyvfalhs.ep35d2ihe4
	  section.data(189).logicalSrcIdx = 188;
	  section.data(189).dtTransOffset = 188;
	
	  ;% lemdyvfalhs.bb0kqphudk
	  section.data(190).logicalSrcIdx = 189;
	  section.data(190).dtTransOffset = 189;
	
	  ;% lemdyvfalhs.ewmrkcguh4
	  section.data(191).logicalSrcIdx = 190;
	  section.data(191).dtTransOffset = 190;
	
	  ;% lemdyvfalhs.kjgiaop3tk
	  section.data(192).logicalSrcIdx = 191;
	  section.data(192).dtTransOffset = 191;
	
	  ;% lemdyvfalhs.fgumimiiqn
	  section.data(193).logicalSrcIdx = 192;
	  section.data(193).dtTransOffset = 192;
	
	  ;% lemdyvfalhs.fpd0lgtezn
	  section.data(194).logicalSrcIdx = 193;
	  section.data(194).dtTransOffset = 193;
	
	  ;% lemdyvfalhs.g0ollzpsdy
	  section.data(195).logicalSrcIdx = 194;
	  section.data(195).dtTransOffset = 194;
	
	  ;% lemdyvfalhs.gwcyios52e
	  section.data(196).logicalSrcIdx = 195;
	  section.data(196).dtTransOffset = 195;
	
	  ;% lemdyvfalhs.f4fh0ct45e
	  section.data(197).logicalSrcIdx = 196;
	  section.data(197).dtTransOffset = 196;
	
	  ;% lemdyvfalhs.ocddn3l0tx
	  section.data(198).logicalSrcIdx = 197;
	  section.data(198).dtTransOffset = 197;
	
	  ;% lemdyvfalhs.k3q51v2rm5
	  section.data(199).logicalSrcIdx = 198;
	  section.data(199).dtTransOffset = 198;
	
	  ;% lemdyvfalhs.ifglumd1vr
	  section.data(200).logicalSrcIdx = 199;
	  section.data(200).dtTransOffset = 199;
	
	  ;% lemdyvfalhs.pmhf3wvapt
	  section.data(201).logicalSrcIdx = 200;
	  section.data(201).dtTransOffset = 200;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 5;
      section.data(5)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.dxs5uxsq1f
	  section.data(1).logicalSrcIdx = 201;
	  section.data(1).dtTransOffset = 0;
	
	  ;% lemdyvfalhs.f4veiiqqom
	  section.data(2).logicalSrcIdx = 202;
	  section.data(2).dtTransOffset = 1;
	
	  ;% lemdyvfalhs.ae1szi3am4
	  section.data(3).logicalSrcIdx = 203;
	  section.data(3).dtTransOffset = 2;
	
	  ;% lemdyvfalhs.m1azb0d0ot
	  section.data(4).logicalSrcIdx = 204;
	  section.data(4).dtTransOffset = 3;
	
	  ;% lemdyvfalhs.k3l3s1o3wj
	  section.data(5).logicalSrcIdx = 205;
	  section.data(5).dtTransOffset = 4;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.iclkdei2xh.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 206;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.p4qjdvlwyg.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 207;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.nzg4g3a3cq.dwpkm32nka
	  section.data(1).logicalSrcIdx = 208;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.kmz50yvsje.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 209;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.ma24ilhkjx.dwpkm32nka
	  section.data(1).logicalSrcIdx = 210;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.lvs4tuvo5q.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 211;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.ficyystmwp.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 212;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(9) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.lsd4zxxavz.dwpkm32nka
	  section.data(1).logicalSrcIdx = 213;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.pkngnbryvt.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 214;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.kinerpas1h.dwpkm32nka
	  section.data(1).logicalSrcIdx = 215;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(12) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.kra4na34gj.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 216;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(13) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.cecxmc0h1i.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 217;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(14) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.g4s4twk2b2.dwpkm32nka
	  section.data(1).logicalSrcIdx = 218;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(15) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.avpfi51xqj.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 219;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(16) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.an5txqujzc.dwpkm32nka
	  section.data(1).logicalSrcIdx = 220;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(17) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.hguo0kwh4p.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 221;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(18) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.oxitfjhj0e.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 222;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(19) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.kxn0m3zbec.dwpkm32nka
	  section.data(1).logicalSrcIdx = 223;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(20) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.hybb0kqc4xm.dxyv3wxlza
	  section.data(1).logicalSrcIdx = 224;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(21) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.btispofq2nb.dwpkm32nka
	  section.data(1).logicalSrcIdx = 225;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(22) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.kbzrijfb2o.pbx0mdxumm
	  section.data(1).logicalSrcIdx = 226;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(23) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% lemdyvfalhs.l4nwcjxgbmr.pbx0mdxumm
	  section.data(1).logicalSrcIdx = 227;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(24) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 54;
    sectIdxOffset = 24;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (hyjfvnofcjf)
    ;%
      section.nData     = 36;
      section.data(36)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.e2oy5ioqnc
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.kyzn4txre0
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.hfs1xp5lvr
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.bjyhsdab1f
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hyjfvnofcjf.gqn54rsyya
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hyjfvnofcjf.mv0hu4lay5
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% hyjfvnofcjf.da3zdpiekx
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% hyjfvnofcjf.or4z10x42w
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% hyjfvnofcjf.k3u5qq1zgy
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% hyjfvnofcjf.jc5i3xd3ww
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% hyjfvnofcjf.dznfmozmm1
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% hyjfvnofcjf.acpqqpszmg
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% hyjfvnofcjf.ktoj31pspb
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% hyjfvnofcjf.lpfwplzxht
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% hyjfvnofcjf.befkob0nm0
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% hyjfvnofcjf.ibqg0ihc2r
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% hyjfvnofcjf.kpfibyvpwr
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% hyjfvnofcjf.n3zb0h1u0l
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% hyjfvnofcjf.mwxwvboycb
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% hyjfvnofcjf.btysz113kg
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% hyjfvnofcjf.kckc33tgvz
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% hyjfvnofcjf.l2yzz1po42
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% hyjfvnofcjf.csfld12lsn
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% hyjfvnofcjf.mp4vtnpatt
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% hyjfvnofcjf.ffklragg5z
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% hyjfvnofcjf.ocpmugoslr
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% hyjfvnofcjf.gwzlzi3fcr
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% hyjfvnofcjf.pqke1qtp5t
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% hyjfvnofcjf.cb5dyyie53
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% hyjfvnofcjf.a2eui2uq4d
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% hyjfvnofcjf.hcx5mfpdj5
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% hyjfvnofcjf.adzhjlx1d3
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% hyjfvnofcjf.ejrr0opujh
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% hyjfvnofcjf.fbdoco3pso
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% hyjfvnofcjf.pmzemkzfot
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% hyjfvnofcjf.d4miin10zi
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 28;
      section.data(28)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.d3mnr10sky.LoggedData
	  section.data(1).logicalSrcIdx = 36;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.mkr54arb4j.LoggedData
	  section.data(2).logicalSrcIdx = 37;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.hk23ydukzk.LoggedData
	  section.data(3).logicalSrcIdx = 38;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.oua30wjv04.LoggedData
	  section.data(4).logicalSrcIdx = 39;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hyjfvnofcjf.c1byvylifi.LoggedData
	  section.data(5).logicalSrcIdx = 40;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hyjfvnofcjf.nwje3aiwa1.LoggedData
	  section.data(6).logicalSrcIdx = 41;
	  section.data(6).dtTransOffset = 5;
	
	  ;% hyjfvnofcjf.fkbhho503f.LoggedData
	  section.data(7).logicalSrcIdx = 42;
	  section.data(7).dtTransOffset = 6;
	
	  ;% hyjfvnofcjf.ksrobbhom2.LoggedData
	  section.data(8).logicalSrcIdx = 43;
	  section.data(8).dtTransOffset = 7;
	
	  ;% hyjfvnofcjf.akcybxgxsq.LoggedData
	  section.data(9).logicalSrcIdx = 44;
	  section.data(9).dtTransOffset = 8;
	
	  ;% hyjfvnofcjf.nz0oohz2u4.LoggedData
	  section.data(10).logicalSrcIdx = 45;
	  section.data(10).dtTransOffset = 9;
	
	  ;% hyjfvnofcjf.drxpazwmlt.LoggedData
	  section.data(11).logicalSrcIdx = 46;
	  section.data(11).dtTransOffset = 10;
	
	  ;% hyjfvnofcjf.ig0vckuqns.LoggedData
	  section.data(12).logicalSrcIdx = 47;
	  section.data(12).dtTransOffset = 11;
	
	  ;% hyjfvnofcjf.nbqifup5jw.LoggedData
	  section.data(13).logicalSrcIdx = 48;
	  section.data(13).dtTransOffset = 12;
	
	  ;% hyjfvnofcjf.eyavcmgjhw.LoggedData
	  section.data(14).logicalSrcIdx = 49;
	  section.data(14).dtTransOffset = 13;
	
	  ;% hyjfvnofcjf.dqblop4kaf.LoggedData
	  section.data(15).logicalSrcIdx = 50;
	  section.data(15).dtTransOffset = 14;
	
	  ;% hyjfvnofcjf.pth3l4syjf.LoggedData
	  section.data(16).logicalSrcIdx = 51;
	  section.data(16).dtTransOffset = 15;
	
	  ;% hyjfvnofcjf.plmlo4ypnz.LoggedData
	  section.data(17).logicalSrcIdx = 52;
	  section.data(17).dtTransOffset = 16;
	
	  ;% hyjfvnofcjf.bhsqnunmsp.LoggedData
	  section.data(18).logicalSrcIdx = 53;
	  section.data(18).dtTransOffset = 17;
	
	  ;% hyjfvnofcjf.aob0ldracd.LoggedData
	  section.data(19).logicalSrcIdx = 54;
	  section.data(19).dtTransOffset = 18;
	
	  ;% hyjfvnofcjf.o2zqskp0ft.LoggedData
	  section.data(20).logicalSrcIdx = 55;
	  section.data(20).dtTransOffset = 19;
	
	  ;% hyjfvnofcjf.bn14jpeetz.LoggedData
	  section.data(21).logicalSrcIdx = 56;
	  section.data(21).dtTransOffset = 20;
	
	  ;% hyjfvnofcjf.bimco1vbz2.LoggedData
	  section.data(22).logicalSrcIdx = 57;
	  section.data(22).dtTransOffset = 21;
	
	  ;% hyjfvnofcjf.eyg4yw4ho2.LoggedData
	  section.data(23).logicalSrcIdx = 58;
	  section.data(23).dtTransOffset = 22;
	
	  ;% hyjfvnofcjf.fvvolt5ofh.LoggedData
	  section.data(24).logicalSrcIdx = 59;
	  section.data(24).dtTransOffset = 23;
	
	  ;% hyjfvnofcjf.f4mrwvbfjs.LoggedData
	  section.data(25).logicalSrcIdx = 60;
	  section.data(25).dtTransOffset = 24;
	
	  ;% hyjfvnofcjf.nsg0woburo.LoggedData
	  section.data(26).logicalSrcIdx = 61;
	  section.data(26).dtTransOffset = 25;
	
	  ;% hyjfvnofcjf.midgwga0ec.LoggedData
	  section.data(27).logicalSrcIdx = 62;
	  section.data(27).dtTransOffset = 26;
	
	  ;% hyjfvnofcjf.pk0mphd2xd.LoggedData
	  section.data(28).logicalSrcIdx = 63;
	  section.data(28).dtTransOffset = 27;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 14;
      section.data(14)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.f4rwqf4frz
	  section.data(1).logicalSrcIdx = 64;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.au4xntftvs
	  section.data(2).logicalSrcIdx = 65;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.ie1py2ucxo
	  section.data(3).logicalSrcIdx = 66;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.pqwtpqfmer
	  section.data(4).logicalSrcIdx = 67;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hyjfvnofcjf.ceon4llkl0
	  section.data(5).logicalSrcIdx = 68;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hyjfvnofcjf.m3ijpx4vb2
	  section.data(6).logicalSrcIdx = 69;
	  section.data(6).dtTransOffset = 5;
	
	  ;% hyjfvnofcjf.mbbcjwmfvo
	  section.data(7).logicalSrcIdx = 70;
	  section.data(7).dtTransOffset = 6;
	
	  ;% hyjfvnofcjf.mwkaw4a031
	  section.data(8).logicalSrcIdx = 71;
	  section.data(8).dtTransOffset = 7;
	
	  ;% hyjfvnofcjf.d1uevuez15
	  section.data(9).logicalSrcIdx = 72;
	  section.data(9).dtTransOffset = 8;
	
	  ;% hyjfvnofcjf.az0pjth0yl
	  section.data(10).logicalSrcIdx = 73;
	  section.data(10).dtTransOffset = 9;
	
	  ;% hyjfvnofcjf.eopul15exg
	  section.data(11).logicalSrcIdx = 74;
	  section.data(11).dtTransOffset = 10;
	
	  ;% hyjfvnofcjf.kty32tplte
	  section.data(12).logicalSrcIdx = 75;
	  section.data(12).dtTransOffset = 11;
	
	  ;% hyjfvnofcjf.jdbx1wfv5p
	  section.data(13).logicalSrcIdx = 76;
	  section.data(13).dtTransOffset = 12;
	
	  ;% hyjfvnofcjf.kqwms3hfnx
	  section.data(14).logicalSrcIdx = 77;
	  section.data(14).dtTransOffset = 13;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 12;
      section.data(12)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.nshrin44md
	  section.data(1).logicalSrcIdx = 78;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.dq2eqqmpnm
	  section.data(2).logicalSrcIdx = 79;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.ecxgojhghs
	  section.data(3).logicalSrcIdx = 80;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.ljezothvrs
	  section.data(4).logicalSrcIdx = 81;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hyjfvnofcjf.h12cni13rl
	  section.data(5).logicalSrcIdx = 82;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hyjfvnofcjf.n3xnek2f5o
	  section.data(6).logicalSrcIdx = 83;
	  section.data(6).dtTransOffset = 5;
	
	  ;% hyjfvnofcjf.exjf4rxdot
	  section.data(7).logicalSrcIdx = 84;
	  section.data(7).dtTransOffset = 6;
	
	  ;% hyjfvnofcjf.i2hx5tdvwv
	  section.data(8).logicalSrcIdx = 85;
	  section.data(8).dtTransOffset = 7;
	
	  ;% hyjfvnofcjf.oiolgcu0wl
	  section.data(9).logicalSrcIdx = 86;
	  section.data(9).dtTransOffset = 8;
	
	  ;% hyjfvnofcjf.pgn454kvlc
	  section.data(10).logicalSrcIdx = 87;
	  section.data(10).dtTransOffset = 9;
	
	  ;% hyjfvnofcjf.htb4ehyw0n
	  section.data(11).logicalSrcIdx = 88;
	  section.data(11).dtTransOffset = 10;
	
	  ;% hyjfvnofcjf.l0oup0hhnz
	  section.data(12).logicalSrcIdx = 89;
	  section.data(12).dtTransOffset = 11;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 33;
      section.data(33)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.eq15hbxjqn
	  section.data(1).logicalSrcIdx = 90;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.jfqt5h4wfl
	  section.data(2).logicalSrcIdx = 91;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.hindzrac3d
	  section.data(3).logicalSrcIdx = 92;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.kkjthjqqu3
	  section.data(4).logicalSrcIdx = 93;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hyjfvnofcjf.poy4xxneo2
	  section.data(5).logicalSrcIdx = 94;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hyjfvnofcjf.e0ec4cmqdf
	  section.data(6).logicalSrcIdx = 95;
	  section.data(6).dtTransOffset = 5;
	
	  ;% hyjfvnofcjf.bl2ajyzhej
	  section.data(7).logicalSrcIdx = 96;
	  section.data(7).dtTransOffset = 6;
	
	  ;% hyjfvnofcjf.fvu51ucdxu
	  section.data(8).logicalSrcIdx = 97;
	  section.data(8).dtTransOffset = 7;
	
	  ;% hyjfvnofcjf.jg213mjvq3
	  section.data(9).logicalSrcIdx = 98;
	  section.data(9).dtTransOffset = 8;
	
	  ;% hyjfvnofcjf.mmzzrglrkc
	  section.data(10).logicalSrcIdx = 99;
	  section.data(10).dtTransOffset = 9;
	
	  ;% hyjfvnofcjf.mmlxdosi3k
	  section.data(11).logicalSrcIdx = 100;
	  section.data(11).dtTransOffset = 10;
	
	  ;% hyjfvnofcjf.kf5eqo00rt
	  section.data(12).logicalSrcIdx = 101;
	  section.data(12).dtTransOffset = 11;
	
	  ;% hyjfvnofcjf.aiitkk4m3o
	  section.data(13).logicalSrcIdx = 102;
	  section.data(13).dtTransOffset = 12;
	
	  ;% hyjfvnofcjf.oudpg520pw
	  section.data(14).logicalSrcIdx = 103;
	  section.data(14).dtTransOffset = 13;
	
	  ;% hyjfvnofcjf.br1nsrn1ta
	  section.data(15).logicalSrcIdx = 104;
	  section.data(15).dtTransOffset = 14;
	
	  ;% hyjfvnofcjf.ezyniw4cbw
	  section.data(16).logicalSrcIdx = 105;
	  section.data(16).dtTransOffset = 15;
	
	  ;% hyjfvnofcjf.bywbz31gy0
	  section.data(17).logicalSrcIdx = 106;
	  section.data(17).dtTransOffset = 16;
	
	  ;% hyjfvnofcjf.gotonlqiyi
	  section.data(18).logicalSrcIdx = 107;
	  section.data(18).dtTransOffset = 17;
	
	  ;% hyjfvnofcjf.b2y22mzkey
	  section.data(19).logicalSrcIdx = 108;
	  section.data(19).dtTransOffset = 18;
	
	  ;% hyjfvnofcjf.gdrcnlhhpt
	  section.data(20).logicalSrcIdx = 109;
	  section.data(20).dtTransOffset = 19;
	
	  ;% hyjfvnofcjf.ixlw1fqg4v
	  section.data(21).logicalSrcIdx = 110;
	  section.data(21).dtTransOffset = 20;
	
	  ;% hyjfvnofcjf.nd0mpkfxki
	  section.data(22).logicalSrcIdx = 111;
	  section.data(22).dtTransOffset = 21;
	
	  ;% hyjfvnofcjf.eqjaa3udld
	  section.data(23).logicalSrcIdx = 112;
	  section.data(23).dtTransOffset = 22;
	
	  ;% hyjfvnofcjf.fxi1r5i5fw
	  section.data(24).logicalSrcIdx = 113;
	  section.data(24).dtTransOffset = 23;
	
	  ;% hyjfvnofcjf.kxbmwhhmrz
	  section.data(25).logicalSrcIdx = 114;
	  section.data(25).dtTransOffset = 24;
	
	  ;% hyjfvnofcjf.euxca53afw
	  section.data(26).logicalSrcIdx = 115;
	  section.data(26).dtTransOffset = 25;
	
	  ;% hyjfvnofcjf.e3mhqogr2m
	  section.data(27).logicalSrcIdx = 116;
	  section.data(27).dtTransOffset = 26;
	
	  ;% hyjfvnofcjf.hlsn0v1li5
	  section.data(28).logicalSrcIdx = 117;
	  section.data(28).dtTransOffset = 27;
	
	  ;% hyjfvnofcjf.desw3kfxwr
	  section.data(29).logicalSrcIdx = 118;
	  section.data(29).dtTransOffset = 28;
	
	  ;% hyjfvnofcjf.buafozr5i3
	  section.data(30).logicalSrcIdx = 119;
	  section.data(30).dtTransOffset = 29;
	
	  ;% hyjfvnofcjf.aodfwsooi1
	  section.data(31).logicalSrcIdx = 120;
	  section.data(31).dtTransOffset = 30;
	
	  ;% hyjfvnofcjf.g2iw43qxgp
	  section.data(32).logicalSrcIdx = 121;
	  section.data(32).dtTransOffset = 31;
	
	  ;% hyjfvnofcjf.h3srasu25l
	  section.data(33).logicalSrcIdx = 122;
	  section.data(33).dtTransOffset = 32;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.f4ieeyvu2d
	  section.data(1).logicalSrcIdx = 123;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.ffuc4mh4bg
	  section.data(1).logicalSrcIdx = 124;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.h314wg0my5
	  section.data(1).logicalSrcIdx = 125;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.boyipppd3j
	  section.data(1).logicalSrcIdx = 126;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hyjfvnofcjf.lxmfq3fjys
	  section.data(2).logicalSrcIdx = 127;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hyjfvnofcjf.o1gitq4ln2
	  section.data(3).logicalSrcIdx = 128;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hyjfvnofcjf.j2a2rpgfvf
	  section.data(4).logicalSrcIdx = 129;
	  section.data(4).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(9) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.clco1wljff
	  section.data(1).logicalSrcIdx = 130;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.pju0s2xsd3
	  section.data(1).logicalSrcIdx = 131;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.d1sci41lkp
	  section.data(1).logicalSrcIdx = 132;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(12) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.iclkdei2xh.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 133;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(13) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.iclkdei2xh.a44sofagvr
	  section.data(1).logicalSrcIdx = 134;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(14) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.p4qjdvlwyg.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 135;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(15) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.p4qjdvlwyg.a44sofagvr
	  section.data(1).logicalSrcIdx = 136;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(16) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.nzg4g3a3cq.htpbyzpanx
	  section.data(1).logicalSrcIdx = 137;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(17) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.nzg4g3a3cq.cy2gauiafv
	  section.data(1).logicalSrcIdx = 138;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(18) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kmz50yvsje.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 139;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(19) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kmz50yvsje.a44sofagvr
	  section.data(1).logicalSrcIdx = 140;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(20) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.ma24ilhkjx.htpbyzpanx
	  section.data(1).logicalSrcIdx = 141;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(21) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.ma24ilhkjx.cy2gauiafv
	  section.data(1).logicalSrcIdx = 142;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(22) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.lvs4tuvo5q.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 143;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(23) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.lvs4tuvo5q.a44sofagvr
	  section.data(1).logicalSrcIdx = 144;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(24) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.ficyystmwp.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 145;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(25) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.ficyystmwp.a44sofagvr
	  section.data(1).logicalSrcIdx = 146;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(26) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.lsd4zxxavz.htpbyzpanx
	  section.data(1).logicalSrcIdx = 147;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(27) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.lsd4zxxavz.cy2gauiafv
	  section.data(1).logicalSrcIdx = 148;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(28) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.pkngnbryvt.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 149;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(29) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.pkngnbryvt.a44sofagvr
	  section.data(1).logicalSrcIdx = 150;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(30) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kinerpas1h.htpbyzpanx
	  section.data(1).logicalSrcIdx = 151;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(31) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kinerpas1h.cy2gauiafv
	  section.data(1).logicalSrcIdx = 152;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(32) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kra4na34gj.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 153;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(33) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kra4na34gj.a44sofagvr
	  section.data(1).logicalSrcIdx = 154;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(34) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.cecxmc0h1i.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 155;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(35) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.cecxmc0h1i.a44sofagvr
	  section.data(1).logicalSrcIdx = 156;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(36) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.g4s4twk2b2.htpbyzpanx
	  section.data(1).logicalSrcIdx = 157;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(37) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.g4s4twk2b2.cy2gauiafv
	  section.data(1).logicalSrcIdx = 158;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(38) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.avpfi51xqj.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 159;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(39) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.avpfi51xqj.a44sofagvr
	  section.data(1).logicalSrcIdx = 160;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(40) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.an5txqujzc.htpbyzpanx
	  section.data(1).logicalSrcIdx = 161;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(41) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.an5txqujzc.cy2gauiafv
	  section.data(1).logicalSrcIdx = 162;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(42) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.hguo0kwh4p.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 163;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(43) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.hguo0kwh4p.a44sofagvr
	  section.data(1).logicalSrcIdx = 164;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(44) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.oxitfjhj0e.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 165;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(45) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.oxitfjhj0e.a44sofagvr
	  section.data(1).logicalSrcIdx = 166;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(46) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kxn0m3zbec.htpbyzpanx
	  section.data(1).logicalSrcIdx = 167;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(47) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kxn0m3zbec.cy2gauiafv
	  section.data(1).logicalSrcIdx = 168;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(48) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.hybb0kqc4xm.ne2hs2xcup
	  section.data(1).logicalSrcIdx = 169;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(49) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.hybb0kqc4xm.a44sofagvr
	  section.data(1).logicalSrcIdx = 170;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(50) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.btispofq2nb.htpbyzpanx
	  section.data(1).logicalSrcIdx = 171;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(51) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.btispofq2nb.cy2gauiafv
	  section.data(1).logicalSrcIdx = 172;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(52) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.kbzrijfb2o.aglykiehjc
	  section.data(1).logicalSrcIdx = 173;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(53) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hyjfvnofcjf.l4nwcjxgbmr.aglykiehjc
	  section.data(1).logicalSrcIdx = 174;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(54) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 2652841513;
  targMap.checksum1 = 1490001689;
  targMap.checksum2 = 1507477213;
  targMap.checksum3 = 2792831185;

