#include "__cf_model.h"
#ifndef RTW_HEADER_model_cap_host_h_
#define RTW_HEADER_model_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
#include "own_collector_capi_host.h"
#include "collectors_capi_host.h"
#include "random_communication_loss_capi_host.h"
#include "random_communication_loss_capi_host.h"
#include "random_communication_loss_capi_host.h"
#include "random_communication_loss_capi_host.h"
#include "own_scout_capi_host.h"
#include "scouts_capi_host.h"
#include "god_capi_host.h"
#include "referee_capi_host.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMappingInfo *
childMMI [ 10 ] ; own_collector_host_DataMapInfo_T child0 ;
collectors_host_DataMapInfo_T child1 ;
random_communication_loss_host_DataMapInfo_T child2 ;
random_communication_loss_host_DataMapInfo_T child3 ;
random_communication_loss_host_DataMapInfo_T child4 ;
random_communication_loss_host_DataMapInfo_T child5 ;
own_scout_host_DataMapInfo_T child6 ; scouts_host_DataMapInfo_T child7 ;
god_host_DataMapInfo_T child8 ; referee_host_DataMapInfo_T child9 ; }
model_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void model_host_InitializeDataMapInfo ( model_host_DataMapInfo_T * dataMap ,
const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
