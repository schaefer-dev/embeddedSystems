#include "__cf_model.h"
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "model.h"
#define GRTINTERFACE 1
#endif
